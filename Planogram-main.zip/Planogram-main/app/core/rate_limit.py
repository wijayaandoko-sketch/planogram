from fastapi import Request
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.core.config import settings


def _rate_limit_key(request: Request) -> str:
    """Keys the rate limit per company (X-API-Key) when there is one — each
    company gets its own bucket, so one busy/misbehaving company never eats
    another's quota, and companies sharing a NAT/corporate proxy IP don't
    fight over one shared bucket. Falls back to client IP for requests with
    no API key at all (register-company-data, or a request missing/wrong
    on X-API-Key — that failure is what actually rate-limits it)."""
    api_key = request.headers.get("x-api-key")
    if api_key:
        return f"apikey:{api_key}"
    return get_remote_address(request)


# In-process memory storage (slowapi's default) — correct for a single
# uvicorn worker; see settings.rate_limit_default's docstring for the
# multi-worker caveat.
limiter = Limiter(key_func=_rate_limit_key, default_limits=[settings.rate_limit_default])
