from pathlib import Path

from PIL import Image
from ultralytics import YOLO

from app.core.config import settings
from app.schemas.models import BoundingBox, Detection


class YoloProductDetector:
    """Detects product bounding boxes on a shelf photo.

    Trained separately as a single-class ("product") detector — SKU
    identification happens downstream in the recognition stage, not here.
    """

    def __init__(self, weights_path: Path | None = None):
        self._weights_path = weights_path or settings.yolo_weights_path
        self._model: YOLO | None = None

    def _load(self) -> YOLO:
        if self._model is None:
            if not self._weights_path.exists():
                raise FileNotFoundError(
                    f"YOLO weights not found at {self._weights_path}. "
                    "Train a detector or point yolo_weights_path at one."
                )
            self._model = YOLO(str(self._weights_path))
        return self._model

    def detect(self, image: Image.Image) -> list[Detection]:
        # Pass a PIL.Image (not a numpy array) so Ultralytics performs its
        # own RGB->BGR conversion internally — it only does that for
        # PIL.Image inputs, not for raw ndarrays, and the model was trained
        # expecting BGR (OpenCV convention).
        model = self._load()
        results = model.predict(
            source=image,
            conf=settings.yolo_conf_threshold,
            iou=settings.yolo_iou_threshold,
            imgsz=settings.yolo_imgsz,
            verbose=False,
        )

        detections: list[Detection] = []
        for result in results:
            if result.boxes is None:
                continue
            for box in result.boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                detections.append(
                    Detection(
                        box=BoundingBox(x1=x1, y1=y1, x2=x2, y2=y2),
                        detection_confidence=float(box.conf[0]),
                    )
                )
        return detections
