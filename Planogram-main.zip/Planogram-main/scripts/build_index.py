"""Builds the FAISS SKU index for one company's product catalog.

Looks up the company by company_id in the company_data MySQL table to get
its data_path (catalog root, containing one subfolder per SKU) and
embed_path (embedding checkpoint):

    <data_path>/
        SKU-00123/
            front.jpg
            angle.jpg
        SKU-00124/
            front.jpg

The resulting index is written to data/faiss_index/<company_id>/ (that
path isn't in the database — see app/core/company.py:faiss_index_dir).

Usage:
    python scripts/build_index.py --company C001
"""

import argparse
import os
import sys
from pathlib import Path

# torch and faiss each bundle their own OpenMP runtime on Windows; loading
# both aborts the process (OMP Error #15) unless this is set before either
# is imported.
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

from fastapi import HTTPException
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.company import faiss_index_dir, resolve_company_by_id
from app.recognition.embedder import ProductEmbedder
from app.recognition.faiss_index import SkuFaissIndex

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}


def collect_catalog_images(catalog_dir: Path) -> tuple[list[Image.Image], list[str]]:
    images: list[Image.Image] = []
    sku_ids: list[str] = []

    for sku_dir in sorted(p for p in catalog_dir.iterdir() if p.is_dir()):
        for image_path in sorted(sku_dir.iterdir()):
            if image_path.suffix.lower() not in IMAGE_EXTENSIONS:
                continue
            images.append(Image.open(image_path))
            sku_ids.append(sku_dir.name)

    return images, sku_ids


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--company", required=True, help="company_id, e.g. C001")
    args = parser.parse_args()

    try:
        company = resolve_company_by_id(args.company)
    except HTTPException as exc:
        raise SystemExit(f"{exc.status_code}: {exc.detail}") from exc

    print(f"Company: {company.company_id} ({company.company_name})")

    catalog_dir = company.data_path
    if not catalog_dir.exists():
        raise SystemExit(f"data_path not found: {catalog_dir}")

    print(f"Loading catalog images from {catalog_dir} ...")
    images, sku_ids = collect_catalog_images(catalog_dir)
    if not images:
        raise SystemExit("No catalog images found")
    print(f"Found {len(images)} images across {len(set(sku_ids))} SKUs")

    embedder = ProductEmbedder(checkpoint_path=company.embed_path)
    print(f"Using embedding checkpoint: {company.embed_path if company.embed_path.exists() else '(none, plain pretrained)'}")

    batch_size = 32
    all_embeddings = []
    for start in range(0, len(images), batch_size):
        batch = images[start : start + batch_size]
        all_embeddings.append(embedder.embed_batch(batch))
        print(f"Embedded {min(start + batch_size, len(images))}/{len(images)}")

    import numpy as np

    embeddings = np.concatenate(all_embeddings, axis=0)

    index = SkuFaissIndex()
    index.build(embeddings, sku_ids)
    index_dir = faiss_index_dir(company.company_id)
    index.save(index_dir)
    print(f"Saved FAISS index to {index_dir}")


if __name__ == "__main__":
    main()
