-- Planogram Compliance Detection — database schema
--
-- Canonical source of truth for the 4 tables this app needs (company_data,
-- template_data, store_data, logs). Idempotent — safe to run against a
-- fresh database or an existing one (CREATE TABLE IF NOT EXISTS never
-- touches a table that's already there, so it won't silently "fix" a
-- production table whose structure has drifted; that would need an
-- explicit ALTER, reviewed by hand).
--
-- Usage:
--   mysql -u <user> -p <database> < schema.sql
-- or, if the database itself doesn't exist yet:
--   mysql -u <user> -p -e "CREATE DATABASE IF NOT EXISTS planogram_data"
--   mysql -u <user> -p planogram_data < schema.sql
--
-- Column identifiers used for lookups/UNIQUE constraints deliberately use
-- COLLATE utf8mb4_bin (case-sensitive) instead of the table's default
-- utf8mb4_general_ci (case-insensitive) — without this, "C001" and "c001"
-- would be treated as the SAME value by MySQL, both for WHERE lookups and
-- UNIQUE checks. See README.md "Database" for the full rationale and the
-- app-level behavior this schema supports.
--
-- api_key_hash stores SHA-256(api_key) (64 lowercase hex chars), never the
-- plaintext api_key itself — see app/core/security.py:hash_api_key() and
-- README.md "Keamanan deployment" for why a fast deterministic hash (not
-- a slow salted one like bcrypt) is the right fit for a high-entropy,
-- machine-generated API key rather than a human password. CHAR(64) is
-- exact (SHA-256 hex digests never vary in length), and ascii collation is
-- enough since hex digits are the only characters that ever appear here.

CREATE TABLE IF NOT EXISTS company_data (
    company_id    VARCHAR(50)  COLLATE utf8mb4_bin NOT NULL PRIMARY KEY,
    company_name  VARCHAR(100) COLLATE utf8mb4_bin NOT NULL,
    api_key_hash  CHAR(64)     COLLATE ascii_bin NOT NULL,
    model_path    VARCHAR(255) COLLATE utf8mb4_bin NOT NULL,   -- relative to models/, e.g. "AICE/product.pt"
    embed_path    VARCHAR(255) COLLATE utf8mb4_bin NOT NULL,   -- relative to models/, e.g. "AICE/embedding_model.pt"
    data_path     VARCHAR(255) COLLATE utf8mb4_bin NOT NULL,   -- relative to data/, e.g. "catalog/AICE"
    -- Usage quota: how many more /input-md + /test-detect calls this
    -- company can make. New companies start at 100 (see
    -- POST /register-company-data); decremented by 1 per successful photo
    -- processed (each /input-md photo, each /test-detect call — see
    -- app/core/db.py:consume_api_limit()), topped up via
    -- POST /topup-api-limit (X-Admin-Token only). CHECK keeps it from ever
    -- going negative even under a bug or a race the app-level atomic
    -- UPDATE didn't catch.
    api_limit     INT          NOT NULL DEFAULT 100 CHECK (api_limit >= 0),
    UNIQUE KEY uq_company_data_company_name (company_name),
    UNIQUE KEY uq_company_data_api_key_hash (api_key_hash),
    UNIQUE KEY uq_company_data_model_path (model_path),
    UNIQUE KEY uq_company_data_embed_path (embed_path),
    UNIQUE KEY uq_company_data_data_path (data_path)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS template_data (
    company_id           VARCHAR(50)  COLLATE utf8mb4_bin NOT NULL,       -- = company_data.company_id
    company_name         VARCHAR(100) NOT NULL,                          -- = company_data.company_name
    customer_tag_id      VARCHAR(50)  COLLATE utf8mb4_bin NOT NULL,       -- planogram/layout identity, client-chosen
    customer_tag_data    LONGTEXT NOT NULL,                              -- JSON {sku_id: quantity}, sent as-is by the client
    created_at           TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),  -- microsecond precision so (company_id, customer_tag_id, created_at) is safe as the row identifier
    template_image_path  VARCHAR(255) NULL,                              -- saved reference photo path (never re-detected)
    PRIMARY KEY (company_id, customer_tag_id, created_at)                -- no template_id column — this combination identifies a row
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS store_data (
    company_id      VARCHAR(50)  COLLATE utf8mb4_bin NOT NULL,  -- = company_data.company_id
    company_name    VARCHAR(100) NOT NULL,                      -- = company_data.company_name
    store_id        VARCHAR(50)  COLLATE utf8mb4_bin NOT NULL,  -- unique per company_id (PK below), NOT globally
    store_name      VARCHAR(100) COLLATE utf8mb4_bin NOT NULL,  -- also unique per company_id (see UNIQUE below)
    customer_tag_id VARCHAR(50)  COLLATE utf8mb4_bin NOT NULL,  -- the tag/layout this store uses
    PRIMARY KEY (company_id, store_id),
    UNIQUE KEY uq_store_data_company_store_name (company_id, store_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- log_id + created_at (composite PK, instead of log_id alone) — MySQL/
-- MariaDB requires every column used in a partitioned table's
-- partitioning expression to be part of every unique key, and this table
-- is partitioned by created_at below (see scripts/archive_logs.py).
-- log_id stays AUTO_INCREMENT and behaves exactly as before (InnoDB
-- allows an auto-increment column to lead a composite key) — no
-- application code change needed, nothing here ever looked up a row by
-- log_id alone.
--
-- UNIX_TIMESTAMP(created_at), not TO_DAYS(created_at) — created_at is
-- TIMESTAMP (not DATETIME), and MariaDB/MySQL reject TO_DAYS() on a
-- TIMESTAMP column in a partitioning expression as "timezone-dependent".
-- UNIX_TIMESTAMP() is the documented exception specifically allowed for
-- TIMESTAMP columns here.
--
-- Starts with a single PARTITION ... MAXVALUE catch-all rather than
-- pre-declaring specific months, so this file stays date-independent —
-- scripts/archive_logs.py carves a real month-named partition out of that
-- catch-all (REORGANIZE PARTITION) only when it's actually about to
-- archive that month, then drops it once the data is safely exported.
CREATE TABLE IF NOT EXISTS logs (
    log_id          INT NOT NULL AUTO_INCREMENT,
    url_api         VARCHAR(255) NOT NULL,   -- endpoint name as hit, e.g. "view-template-data" (no leading slash, no dynamic path segment)
    company_id      VARCHAR(50)  NOT NULL,   -- = company_data.company_id
    company_name    VARCHAR(100) NOT NULL,   -- = company_data.company_name
    customer_tag_id VARCHAR(50)  NOT NULL,   -- tag used by this request
    store_id        VARCHAR(50)  NOT NULL,
    store_name      VARCHAR(100) NOT NULL,
    image_path      VARCHAR(255) NULL,       -- specific file for register/update/delete, company folder for view (see README.md)
    message_log     LONGTEXT NULL,           -- JSON: the full response body for this call (or the error body on failure)
    data_type       ENUM('template', 'md', 'store', 'company') NOT NULL,
    activity        ENUM('register', 'update', 'delete', 'view') NOT NULL DEFAULT 'register',  -- 'update' kept for compatibility with old rows; no endpoint produces it anymore
    status          ENUM('success', 'failed') NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (log_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  PARTITION BY RANGE (UNIX_TIMESTAMP(created_at)) (
      PARTITION pmax VALUES LESS THAN MAXVALUE
  );
