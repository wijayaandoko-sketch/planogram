import io
import secrets
import shutil
import sys
from contextlib import contextmanager
from pathlib import Path
from unittest import mock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import Image  # noqa: E402

TEST_ADMIN_TOKEN = "pytest-admin-token-do-not-use-in-prod"


def png_bytes(color=(10, 20, 30)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (10, 10), color).save(buf, format="PNG")
    buf.seek(0)
    return buf.read()


@pytest.fixture(scope="session", autouse=True)
def admin_token():
    """Every test run needs a real admin_token configured, or
    register-company-data 503s for everyone (see require_admin_token's
    fail-closed design) — set directly on the settings singleton rather
    than via monkeypatch since this needs to live for the whole session,
    not just one test."""
    from app.core.config import settings

    settings.admin_token = TEST_ADMIN_TOKEN
    yield TEST_ADMIN_TOKEN


@pytest.fixture(scope="session")
def client(admin_token):
    from fastapi.testclient import TestClient

    import app.main as main

    return TestClient(main.app)


@pytest.fixture(scope="session")
def company(client, admin_token):
    """Registers one throwaway company for the whole test session (model
    loading/index setup has real overhead, not worth repeating per test),
    with a random suffix so reruns never collide with leftovers from a
    previous crashed run. Cleans up its DB rows, uploaded files, and
    filesystem folders (models/, data/catalog/, data/faiss_index/,
    data/uploads/) when the session ends — regardless of whether the tests
    passed or failed."""
    from app.core.config import settings
    from app.core.db import _execute

    suffix = secrets.token_hex(4).upper()
    company_id = f"PYTEST{suffix}"
    company_name = f"PYTEST {suffix} Co"
    api_key = f"pytest-{suffix}-key"

    r = client.post(
        "/register-company-data",
        data={"company_id": company_id, "company_name": company_name, "api_key": api_key},
        files={"model_path": ("model.pt", b"dummy"), "embed_path": ("embed.pt", b"dummy")},
        headers={"X-Admin-Token": admin_token},
    )
    assert r.status_code == 200, r.text

    index_dir = settings.faiss_index_dir / company_id
    index_dir.mkdir(parents=True, exist_ok=True)
    (index_dir / "index.faiss").write_bytes(b"dummy")

    info = {
        "company_id": company_id,
        "company_name": company_name,
        "api_key": api_key,
        "headers": {"X-API-Key": api_key},
    }
    yield info

    for table in ("company_data", "template_data", "store_data", "logs"):
        _execute(f"DELETE FROM {table} WHERE company_id = %s", (company_id,))
    for base in (
        settings.uploads_dir / "template_data" / company_name,
        settings.uploads_dir / "md_data" / company_name,
        settings.models_dir / company_name,
        Path("data/catalog") / company_name,
        index_dir,
    ):
        shutil.rmtree(base, ignore_errors=True)


class _StubPipeline:
    """Fixed, deterministic detections standing in for real YOLO+embedding
    inference — no trained model weights needed to exercise the detection
    endpoints' request/response plumbing, DB writes, and file saves."""

    def __init__(self, detections):
        self._detections = detections

    def detect_and_recognize(self, image):
        return self._detections


def make_detection(sku_id):
    from app.schemas.models import BoundingBox, Detection

    return Detection(
        box=BoundingBox(x1=0, y1=0, x2=5, y2=5), detection_confidence=0.9, sku_id=sku_id, sku_confidence=0.8
    )


@pytest.fixture
def stub_pipeline():
    """Patches both routes that call get_pipeline() — /test-detect and
    /input-md — for the duration of a `with` block. Tests use it as
    `with stub_pipeline(["SKU_A", "SKU_A"]):` to make detection return
    exactly those SKU ids (as separate detections), no trained model
    weights needed."""

    @contextmanager
    def _apply(sku_ids):
        pipeline = _StubPipeline([make_detection(s) for s in sku_ids])
        with mock.patch("app.api.routes.detection.get_pipeline", return_value=pipeline), mock.patch(
            "app.api.routes.md.get_pipeline", return_value=pipeline
        ):
            yield pipeline

    return _apply
