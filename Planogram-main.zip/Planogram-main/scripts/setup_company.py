"""One-shot setup: creates a company plus its templates from a single JSON
config, in one DB transaction — so you don't have to INSERT into
company_data and template_data separately by hand (which is easy to leave
half-done if one step is forgotten or fails).

Also checks model_path/embed_path/data_path actually exist on disk BEFORE
touching the database, so a typo in the config fails fast with a clear
message instead of registering a company that /register-template-data
etc. will 422 on later.

Config format — see scripts/setup_company.example.json:
{
  "company": {
    "company_id": "C001",
    "company_name": "AICE",
    "api_key": "...",
    "model_path": "AICE/product.pt",
    "embed_path": "AICE/embedding_model.pt",
    "data_path": "catalog/AICE"
  },
  "templates": [
    {"customer_tag_id": "LAYOUT_A", "customer_tag_data": {"SUSU COKLAT": 2, "SUSU STROBERI": 3}}
  ]
}

"templates" is optional (omit or leave empty to only create/confirm the
company). A company_id that already exists is NOT an error — it's
skipped, and its existing company_name is reused for the templates so
they always match. Any other failure (duplicate customer_tag_id, bad
column, DB down) rolls back the whole run — nothing partially applied.

Usage:
    python scripts/setup_company.py --config scripts/setup_company.example.json
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.config import settings
from app.core.db import setup_company


def _check_local_paths(company: dict) -> None:
    errors = []

    model_path = settings.models_dir / company["model_path"]
    if not model_path.is_file():
        errors.append(f"model_path not found: {model_path}")

    embed_path = settings.models_dir / company["embed_path"]
    if not embed_path.is_file():
        errors.append(f"embed_path not found: {embed_path}")

    data_path = settings.data_dir / company["data_path"]
    if not data_path.is_dir():
        errors.append(f"data_path not found: {data_path}")

    if errors:
        raise SystemExit("Config points at files/folders that don't exist:\n  " + "\n  ".join(errors))


def _check_template_data(templates: list[dict]) -> None:
    # /input-md does arithmetic on these values (must_have - product_total)
    # — a non-int here would crash that endpoint later instead of failing
    # here, at setup time.
    errors = []
    for template in templates:
        tag_id = template.get("customer_tag_id")
        for sku_id, count in template.get("customer_tag_data", {}).items():
            if not isinstance(count, int) or isinstance(count, bool):
                errors.append(f"{tag_id}: customer_tag_data[{sku_id!r}] = {count!r} is not an integer")

    if errors:
        raise SystemExit("Config has non-integer customer_tag_data values:\n  " + "\n  ".join(errors))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()

    if not args.config.exists():
        raise SystemExit(f"Config file not found: {args.config}")

    config = json.loads(args.config.read_text())
    company = config["company"]
    templates = config.get("templates", [])

    _check_local_paths(company)
    _check_template_data(templates)

    result = setup_company(company, templates)

    print(f"Company {company['company_id']}: {result['company_status']}")
    for tag_id in result["templates"]:
        print(f"  Template created: {tag_id}")
    print("\nAll changes committed in one transaction.")


if __name__ == "__main__":
    main()
