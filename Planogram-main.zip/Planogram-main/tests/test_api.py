"""Integration tests against the real endpoints, hitting a real MySQL
database (see README.md "Test") — this project has no ORM/in-memory
substitute to test against, and every behavior verified here (collation,
composite keys, retry-on-transient-error, ...) is itself a property of the
real database, not something a fake would reproduce faithfully.

Uses the `company`/`client`/`stub_pipeline` fixtures from conftest.py — one
throwaway company per test session (registered via the real
/register-company-data flow), a stubbed detection pipeline (no trained
model weights needed), and full cleanup (DB rows + files) after the run.
"""

import io
import json
import secrets
from unittest import mock

from PIL import Image


def png_bytes(color=(10, 20, 30)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (10, 10), color).save(buf, format="PNG")
    buf.seek(0)
    return buf.read()


def _tag(prefix: str) -> str:
    return f"{prefix}{secrets.token_hex(3).upper()}"


# --- register-company-data --------------------------------------------------


def test_register_company_duplicate_is_409_not_503(client, company, admin_token):
    """Regression check for the duplicate-race fix (db.py's IntegrityError
    handling) — a duplicate company_id must be a clean 409, never the raw
    503 a MySQL constraint violation would otherwise surface as."""
    r = client.post(
        "/register-company-data",
        data={"company_id": company["company_id"], "company_name": "Someone Else", "api_key": "someone-else-key"},
        files={"model_path": ("m2.pt", b"d"), "embed_path": ("e2.pt", b"d")},
        headers={"X-Admin-Token": admin_token},
    )
    assert r.status_code == 409
    body = r.json()
    assert body["success"] is False
    assert body["message"] == "company_id already registered"
    # error data mirrors the success shape field-for-field, not a subset
    assert set(body["data"][0].keys()) == {
        "company_id",
        "company_name",
        "api_key",
        "model_path",
        "embed_path",
        "data_path",
    }


def test_register_company_stores_api_key_hash_not_plaintext(company):
    """company_data must never store the raw api_key — only
    SHA-256(api_key) (see app/core/security.py:hash_api_key()). Confirms
    directly against the live row (not just "the API still works"), since
    a regression here (e.g. someone reverting to a plain api_key column)
    wouldn't otherwise fail any behavioral test — the API surface looks
    identical either way."""
    import hashlib

    from app.core.db import _query_one

    row = _query_one(
        "SELECT api_key_hash FROM company_data WHERE company_id = %s", (company["company_id"],)
    )
    assert row["api_key_hash"] == hashlib.sha256(company["api_key"].encode("utf-8")).hexdigest()
    assert row["api_key_hash"] != company["api_key"]


def test_register_company_api_key_masked_in_logs(company):
    """logs.message_log stores the full response body for every request
    (see app/main.py:log_requests) — without masking, register-company-data's
    plaintext api_key would end up there (and later in the CSV log
    archive) even though company_data itself only ever stores a hash.
    Regression check for app/main.py:_mask_api_key()."""
    from app.core.db import _query_one

    row = _query_one(
        "SELECT message_log FROM logs WHERE company_id = %s AND url_api = 'register-company-data' "
        "ORDER BY log_id DESC LIMIT 1",
        (company["company_id"],),
    )
    assert row is not None
    assert '"api_key": "***"' in row["message_log"]
    assert company["api_key"] not in row["message_log"]


def test_register_company_admin_token_fail_closed(client, monkeypatch):
    """If admin_token isn't configured at all, the endpoint must reject
    EVERY caller (503) rather than silently accepting anyone — see
    app/api/routes/company.py:require_admin_token."""
    from app.core.config import settings

    monkeypatch.setattr(settings, "admin_token", "")
    r = client.post(
        "/register-company-data",
        data={"company_id": "SHOULDNOTEXIST", "company_name": "X", "api_key": "x"},
        files={"model_path": ("m.pt", b"d"), "embed_path": ("e.pt", b"d")},
    )
    assert r.status_code == 503
    assert r.json()["message"] == "Admin token is not configured on this server"


def test_register_company_wrong_admin_token_is_401(client):
    r = client.post(
        "/register-company-data",
        data={"company_id": "SHOULDNOTEXIST2", "company_name": "X", "api_key": "x"},
        files={"model_path": ("m.pt", b"d"), "embed_path": ("e.pt", b"d")},
        headers={"X-Admin-Token": "wrong"},
    )
    assert r.status_code == 401
    assert r.json()["message"] == "Missing or invalid X-Admin-Token"


# --- register/view/delete-template-data -------------------------------------


def test_register_template_data_success(client, company):
    tag = _tag("TAG")
    r = client.post(
        "/register-template-data",
        data={"customer_tag_id": tag},
        files={
            "image": ("t.png", png_bytes(), "image/png"),
            "customer_tag_data": ("t.json", json.dumps({"SKU1": 2, "SKU2": 3}).encode(), "application/json"),
        },
        headers=company["headers"],
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["data"][0]["customer_tag_data"] == {"SKU1": 2, "SKU2": 3}
    assert body["data"][0]["template_image_path"]


def test_register_template_data_customer_tag_data_must_be_json_file(client, company):
    """customer_tag_data is a file upload, not a text form field — omitting
    it must 422, not silently accept a plain string field."""
    tag = _tag("TAG")
    r = client.post(
        "/register-template-data",
        data={"customer_tag_id": tag, "customer_tag_data": json.dumps({"SKU1": 1})},
        files={"image": ("t.png", png_bytes(), "image/png")},
        headers=company["headers"],
    )
    assert r.status_code == 422


def test_register_template_data_non_int_value_is_400(client, company):
    tag = _tag("TAG")
    r = client.post(
        "/register-template-data",
        data={"customer_tag_id": tag},
        files={
            "image": ("t.png", png_bytes(), "image/png"),
            "customer_tag_data": ("t.json", json.dumps({"SKU1": "two"}).encode(), "application/json"),
        },
        headers=company["headers"],
    )
    assert r.status_code == 400
    assert "must be an integer" in r.json()["message"]


def test_register_template_data_invalid_image_is_400(client, company):
    tag = _tag("TAG")
    r = client.post(
        "/register-template-data",
        data={"customer_tag_id": tag},
        files={
            "image": ("t.png", b"not an image", "image/png"),
            "customer_tag_data": ("t.json", b"{}", "application/json"),
        },
        headers=company["headers"],
    )
    assert r.status_code == 400
    assert r.json()["message"] == "Invalid image file"


def test_view_template_data_lists_registered_tags(client, company):
    tag = _tag("TAG")
    client.post(
        "/register-template-data",
        data={"customer_tag_id": tag},
        files={
            "image": ("t.png", png_bytes(), "image/png"),
            "customer_tag_data": ("t.json", b'{"SKU1": 1}', "application/json"),
        },
        headers=company["headers"],
    )
    r = client.get("/view-template-data", headers=company["headers"])
    assert r.status_code == 200
    assert any(item["customer_tag_id"] == tag for item in r.json()["data"])


def test_view_template_data_pagination(client, company):
    tag = _tag("TAG")
    for value in range(3):
        _register_template(client, company, tag, {"SKU1": value})

    total = client.get("/view-template-data", headers=company["headers"]).headers["x-total-count"]

    r = client.get("/view-template-data", params={"limit": 1, "offset": 0}, headers=company["headers"])
    assert r.status_code == 200
    assert len(r.json()["data"]) == 1
    assert r.headers["x-total-count"] == total

    r = client.get("/view-template-data", params={"limit": 1, "offset": int(total)}, headers=company["headers"])
    assert r.json()["data"] == []  # past the last row, still 200 with an empty page

    r = client.get("/view-template-data", params={"limit": 0}, headers=company["headers"])
    assert r.status_code == 422  # limit=0 rejected, not treated as "unlimited"

    r = client.get("/view-template-data", params={"limit": 201}, headers=company["headers"])
    assert r.status_code == 422  # above _MAX_LIMIT


def test_delete_template_data_unknown_tag_is_404(client, company):
    r = client.delete("/delete-template-data/NOPE_DOES_NOT_EXIST", headers=company["headers"])
    assert r.status_code == 404
    assert r.json()["message"] == "customer_tag_id missing"


def test_delete_template_data_removes_full_history(client, company):
    tag = _tag("TAG")
    for value in (1, 2):
        client.post(
            "/register-template-data",
            data={"customer_tag_id": tag},
            files={
                "image": ("t.png", png_bytes(), "image/png"),
                "customer_tag_data": ("t.json", json.dumps({"SKU1": value}).encode(), "application/json"),
            },
            headers=company["headers"],
        )

    r = client.delete(f"/delete-template-data/{tag}", headers=company["headers"])
    assert r.status_code == 200
    assert len(r.json()["data"]) == 2  # both history rows, not just the latest

    # gone afterward
    r = client.get("/view-template-data", headers=company["headers"])
    assert not any(item["customer_tag_id"] == tag for item in r.json()["data"])


# --- register/view/delete-store-data -----------------------------------------


def _register_template(client, company, tag, sku_counts):
    r = client.post(
        "/register-template-data",
        data={"customer_tag_id": tag},
        files={
            "image": ("t.png", png_bytes(), "image/png"),
            "customer_tag_data": ("t.json", json.dumps(sku_counts).encode(), "application/json"),
        },
        headers=company["headers"],
    )
    assert r.status_code == 200, r.text


def _register_store(client, company, store_id, store_name, tag):
    r = client.post(
        "/register-store-data",
        data={"store_id": store_id, "store_name": store_name, "customer_tag_id": tag},
        headers=company["headers"],
    )
    assert r.status_code == 200, r.text


def test_register_store_data_unknown_tag_is_404(client, company):
    r = client.post(
        "/register-store-data",
        data={"store_id": _tag("S"), "store_name": "Store X", "customer_tag_id": "NOPE_NOT_REGISTERED"},
        headers=company["headers"],
    )
    assert r.status_code == 404
    assert r.json()["message"] == "customer_tag_id missing"


def test_register_store_data_success_and_duplicates(client, company):
    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    store_id = _tag("S")

    r = client.post(
        "/register-store-data",
        data={"store_id": store_id, "store_name": "Store One", "customer_tag_id": tag},
        headers=company["headers"],
    )
    assert r.status_code == 200, r.text

    # duplicate store_id (same company) -> 409
    r = client.post(
        "/register-store-data",
        data={"store_id": store_id, "store_name": "Different Name", "customer_tag_id": tag},
        headers=company["headers"],
    )
    assert r.status_code == 409
    assert "store_id" in r.json()["message"]

    # duplicate store_name (different store_id, same company) -> 409
    r = client.post(
        "/register-store-data",
        data={"store_id": _tag("S"), "store_name": "Store One", "customer_tag_id": tag},
        headers=company["headers"],
    )
    assert r.status_code == 409
    assert "store_name" in r.json()["message"]


def test_view_store_data_includes_store_image_path(client, company):
    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    store_id = _tag("S")
    _register_store(client, company, store_id, f"Store {store_id}", tag)
    r = client.get("/view-store-data", headers=company["headers"])
    assert r.status_code == 200
    item = next(i for i in r.json()["data"] if i["store_id"] == store_id)
    assert "store_image_path" in item


def test_view_store_data_pagination(client, company):
    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    for _ in range(3):
        store_id = _tag("S")
        _register_store(client, company, store_id, f"Store {store_id}", tag)

    total = client.get("/view-store-data", headers=company["headers"]).headers["x-total-count"]

    r = client.get("/view-store-data", params={"limit": 1, "offset": 0}, headers=company["headers"])
    assert r.status_code == 200
    assert len(r.json()["data"]) == 1
    assert r.headers["x-total-count"] == total

    r = client.get("/view-store-data", params={"limit": 201}, headers=company["headers"])
    assert r.status_code == 422  # above _MAX_LIMIT


def test_delete_store_data_unknown_is_404(client, company):
    r = client.delete("/delete-store-data/NOPE_NOT_REGISTERED", headers=company["headers"])
    assert r.status_code == 404


def test_delete_store_data_success(client, company):
    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    store_id = _tag("S")
    _register_store(client, company, store_id, f"Store {store_id}", tag)
    r = client.delete(f"/delete-store-data/{store_id}", headers=company["headers"])
    assert r.status_code == 200
    assert r.json()["data"][0]["store_id"] == store_id


# --- test-detect --------------------------------------------------------------


def test_test_detect_success_and_not_logged(client, company, stub_pipeline):
    from app.core.db import _query_all

    before = _query_all("SELECT COUNT(*) c FROM logs WHERE company_id = %s", (company["company_id"],))[0]["c"]
    with stub_pipeline(["SKU1", "SKU1"]):
        r = client.post("/test-detect", files={"image": ("t.png", png_bytes(), "image/png")}, headers=company["headers"])
    assert r.status_code == 200, r.text
    assert r.json()["data"][0]["total_item"] == 2
    assert r.json()["data"][0]["total_product"] == 1

    after = _query_all("SELECT COUNT(*) c FROM logs WHERE company_id = %s", (company["company_id"],))[0]["c"]
    assert after == before, "/test-detect must never write a logs row"


def test_test_detect_and_input_md_consume_api_limit(client, company, stub_pipeline):
    from app.core.db import peek_api_limit

    before = peek_api_limit(company["company_id"])
    with stub_pipeline(["SKU1"]):
        r = client.post("/test-detect", files={"image": ("t.png", png_bytes(), "image/png")}, headers=company["headers"])
    assert r.status_code == 200, r.text
    assert peek_api_limit(company["company_id"]) == before - 1  # 1 photo, 1 unit

    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    store_id = _tag("S")
    _register_store(client, company, store_id, f"Store {store_id}", tag)

    before = peek_api_limit(company["company_id"])
    with stub_pipeline(["SKU1"]):
        r = client.post(
            "/input-md",
            params={"customer_tag_id": tag, "store_id": store_id},
            files=[
                ("images", ("m1.png", png_bytes(), "image/png")),
                ("images", ("m2.png", png_bytes(), "image/png")),
                ("images", ("m3.png", png_bytes(), "image/png")),
            ],
            headers=company["headers"],
        )
    assert r.status_code == 200, r.text
    assert peek_api_limit(company["company_id"]) == before - 3  # 3 photos, 3 units


def test_api_limit_exceeded_is_403_and_topup_restores_access(client, company, stub_pipeline, admin_token):
    from app.core.config import settings
    from app.core.db import _execute, peek_api_limit

    # Borrow the shared session company but drive its api_limit down to a
    # known small number, then restore it afterward — safe because this
    # test controls the exact before/after values and every other test in
    # the session either doesn't touch api_limit or only decrements it
    # (never depends on an exact absolute value).
    original = peek_api_limit(company["company_id"])
    _execute(f"UPDATE {settings.mysql_table} SET api_limit = 1 WHERE company_id = %s", (company["company_id"],))
    try:
        with stub_pipeline(["SKU1"]):
            r = client.post("/test-detect", files={"image": ("t.png", png_bytes(), "image/png")}, headers=company["headers"])
        assert r.status_code == 200, r.text
        assert peek_api_limit(company["company_id"]) == 0

        with stub_pipeline(["SKU1"]):
            r = client.post("/test-detect", files={"image": ("t.png", png_bytes(), "image/png")}, headers=company["headers"])
        assert r.status_code == 403
        assert "limit" in r.json()["message"].lower()

        r = client.post(
            "/topup-api-limit",
            data={"company_id": company["company_id"], "amount": 5},
            headers={"X-Admin-Token": admin_token},
        )
        assert r.status_code == 200, r.text
        assert r.json()["data"][0]["api_limit"] == 5

        with stub_pipeline(["SKU1"]):
            r = client.post("/test-detect", files={"image": ("t.png", png_bytes(), "image/png")}, headers=company["headers"])
        assert r.status_code == 200, r.text
        assert peek_api_limit(company["company_id"]) == 4
    finally:
        _execute(f"UPDATE {settings.mysql_table} SET api_limit = %s WHERE company_id = %s", (original, company["company_id"]))


def test_topup_api_limit_wrong_admin_token_is_401(client, company):
    r = client.post("/topup-api-limit", data={"company_id": company["company_id"], "amount": 5}, headers={"X-Admin-Token": "wrong"})
    assert r.status_code == 401


def test_topup_api_limit_unknown_company_is_404(client, admin_token):
    r = client.post("/topup-api-limit", data={"company_id": "NOPE_NOT_REGISTERED", "amount": 5}, headers={"X-Admin-Token": admin_token})
    assert r.status_code == 404


def test_topup_api_limit_non_positive_amount_is_422(client, company, admin_token):
    r = client.post(
        "/topup-api-limit", data={"company_id": company["company_id"], "amount": 0}, headers={"X-Admin-Token": admin_token}
    )
    assert r.status_code == 422


# --- input-md ------------------------------------------------------------------


def test_input_md_multi_photo_and_compliance_score(client, company, stub_pipeline):
    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 2, "SKU2": 3, "SKU3": 4})
    store_id = _tag("S")
    _register_store(client, company, store_id, f"Store {store_id}", tag)

    # detects 1x SKU1 (under must_have=2, still "present") and 3x SKU2
    # (exact match); SKU3 never appears -> missing_product.
    with stub_pipeline(["SKU1", "SKU2", "SKU2", "SKU2"]):
        r = client.post(
            "/input-md",
            params={"customer_tag_id": tag, "store_id": store_id},
            files=[
                ("images", ("m1.png", png_bytes(), "image/png")),
                ("images", ("m2.png", png_bytes(), "image/png")),
            ],
            headers=company["headers"],
        )
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert len(data) == 2  # one result per uploaded photo
    for item in data:
        assert item["compliance_score"] == 66.67  # round((3-1)/3*100, 2)
        assert item["missing_product"] == [{"product_id": "SKU3"}]
    # each photo's saved file is distinct — no filename collision
    assert data[0]["image_path"] != data[1]["image_path"]


def test_input_md_all_or_nothing_on_invalid_photo(client, company, stub_pipeline, tmp_path):
    from pathlib import Path

    from app.core.config import settings

    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    store_id = _tag("S")
    _register_store(client, company, store_id, f"Store {store_id}", tag)
    md_dir = settings.uploads_dir / "md_data" / company["company_name"] / tag / f"{store_id}_Store_{store_id}"

    with stub_pipeline(["SKU1"]):
        r = client.post(
            "/input-md",
            params={"customer_tag_id": tag, "store_id": store_id},
            files=[
                ("images", ("ok.png", png_bytes(), "image/png")),
                ("images", ("bad.png", b"not an image", "image/png")),
            ],
            headers=company["headers"],
        )
    assert r.status_code == 400
    assert r.json()["message"] == "Invalid image file"
    saved = list(md_dir.glob("*.png")) if md_dir.exists() else []
    assert saved == [], "no file from either photo should be saved when one of them is invalid"


def test_input_md_unknown_store_is_404(client, company, stub_pipeline):
    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    with stub_pipeline(["SKU1"]):
        r = client.post(
            "/input-md",
            params={"customer_tag_id": tag, "store_id": "NOPE_NOT_REGISTERED"},
            files={"images": ("m.png", png_bytes(), "image/png")},
            headers=company["headers"],
        )
    assert r.status_code == 404
    assert r.json()["message"] == "Unknown store_id"


# --- view-store-image ----------------------------------------------------------


def test_view_store_image_before_and_after_input_md(client, company, stub_pipeline):
    tag = _tag("TAG")
    _register_template(client, company, tag, {"SKU1": 1})
    store_id = _tag("S")
    _register_store(client, company, store_id, f"Store {store_id}", tag)

    r = client.get("/view-store-image", params={"store_id": store_id}, headers=company["headers"])
    assert r.status_code == 404
    assert r.json()["message"] == "No image has been uploaded yet"
    # store_name/customer_tag_id still resolved even though there's no image yet
    assert r.json()["data"][0]["store_name"] == f"Store {store_id}"
    assert r.json()["data"][0]["customer_tag_id"] == tag

    with stub_pipeline(["SKU1"]):
        client.post(
            "/input-md",
            params={"customer_tag_id": tag, "store_id": store_id},
            files={"images": ("m.png", png_bytes(), "image/png")},
            headers=company["headers"],
        )

    r = client.get("/view-store-image", params={"store_id": store_id}, headers=company["headers"])
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/json")
    assert r.json()["data"][0]["store_image_path"].endswith(".png")


def test_view_store_image_unknown_store_is_404(client, company):
    r = client.get("/view-store-image", params={"store_id": "NOPE_NOT_REGISTERED"}, headers=company["headers"])
    assert r.status_code == 404
    assert r.json()["message"] == "Unknown store_id"


# --- cross-cutting: auth & error-shape consistency ---------------------------


def test_missing_api_key_is_401_with_full_error_shape(client):
    r = client.get("/view-store-data")
    assert r.status_code == 401
    body = r.json()
    assert body["success"] is False
    assert body["message"] == "Missing API key"
    assert set(body["data"][0].keys()) == {"company_id", "store_id", "store_name", "customer_tag_id", "store_image_path"}


def test_invalid_api_key_is_401(client):
    r = client.get("/view-template-data", headers={"X-API-Key": "not-a-real-key"})
    assert r.status_code == 401
    assert r.json()["message"] == "Invalid API key"


# --- /health -------------------------------------------------------------------


def test_health_ok_when_db_reachable(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "database": "ok"}


def test_health_503_when_db_unreachable(client):
    """/health must reflect real DB connectivity, not just "the process is
    running" — an orchestrator (k8s probe, load balancer) needs this to
    decide whether to route traffic here or restart the container."""
    import pymysql

    import app.core.db as db

    with mock.patch.object(db, "_connect", side_effect=pymysql.err.OperationalError(2003, "Can't connect")):
        r = client.get("/health")
    assert r.status_code == 503
    assert r.json()["success"] is False

    # recovers on its own once the DB is reachable again, no restart needed
    r = client.get("/health")
    assert r.status_code == 200
