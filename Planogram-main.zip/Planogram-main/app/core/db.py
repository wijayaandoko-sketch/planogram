import json
import random
import time
from typing import Callable, TypeVar

import pymysql
from dbutils.pooled_db import PooledDB
from fastapi import HTTPException
from pymysql.cursors import DictCursor

from app.core.config import settings
from app.core.security import hash_api_key

_DUPLICATE_ENTRY_ERRNO = 1062

# Purely timing-based MySQL errors — deadlock, lock wait timeout, a
# dropped/refused connection, or the server briefly out of connection
# slots — where a retry a moment later often just works, unlike a
# duplicate-key violation (a permanent conflict that no amount of
# retrying will ever resolve, so it's deliberately NOT in this set — see
# _DUPLICATE_ENTRY_ERRNO handling below).
_RETRYABLE_ERRNOS = {
    1040,  # Too many connections
    1205,  # Lock wait timeout exceeded
    1213,  # Deadlock found when trying to get lock
    2003,  # Can't connect to MySQL server
    2006,  # MySQL server has gone away
    2013,  # Lost connection to MySQL server during query
}

_COLUMNS = "company_id, company_name, model_path, embed_path, data_path"

_T = TypeVar("_T")

# A pool of reusable connections instead of opening+closing a fresh one
# per query (see README.md "Connection pooling") — every caller below
# still does conn.close() in a finally block exactly as before, but on a
# pooled connection that returns it to the pool for reuse rather than
# actually tearing down the TCP+auth handshake each time. One pool per
# process — with multiple uvicorn workers, each process gets its own,
# each capped at mysql_pool_max_connections.
_pool = PooledDB(
    creator=pymysql,
    # mincached=0 — don't connect eagerly when the pool is created (i.e. at
    # app import time). With mincached>0, PooledDB opens connections right
    # away, so if MySQL isn't reachable yet at that exact moment (e.g. the
    # API container starts before MySQL finishes booting), the app would
    # fail to start at all instead of starting fine and just 503-ing on
    # DB-touching requests until MySQL comes up — the same graceful
    # degradation the un-pooled per-query connect() had before.
    mincached=0,
    maxcached=5,
    maxconnections=settings.mysql_pool_max_connections,
    blocking=True,
    ping=1,  # verify a connection is still alive before handing it out, reconnect if not
    host=settings.mysql_host,
    port=settings.mysql_port,
    user=settings.mysql_user,
    password=settings.mysql_password,
    database=settings.mysql_database,
    cursorclass=DictCursor,
    connect_timeout=5,
)


def _connect():
    return _pool.connection()


def _with_retry(fn: Callable[[], _T]) -> _T:
    """Runs one full connect-execute-close attempt (fn), retrying it up to
    settings.mysql_retry_max_attempts times if it fails with one of
    _RETRYABLE_ERRNOS — a deadlock/lock-timeout always means the attempt's
    transaction was never committed (fn's own conn.commit() only runs after
    cursor.execute() returns without error), and a dropped/refused
    connection means nothing was sent at all — so retrying never risks
    double-applying a write. Every other error (including a genuine
    duplicate-key conflict) is raised immediately on the first attempt,
    since retrying it would just fail the same way forever.

    Delay before each retry doubles from mysql_retry_base_delay_seconds
    with a little random jitter mixed in (avoids many callers retrying in
    lockstep and re-colliding on the same lock). pymysql has no async
    driver, so this does briefly block the calling thread — kept
    deliberately short (tens of milliseconds) rather than eliminated, and
    only ever happens on the rare transient-error path, not on every call.
    """
    # max(1, ...) guards against a misconfigured mysql_retry_max_attempts
    # of 0 or negative (e.g. a bad env var) — without it, the loop body
    # would never run and the AssertionError below would leak out instead
    # of the exception any caller here actually knows how to handle.
    max_attempts = max(1, settings.mysql_retry_max_attempts)
    for attempt in range(max_attempts):
        try:
            return fn()
        except pymysql.MySQLError as exc:
            is_last_attempt = attempt == max_attempts - 1
            is_retryable = bool(exc.args) and exc.args[0] in _RETRYABLE_ERRNOS
            if is_last_attempt or not is_retryable:
                raise
            # max(0.0, ...) guards against a misconfigured negative
            # mysql_retry_base_delay_seconds — time.sleep() raises
            # ValueError on a negative duration, which isn't a
            # pymysql.MySQLError so it wouldn't be caught by any caller
            # here and would leak out as a raw 500 instead.
            delay = max(0.0, settings.mysql_retry_base_delay_seconds * (2**attempt))
            time.sleep(delay + random.uniform(0, delay))
    raise AssertionError("unreachable")  # pragma: no cover


def _query_one(sql: str, params: tuple) -> dict | None:
    def _do() -> dict | None:
        conn = _connect()
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
                return cursor.fetchone()
        finally:
            conn.close()

    try:
        return _with_retry(_do)
    except pymysql.MySQLError as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}") from exc


def _query_all(sql: str, params: tuple) -> list[dict]:
    def _do() -> list[dict]:
        conn = _connect()
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
                return list(cursor.fetchall())
        finally:
            conn.close()

    try:
        return _with_retry(_do)
    except pymysql.MySQLError as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}") from exc


def _execute(sql: str, params: tuple) -> None:
    def _do() -> None:
        conn = _connect()
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
            conn.commit()
        finally:
            conn.close()

    try:
        _with_retry(_do)
    except pymysql.err.IntegrityError as exc:
        # A route-level duplicate check (SELECT then INSERT) isn't atomic —
        # two concurrent requests for the same company_id/store_id/etc. can
        # both pass the check before either commits. The loser then hits
        # this UNIQUE/PRIMARY KEY violation, which without this branch would
        # fall through to the generic 503 below instead of a 409 conflict.
        # _with_retry already didn't retry this (not in _RETRYABLE_ERRNOS) —
        # retrying a duplicate-key error would just fail the same way again.
        if exc.args and exc.args[0] == _DUPLICATE_ENTRY_ERRNO:
            raise HTTPException(status_code=409, detail="Duplicate entry — already registered") from exc
        raise HTTPException(status_code=503, detail=f"Database error: {exc}") from exc
    except pymysql.MySQLError as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}") from exc


def _execute_rowcount(sql: str, params: tuple) -> int:
    """Returns affected row count — used by UPDATE/DELETE callers to tell
    "matched nothing" (0) apart from "matched and changed" (>0), so they
    can raise a 404 instead of silently no-op'ing."""

    def _do() -> int:
        conn = _connect()
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
                rowcount = cursor.rowcount
            conn.commit()
            return rowcount
        finally:
            conn.close()

    try:
        return _with_retry(_do)
    except pymysql.err.IntegrityError as exc:
        # Same race as _execute above — a rename (new_store_id/
        # new_customer_tag_id) can lose a concurrent race against another
        # request claiming the same value between the route's pre-check and
        # this UPDATE.
        if exc.args and exc.args[0] == _DUPLICATE_ENTRY_ERRNO:
            raise HTTPException(status_code=409, detail="Duplicate entry — already registered") from exc
        raise HTTPException(status_code=503, detail=f"Database error: {exc}") from exc
    except pymysql.MySQLError as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}") from exc


def ping() -> None:
    """Trivial connectivity check for GET /health — runs a real query
    through the same pool/retry path every other DB call uses, so it
    reflects "can this process actually reach and query MySQL right now",
    not just "is a hostname configured". Raises the same 503 as any other
    DB call on failure (via _query_one) — no special-casing needed."""
    _query_one("SELECT 1", ())


def fetch_company_by_api_key(api_key: str) -> dict | None:
    """api_key is the plaintext value from the client's X-API-Key header —
    company_data never stores that value itself, only SHA-256(api_key)
    (see app/core/security.py), so the lookup re-hashes it here and
    matches against api_key_hash instead."""
    return _query_one(
        f"SELECT {_COLUMNS} FROM {settings.mysql_table} WHERE api_key_hash = %s", (hash_api_key(api_key),)
    )


def fetch_company_by_id(company_id: str) -> dict | None:
    return _query_one(f"SELECT {_COLUMNS} FROM {settings.mysql_table} WHERE company_id = %s", (company_id,))


def fetch_company_by_name(company_name: str) -> dict | None:
    """company_name has a UNIQUE constraint — used to duplicate-check it
    before INSERT (model_path/embed_path/data_path are all derived from
    company_name, so a unique company_name is enough to guarantee those
    three stay unique too)."""
    return _query_one(f"SELECT company_id FROM {settings.mysql_table} WHERE company_name = %s", (company_name,))


def insert_company(
    company_id: str,
    company_name: str,
    api_key: str,
    model_path: str,
    embed_path: str,
    data_path: str,
) -> None:
    _execute(
        f"INSERT INTO {settings.mysql_table} "
        "(company_id, company_name, api_key_hash, model_path, embed_path, data_path) "
        "VALUES (%s, %s, %s, %s, %s, %s)",
        (company_id, company_name, hash_api_key(api_key), model_path, embed_path, data_path),
    )


def peek_api_limit(company_id: str) -> int:
    """Read-only, best-effort check used to reject an obviously-out-of-quota
    request BEFORE running detection (no point decoding an image or
    running the model for a call that can't be charged) — NOT what
    actually enforces the limit (that's consume_api_limit(), called after
    success). A company could still race past this check under concurrent
    requests; consume_api_limit()'s atomic UPDATE is what makes the final
    outcome correct regardless."""
    row = _query_one(f"SELECT api_limit FROM {settings.mysql_table} WHERE company_id = %s", (company_id,))
    return row["api_limit"] if row else 0


def consume_api_limit(company_id: str, amount: int) -> bool:
    """Atomically checks-and-decrements api_limit in one statement (rather
    than reading the current value, checking it in Python, then issuing a
    separate UPDATE) — that read-then-write pattern would race under
    concurrent requests for the same company, letting more get through
    than the quota allows. The WHERE clause makes MySQL itself the single
    source of truth: it only decrements (and this only returns True) if
    api_limit was already >= amount at the moment of the UPDATE, so two
    simultaneous calls can never both succeed past the last unit of quota.
    Returns False (no row changed, nothing decremented) if the company is
    out of quota — the caller is expected to reject the request with that
    outcome rather than run detection it can't charge for."""
    rowcount = _execute_rowcount(
        f"UPDATE {settings.mysql_table} SET api_limit = api_limit - %s WHERE company_id = %s AND api_limit >= %s",
        (amount, company_id, amount),
    )
    return rowcount > 0


def topup_api_limit(company_id: str, amount: int) -> int | None:
    """Adds amount to the company's current api_limit and returns the new
    total — None if company_id doesn't exist (caller raises 404)."""
    rowcount = _execute_rowcount(
        f"UPDATE {settings.mysql_table} SET api_limit = api_limit + %s WHERE company_id = %s",
        (amount, company_id),
    )
    if rowcount == 0:
        return None
    row = _query_one(f"SELECT api_limit FROM {settings.mysql_table} WHERE company_id = %s", (company_id,))
    return row["api_limit"]


def fetch_latest_template_tag(company_id: str, customer_tag_id: str) -> dict | None:
    """Most recent template_data row for this (company_id, customer_tag_id)
    — customer_tag_id isn't unique (a tag accumulates history), so
    "current" means latest by created_at. Includes created_at/
    template_image_path (not just customer_tag_data) so callers that need
    to update this exact row in place — PUT /update-template-data — don't
    need a second query: (company_id, customer_tag_id, created_at) is the
    row's primary key (there's no separate template_id column)."""
    return _query_one(
        f"SELECT customer_tag_data, template_image_path, created_at "
        f"FROM {settings.mysql_template_table} "
        "WHERE company_id = %s AND customer_tag_id = %s "
        "ORDER BY created_at DESC LIMIT 1",
        (company_id, customer_tag_id),
    )


def insert_template_tag(
    company_id: str,
    company_name: str,
    customer_tag_id: str,
    customer_tag_data: str,
    template_image_path: str | None = None,
) -> None:
    _execute(
        f"INSERT INTO {settings.mysql_template_table} "
        "(company_id, company_name, customer_tag_id, customer_tag_data, template_image_path) "
        "VALUES (%s, %s, %s, %s, %s)",
        (company_id, company_name, customer_tag_id, customer_tag_data, template_image_path),
    )


def list_templates(company_id: str, limit: int, offset: int) -> list[dict]:
    """One page of history for this company, newest first — see
    count_templates() for the total row count (used for the
    X-Total-Count response header, not returned in this list itself)."""
    return _query_all(
        f"SELECT customer_tag_id, customer_tag_data, template_image_path, created_at "
        f"FROM {settings.mysql_template_table} WHERE company_id = %s ORDER BY created_at DESC LIMIT %s OFFSET %s",
        (company_id, limit, offset),
    )


def count_templates(company_id: str) -> int:
    row = _query_one(
        f"SELECT COUNT(*) AS c FROM {settings.mysql_template_table} WHERE company_id = %s", (company_id,)
    )
    return row["c"]


def fetch_templates_by_tag(company_id: str, customer_tag_id: str) -> list[dict]:
    """Every row (full history) for this tag — used by
    DELETE /delete-template-data/{customer_tag_id} to capture what's
    about to be removed, before it's actually deleted."""
    return _query_all(
        f"SELECT company_id, company_name, customer_tag_id, customer_tag_data, template_image_path, created_at "
        f"FROM {settings.mysql_template_table} WHERE company_id = %s AND customer_tag_id = %s "
        "ORDER BY created_at DESC",
        (company_id, customer_tag_id),
    )


def delete_templates_by_tag(company_id: str, customer_tag_id: str) -> int:
    """customer_tag_id isn't unique in template_data (a tag accumulates
    history) — this deletes every row for the tag, not just one."""
    return _execute_rowcount(
        f"DELETE FROM {settings.mysql_template_table} WHERE company_id = %s AND customer_tag_id = %s",
        (company_id, customer_tag_id),
    )


def fetch_store(company_id: str, store_id: str, customer_tag_id: str) -> dict | None:
    """A store only validates if it belongs to this company AND is
    assigned to this exact customer_tag_id — any mismatch (wrong company,
    wrong tag, or store_id that doesn't exist at all) is indistinguishable
    from the caller's side, same "Unknown store_id" either way."""
    return _query_one(
        f"SELECT store_name FROM {settings.mysql_store_table} "
        "WHERE company_id = %s AND store_id = %s AND customer_tag_id = %s",
        (company_id, store_id, customer_tag_id),
    )


def fetch_store_by_id(company_id: str, store_id: str) -> dict | None:
    """Existence check used by POST /register-store — ignores
    customer_tag_id since store_id is unique per company_id regardless of
    which tag it's assigned to (store_data's primary key)."""
    return _query_one(
        f"SELECT store_name, customer_tag_id FROM {settings.mysql_store_table} "
        "WHERE company_id = %s AND store_id = %s",
        (company_id, store_id),
    )


def fetch_store_by_name(company_id: str, store_name: str) -> dict | None:
    """store_name is UNIQUE per company_id (not across all companies —
    different companies can reuse the same store_name) — used to
    duplicate-check it before INSERT/UPDATE."""
    return _query_one(
        f"SELECT store_id FROM {settings.mysql_store_table} WHERE company_id = %s AND store_name = %s",
        (company_id, store_name),
    )


def insert_store(
    company_id: str,
    company_name: str,
    store_id: str,
    store_name: str,
    customer_tag_id: str,
) -> None:
    _execute(
        f"INSERT INTO {settings.mysql_store_table} "
        "(company_id, company_name, store_id, store_name, customer_tag_id) "
        "VALUES (%s, %s, %s, %s, %s)",
        (company_id, company_name, store_id, store_name, customer_tag_id),
    )


def list_stores(company_id: str, limit: int, offset: int) -> list[dict]:
    """One page of stores for this company — see count_stores() for the
    total row count (used for the X-Total-Count response header, not
    returned in this list itself)."""
    return _query_all(
        f"SELECT store_id, store_name, customer_tag_id FROM {settings.mysql_store_table} "
        "WHERE company_id = %s ORDER BY store_id LIMIT %s OFFSET %s",
        (company_id, limit, offset),
    )


def count_stores(company_id: str) -> int:
    row = _query_one(f"SELECT COUNT(*) AS c FROM {settings.mysql_store_table} WHERE company_id = %s", (company_id,))
    return row["c"]


def delete_store(company_id: str, store_id: str) -> int:
    return _execute_rowcount(
        f"DELETE FROM {settings.mysql_store_table} WHERE company_id = %s AND store_id = %s",
        (company_id, store_id),
    )


def insert_log(
    url_api: str,
    company_id: str,
    company_name: str,
    customer_tag_id: str,
    store_id: str,
    store_name: str,
    image_path: str | None,
    message_log: str,
    data_type: str,
    activity: str,
    status: str,
) -> None:
    """url_api is the endpoint path that was hit (e.g. "view-template-data",
    no leading slash) — lets a log row be traced back to which of the
    business endpoints it came from at a glance, without having to infer
    it from the activity/data_type combination. activity
    ("register"/"delete"/"view") + data_type ("template"/"md"/
    "store"/"company") together identify the same thing more granularly
    (e.g. activity="delete", data_type="store" is always
    DELETE /delete-store-data/{store_id})."""
    _execute(
        f"INSERT INTO {settings.mysql_logs_table} "
        "(url_api, company_id, company_name, customer_tag_id, store_id, store_name, image_path, message_log, data_type, activity, status) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
        (
            url_api,
            company_id,
            company_name,
            customer_tag_id,
            store_id,
            store_name,
            image_path,
            message_log,
            data_type,
            activity,
            status,
        ),
    )


def fetch_logs_for_period(start, end) -> list[dict]:
    """All logs rows with company_id + created_at in [start, end) — used by
    scripts/archive_logs.py. Read-only, so it uses the regular
    least-privilege pool (same as every other query here) — only the
    partition DDL that follows a successful export needs the separate
    elevated credentials in app/core/db_admin.py."""
    return _query_all(
        f"SELECT * FROM {settings.mysql_logs_table} WHERE created_at >= %s AND created_at < %s ORDER BY created_at",
        (start, end),
    )


def setup_company(company: dict, templates: list[dict]) -> dict:
    """Creates a company plus its templates in ONE transaction — either
    everything commits, or nothing does. company_data/template_data can
    never end up half-applied relative to each other the way they could
    from doing separate CRUD calls per table.

    An already-existing company_id is not an error — it's skipped, and its
    existing company_name (from the DB) is reused for the templates below,
    so they always match company_data.company_name exactly. New templates
    are plain INSERTs — any DB error rolls back the *entire* call, not
    just that one row, so a partial run never gets committed.
    """
    conn = _connect()
    result: dict = {"company_status": None, "templates": []}
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"SELECT company_name FROM {settings.mysql_table} WHERE company_id = %s",
                (company["company_id"],),
            )
            existing = cursor.fetchone()
            if existing:
                company_name = existing["company_name"]
                result["company_status"] = "already_exists"
            else:
                cursor.execute(
                    f"INSERT INTO {settings.mysql_table} "
                    "(company_id, company_name, api_key_hash, model_path, embed_path, data_path) "
                    "VALUES (%s, %s, %s, %s, %s, %s)",
                    (
                        company["company_id"],
                        company["company_name"],
                        hash_api_key(company["api_key"]),
                        company["model_path"],
                        company["embed_path"],
                        company["data_path"],
                    ),
                )
                company_name = company["company_name"]
                result["company_status"] = "created"

            for template in templates:
                cursor.execute(
                    f"INSERT INTO {settings.mysql_template_table} "
                    "(company_id, company_name, customer_tag_id, customer_tag_data, template_image_path) "
                    "VALUES (%s, %s, %s, %s, %s)",
                    (
                        company["company_id"],
                        company_name,
                        template["customer_tag_id"],
                        json.dumps(template["customer_tag_data"]),
                        template.get("template_image_path"),
                    ),
                )
                result["templates"].append(template["customer_tag_id"])

        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
