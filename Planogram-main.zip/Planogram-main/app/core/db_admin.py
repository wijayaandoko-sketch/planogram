"""Admin-only database helpers for maintenance scripts (currently just
scripts/archive_logs.py) — DDL operations on the `logs` table's monthly
partitions (see schema.sql). Deliberately separate from app/core/db.py:
the app's own runtime user (settings.mysql_user) is least-privilege by
design (SELECT/INSERT/UPDATE/DELETE only, see README.md "Kredensial
database") and does NOT have ALTER, so partition maintenance needs its
own, more privileged credentials — configured only where a script
actually needs them, never used by the running API itself.
"""

import re

import pymysql
from pymysql.cursors import DictCursor

from app.core.config import settings

# Partition names are generated internally (never from request/user input)
# as "p" + YYYYMM, but this is still validated before being interpolated
# into DDL SQL (which can't be parameterized like a normal query value) —
# cheap insurance against ever building a malformed/unsafe ALTER TABLE
# statement from a programming mistake upstream.
_PARTITION_NAME_PATTERN = re.compile(r"^p\d{6}$")


def _validate_partition_name(partition_name: str) -> None:
    if not _PARTITION_NAME_PATTERN.match(partition_name):
        raise ValueError(f"Invalid partition name: {partition_name!r}")


def _admin_connect() -> pymysql.connections.Connection:
    if not settings.mysql_admin_user:
        raise RuntimeError(
            "PLANOGRAM_MYSQL_ADMIN_USER / PLANOGRAM_MYSQL_ADMIN_PASSWORD must be set to run "
            "this script — partition maintenance needs ALTER TABLE, which the app's regular "
            "runtime user (PLANOGRAM_MYSQL_USER) deliberately does not have. See README.md "
            "'Kredensial database' / 'Retensi logs'."
        )
    return pymysql.connect(
        host=settings.mysql_host,
        port=settings.mysql_port,
        user=settings.mysql_admin_user,
        password=settings.mysql_admin_password,
        database=settings.mysql_database,
        cursorclass=DictCursor,
        connect_timeout=5,
    )


def partition_exists(partition_name: str) -> bool:
    _validate_partition_name(partition_name)
    conn = _admin_connect()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT 1 FROM information_schema.PARTITIONS "
                "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND PARTITION_NAME = %s",
                (settings.mysql_database, settings.mysql_logs_table, partition_name),
            )
            return cursor.fetchone() is not None
    finally:
        conn.close()


def carve_month_partition(partition_name: str, next_month_start_unix: int) -> None:
    """Splits the `pmax` catch-all partition (see schema.sql) so
    `partition_name` covers everything up to (not including)
    next_month_start_unix, leaving a fresh `pmax` for everything after —
    i.e. "give this one month its own partition, out of the catch-all
    that new rows have been landing in." Caller must check
    partition_exists() first; REORGANIZE fails if partition_name is
    already there (this isn't itself idempotent, unlike the rest of
    scripts/archive_logs.py's flow)."""
    _validate_partition_name(partition_name)
    conn = _admin_connect()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"ALTER TABLE {settings.mysql_logs_table} REORGANIZE PARTITION pmax INTO "
                f"(PARTITION {partition_name} VALUES LESS THAN ({int(next_month_start_unix)}), "
                "PARTITION pmax VALUES LESS THAN MAXVALUE)"
            )
        conn.commit()
    finally:
        conn.close()


def drop_partition(partition_name: str) -> None:
    """Near-instant metadata-only operation (not a row-by-row DELETE) —
    this is the whole point of partitioning by month instead of just
    running DELETE FROM logs WHERE created_at < ... directly."""
    _validate_partition_name(partition_name)
    conn = _admin_connect()
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"ALTER TABLE {settings.mysql_logs_table} DROP PARTITION {partition_name}")
        conn.commit()
    finally:
        conn.close()
