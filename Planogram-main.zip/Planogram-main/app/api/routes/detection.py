from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel

from app.api.routes._common import ProductGroup, group_by_product, read_image, read_upload_bounded
from app.core.company import CompanyRecord, resolve_company
from app.core.config import settings
from app.core.db import consume_api_limit, peek_api_limit
from app.core.registry import get_pipeline

router = APIRouter(prefix="/test-detect", tags=["detection"])


class TestDetectData(BaseModel):
    company_id: str
    api_limit_consumed: int
    api_limit_remaining: int | None
    total_item: int
    total_product: int
    list_product: list[ProductGroup]


class TestDetectResponse(BaseModel):
    success: bool
    data: list[TestDetectData]
    message: str


@router.post("", response_model=TestDetectResponse)
async def test_detect(
    image: UploadFile = File(...),
    company: CompanyRecord = Depends(resolve_company),
) -> TestDetectResponse:
    """Quick detection test for the caller's company — validation is API
    key only, nothing else. No image is saved to disk and no template
    state is touched — useful for checking a company's model/index
    actually works without persisting anything business-related. Unlike
    every other endpoint, this one is also NOT recorded in the `logs`
    table — app/main.py's request-logging middleware skips it on purpose
    (see the comment above _DATA_TYPE_BY_PREFIX there).

    Consumes 1 unit of the company's api_limit (see company_data.api_limit,
    topped up via POST /topup-api-limit) — only once detection has actually
    succeeded, never for a request that fails validation or errors out.
    A cheap upfront check still rejects an obviously-out-of-quota company
    before it pays the cost of decoding a file or running the model; the
    real enforcement is the atomic decrement at the end, which is what
    actually stays correct under concurrent requests.
    """
    if peek_api_limit(company.company_id) <= 0:
        raise HTTPException(status_code=403, detail="API limit exceeded for this company")

    pil_image = read_image(await read_upload_bounded(image, settings.max_image_upload_bytes, "image"))

    pipeline = get_pipeline(company)
    detections = pipeline.detect_and_recognize(pil_image)
    list_product = group_by_product(detections)

    if not consume_api_limit(company.company_id, 1):
        raise HTTPException(status_code=403, detail="API limit exceeded for this company")

    data = TestDetectData(
        company_id=company.company_id,
        api_limit_consumed=1,
        api_limit_remaining=peek_api_limit(company.company_id),
        total_item=len(detections),
        total_product=len(list_product),
        list_product=list_product,
    )
    return TestDetectResponse(success=True, data=[data], message="SUCCESS")
