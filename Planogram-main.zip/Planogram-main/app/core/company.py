import logging
from dataclasses import dataclass
from pathlib import Path

from fastapi import HTTPException, Security
from fastapi.security import APIKeyHeader

from app.core import db
from app.core.config import settings

logger = logging.getLogger(__name__)

# Registered as a security scheme (not a plain Header dependency) so
# Swagger UI shows an "Authorize" button — the key is entered once and
# reused for every endpoint call, instead of being re-typed per request.
# scheme_name is explicit (not left to default to the class name
# "APIKeyHeader") because app/api/routes/company.py's X-Admin-Token check
# is also an APIKeyHeader instance — without distinct names here, FastAPI's
# OpenAPI generator collapses both into one scheme, and Swagger's Authorize
# dialog ends up showing one merged/wrong field for both.
_api_key_header = APIKeyHeader(name="X-API-Key", scheme_name="ApiKeyAuth", auto_error=False)


@dataclass(frozen=True)
class CompanyRecord:
    company_id: str
    company_name: str
    model_path: Path  # resolved YOLO weights .pt (models_dir / row's model_path)
    embed_path: Path  # resolved embedding checkpoint .pt (models_dir / row's embed_path)
    data_path: Path  # resolved catalog root (data_dir / row's data_path), contains <SKU>/ subfolders


def _to_record(row: dict) -> CompanyRecord:
    # model_path/embed_path/data_path in the DB are relative fragments, e.g.
    # model_path="AICE/product.pt", data_path="catalog/AICE" — resolved here
    # against models_dir/data_dir so the DB doesn't need machine-specific
    # absolute paths.
    return CompanyRecord(
        company_id=row["company_id"],
        company_name=row["company_name"],
        model_path=settings.models_dir / row["model_path"],
        embed_path=settings.models_dir / row["embed_path"],
        data_path=settings.data_dir / row["data_path"],
    )


def _validate_paths(company: CompanyRecord, require_faiss_index: bool = True) -> None:
    """Checks model_path/embed_path/data_path from the company_data row,
    plus (usually) the FAISS index folder — not a DB column, it's a
    company_id-based convention, see faiss_index_dir — all actually exist
    on disk before anything downstream tries to load them. Each bad field
    is named in the error so a typo in one (e.g. data_path) doesn't get
    misread as a problem with a different one (e.g. model_path) — the
    resolved filesystem path itself is only logged server-side, never
    returned to the client, since it'd leak the server's internal
    directory layout.

    Without the FAISS index check, a missing index isn't caught here at
    all — it surfaces later, mid-request, as an unhandled 500 when
    SkuFaissIndex.search() runs (see app/recognition/faiss_index.py),
    instead of a clean 422 up front like the other three fields.

    require_faiss_index=False is for resolve_company_by_id, used by
    scripts/build_index.py — that script's whole job is to create the
    index for the first time, so it can't also require the index to
    already exist."""
    errors: list[str] = []

    if not company.model_path.is_file():
        errors.append("model_path is invalid")
        logger.warning("company %s: model_path not found at %s", company.company_id, company.model_path)
    if not company.embed_path.is_file():
        errors.append("embed_path is invalid")
        logger.warning("company %s: embed_path not found at %s", company.company_id, company.embed_path)
    if not company.data_path.is_dir():
        errors.append("data_path is invalid")
        logger.warning("company %s: data_path not found at %s", company.company_id, company.data_path)

    if require_faiss_index:
        index_dir = faiss_index_dir(company.company_id)
        if not (index_dir / "index.faiss").is_file():
            errors.append("faiss_index is missing — run scripts/build_index.py for this company")
            logger.warning("company %s: faiss index not found at %s", company.company_id, index_dir)

    if errors:
        # Only company_id + the invalid field names go back to the client —
        # never model_path/embed_path/data_path themselves (see docstring).
        raise HTTPException(
            status_code=422,
            detail={
                "company_id": company.company_id,
                "errors": errors,
            },
        )


def resolve_company(api_key: str | None = Security(_api_key_header)) -> CompanyRecord:
    """FastAPI dependency: looks up X-API-Key in the company_data MySQL
    table and returns the matching company's record — its model_path,
    embed_path, and data_path are what CompliancePipeline is built from, so
    a request never touches another company's model or reference data."""
    if not api_key:
        raise HTTPException(status_code=401, detail="Missing API key")
    row = db.fetch_company_by_api_key(api_key)
    if row is None:
        raise HTTPException(status_code=401, detail="Invalid API key")
    company = _to_record(row)
    _validate_paths(company)
    return company


def resolve_company_by_id(company_id: str) -> CompanyRecord:
    """Same lookup as resolve_company, but by company_id — used by scripts
    (e.g. build_index.py) that aren't going through an HTTP request. Does
    NOT require the FAISS index to already exist, since build_index.py's
    job is to create it."""
    row = db.fetch_company_by_id(company_id)
    if row is None:
        raise HTTPException(status_code=404, detail=f"Unknown company_id: {company_id}")
    company = _to_record(row)
    _validate_paths(company, require_faiss_index=False)
    return company


def faiss_index_dir(company_id: str) -> Path:
    return settings.faiss_index_dir / company_id


def uploads_dir(company_id: str) -> Path:
    return settings.uploads_dir / company_id
