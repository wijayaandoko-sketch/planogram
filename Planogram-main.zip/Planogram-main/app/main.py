import json
import logging
import os

# torch and faiss each bundle their own OpenMP runtime on Windows; loading
# both aborts the process (OMP Error #15) unless this is set before either
# is imported. Must stay above the app.api imports below.
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

from fastapi import FastAPI, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIASGIMiddleware

from app.api.routes.api_limit import router as api_limit_router
from app.api.routes.company import router as company_router
from app.api.routes.customer_tag import router as customer_tag_router
from app.api.routes.detection import router as detection_router
from app.api.routes.md import router as md_router
from app.api.routes.store import router as store_router
from app.api.routes.store_data import router as store_data_router
from app.api.routes.store_images import router as store_images_router
from app.api.routes.template_data import router as template_data_router
from app.core.config import settings
from app.core.db import fetch_company_by_api_key, fetch_store_by_id, insert_log, peek_api_limit, ping as ping_db
from app.core.rate_limit import limiter
from app.utils.image_store import company_kind_dir

# Root config for every `logging` call app-wide (uvicorn sets up its own
# separate access-log formatting regardless — this only governs ours, e.g.
# the DB-credentials warning below and unhandled_exception_handler's
# traceback logging further down). Without this, log records still print
# via Python's default last-resort handler, but with no timestamp/level/
# logger-name prefix — hard to tell one line's severity or origin from
# another once there's more than a handful of them.
logging.basicConfig(
    level=settings.log_level,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

app = FastAPI(title="Planogram Compliance Detection", version="0.1.0")

app.state.limiter = limiter
# The ASGI variant, not the BaseHTTPMiddleware-based SlowAPIMiddleware —
# that one only supports SYNCHRONOUS exception handlers, so it silently
# swaps in slowapi's own default {"error": ...} response whenever the
# registered handler is `async def` (ours is, since _build_error_data
# needs to await request.form()) instead of raising or erroring loudly
# about it. This ASGI version awaits async handlers correctly.
app.add_middleware(SlowAPIASGIMiddleware)

# allow_origins=["*"] — any website's browser JS may call this API and
# read the response. Deliberate for this project: every endpoint except
# register-company-data is already gated by X-API-Key (and that one by
# X-Admin-Token), so CORS here is about which frontends MAY read a
# response, not about who's allowed to act — the API key is still the
# real gate either way. allow_credentials stays False (the default) —
# browsers reject a wildcard origin combined with allow_credentials=True,
# and nothing here relies on cookies, so it's never needed.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

if settings.mysql_user == "root" and not settings.mysql_password:
    # Not fatal — a fresh local XAMPP/MySQL install legitimately defaults
    # to this, and blocking startup over it would break that workflow. But
    # root+no-password reaching a real deployment is a real risk (see
    # README.md "Kredensial database"), so at least make it loud in the
    # logs instead of silent.
    logger.warning(
        "MySQL is configured as root with no password (PLANOGRAM_MYSQL_USER/"
        "PLANOGRAM_MYSQL_PASSWORD) — fine for local dev, but a dedicated "
        "least-privilege user is expected before this reaches production. "
        "See README.md 'Kredensial database'."
    )

app.include_router(detection_router)
app.include_router(md_router)
app.include_router(company_router)
app.include_router(customer_tag_router)
app.include_router(store_router)
app.include_router(store_data_router)
app.include_router(template_data_router)
app.include_router(store_images_router)
app.include_router(api_limit_router)


# --- Shared request-context extraction -------------------------------------
#
# Used by both the error-response builder (below) and the request-logging
# middleware (further down) — reconstructing "who/what was this request
# about" from whatever's available, since a failed request may not have
# gotten far enough to have looked anything up yet.

_CONTEXT_FIELDS = ("company_id", "company_name", "customer_tag_id", "store_id", "store_name", "api_key")


async def _extract_context(request: Request, response_body: object) -> dict:
    """Best-effort reconstruction of who/what a request was about, tried
    in order from most to least reliable:
    1. The response body's data[0] (exact values actually used/returned).
    2. URL path params (customer_tag_id/store_id on the *-{id} routes).
    3. Query params (customer_tag_id/store_id on /input-md, /view-store-image).
    4. request.state, for values a route computed but doesn't return in
       its body (e.g. /input-md's saved image_path, or the tag/store_name
       a delete-* call removed).
    5. Submitted form fields (covers failures before anything is looked
       up, e.g. a brand-new company_id/store_id that was rejected).
    6. company_id/company_name resolved fresh from the X-API-Key header,
       if nothing above found them.
    Every step only fills in fields still missing — nothing overwrites a
    value an earlier, more reliable step already found.
    """
    ctx = {field: "" for field in _CONTEXT_FIELDS}
    image_path = None

    if isinstance(response_body, dict):
        data = response_body.get("data")
        if isinstance(data, list) and data and isinstance(data[0], dict):
            item = data[0]
            for field in _CONTEXT_FIELDS:
                value = item.get(field)
                if value:
                    ctx[field] = str(value)
            path_value = item.get("template_image_path")
            if path_value:
                image_path = str(path_value)

    for field in ("customer_tag_id", "store_id"):
        if not ctx[field] and field in request.path_params:
            ctx[field] = str(request.path_params[field])

    for field in ("customer_tag_id", "store_id"):
        if not ctx[field] and field in request.query_params:
            ctx[field] = str(request.query_params[field])

    for field in _CONTEXT_FIELDS:
        if not ctx[field]:
            value = getattr(request.state, field, None)
            if value:
                ctx[field] = str(value)
    if image_path is None:
        image_path = getattr(request.state, "image_path", None)

    if request.method in ("POST", "PUT") and not all(ctx[f] for f in _CONTEXT_FIELDS):
        try:
            form = await request.form()
        except Exception:
            form = None
        if form is not None:
            for field in _CONTEXT_FIELDS:
                if not ctx[field]:
                    value = form.get(field)
                    if isinstance(value, str) and value:
                        ctx[field] = value

    if not ctx["company_id"] or not ctx["company_name"]:
        # Most response bodies only carry company_id (company_name isn't
        # part of those schemas) — resolving via the API key fills in
        # company_name even when company_id was already found above.
        api_key = request.headers.get("x-api-key")
        if api_key:
            try:
                row = fetch_company_by_api_key(api_key)
            except Exception:
                row = None
            if row:
                ctx["company_id"] = row["company_id"]
                ctx["company_name"] = row["company_name"]

    if ctx["company_id"] and ctx["store_id"] and (not ctx["store_name"] or not ctx["customer_tag_id"]):
        try:
            row = fetch_store_by_id(ctx["company_id"], ctx["store_id"])
        except Exception:
            row = None
        if row:
            if not ctx["store_name"]:
                ctx["store_name"] = row["store_name"]
            if not ctx["customer_tag_id"]:
                ctx["customer_tag_id"] = row["customer_tag_id"]

    return {**ctx, "image_path": image_path}


# --- Error response shape ---------------------------------------------------
#
# Every success response already returns {"success": True, "data": [...],
# "message": "SUCCESS"} at the route level (see each router's response
# models). Error responses mirror that SAME shape — every field name that
# endpoint's success data[0] carries is present here too (never a subset),
# populated with whatever was resolved before the failure happened, null
# for anything genuinely unknowable at that point (e.g. total_item on
# /test-detect — detection never ran; model_path on /register-company-data
# — only computed after validation passes). The field lists below are
# each endpoint's success response model, field-for-field.

_ERROR_FIELDS_BY_PREFIX = (
    ("/register-company-data", ("company_id", "company_name", "api_key", "model_path", "embed_path", "data_path")),
    ("/topup-api-limit", ("company_id", "api_limit")),
    ("/test-detect", ("company_id", "api_limit_consumed", "api_limit_remaining", "total_item", "total_product", "list_product")),
    (
        "/input-md",
        (
            "company_id",
            "api_limit_consumed",
            "api_limit_remaining",
            "customer_tag_id",
            "store_id",
            "image_path",
            "total_item",
            "total_product",
            "list_product",
            "missing_product",
            "compliance_score",
        ),
    ),
    ("/register-template-data", ("company_id", "customer_tag_id", "customer_tag_data", "template_image_path")),
    (
        "/view-template-data",
        ("company_id", "customer_tag_id", "customer_tag_data", "template_image_path", "created_at"),
    ),
    (
        "/delete-template-data",
        ("company_id", "company_name", "customer_tag_id", "customer_tag_data", "template_image_path", "created_at"),
    ),
    ("/register-store-data", ("company_id", "store_id", "store_name", "customer_tag_id")),
    ("/view-store-data", ("company_id", "store_id", "store_name", "customer_tag_id", "store_image_path")),
    ("/delete-store-data", ("company_id", "store_id", "store_name", "customer_tag_id")),
    ("/view-store-image", ("company_id", "store_id", "store_name", "customer_tag_id", "store_image_path")),
)

# register-template-data/view-template-data/delete-template-data's
# template_image_path, input-md's image_path, and view-store-data/
# view-store-image's store_image_path are all really the same underlying
# tracked value (see _extract_context's "image_path") — just named
# differently per endpoint's response model, so they share one source here.
_IMAGE_PATH_FIELDS = {"image_path", "template_image_path", "store_image_path"}


async def _build_error_data(request: Request) -> list[dict] | None:
    path = request.url.path
    fields = next((f for prefix, f in _ERROR_FIELDS_BY_PREFIX if path.startswith(prefix)), None)
    if fields is None:
        return None
    ctx = await _extract_context(request, None)
    item = {}
    for field in fields:
        if field == "api_limit_consumed":
            # A failed /test-detect or /input-md call never charges
            # anything (see both routes' docstrings) — always 0 here,
            # regardless of what failed or how far the request got.
            item[field] = 0
        elif field == "api_limit_remaining":
            # Only knowable once company_id itself is known (e.g. a bad/
            # missing API key never resolves a company at all) — null in
            # that case rather than guessing whose limit to report.
            item[field] = peek_api_limit(ctx["company_id"]) if ctx.get("company_id") else None
        else:
            source = "image_path" if field in _IMAGE_PATH_FIELDS else field
            item[field] = ctx.get(source) or None
    return [item]


# These handlers make error responses match the {success, data, message}
# shape above — instead of FastAPI/Starlette's default {"detail": ...} —
# for every HTTPException raised anywhere (401/404/409/422/503, ...),
# every request validation error (missing/malformed body or query
# fields), and any other unhandled exception.
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "data": await _build_error_data(request),
            "message": jsonable_encoder(exc.detail),
        },
        headers=exc.headers,
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        content={
            "success": False,
            "data": await _build_error_data(request),
            "message": jsonable_encoder(exc.errors()),
        },
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    # The `logs` table (via log_requests below) only ever gets str(exc) —
    # one line, no traceback, no file/line info. Without this call, that
    # one line is the ONLY record anywhere of a bug that actually happened
    # in production — logger.exception() prints the full traceback here so
    # it reaches wherever server logs actually go (journald, a cloud log
    # sink, ...), independent of what's in MySQL.
    logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "data": await _build_error_data(request),
            "message": str(exc),
        },
    )


@app.exception_handler(RateLimitExceeded)
async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
    return JSONResponse(
        status_code=429,
        content={
            "success": False,
            "data": await _build_error_data(request),
            "message": f"Rate limit exceeded: {exc.detail}",
        },
    )


# --- Request logging middleware -------------------------------------------
#
# Every business endpoint gets one row in `logs` per call, success or
# error — this is the single place that does it, instead of each route
# writing its own insert_log() call (easy to forget on a new endpoint).
# It runs *around* the exception handlers above, so by the time it sees
# `response` here, any HTTPException/validation error has already been
# turned into the standard {success, data, message} JSON body.

_ACTIVITY_BY_METHOD = {"GET": "view", "POST": "register", "DELETE": "delete"}

# path prefix -> data_type. Order matters: checked with str.startswith(),
# so a prefix that's a substring of another (there are none currently)
# would need the longer one listed first. /test-detect is deliberately
# NOT here — it's a pure test/read call (nothing persisted, see
# app/api/routes/detection.py), not logged at all.
_DATA_TYPE_BY_PREFIX = (
    ("/register-company-data", "company"),
    ("/topup-api-limit", "company"),
    ("/input-md", "md"),
    ("/register-template-data", "template"),
    ("/view-template-data", "template"),
    ("/delete-template-data", "template"),
    ("/register-store-data", "store"),
    ("/view-store-data", "store"),
    ("/delete-store-data", "store"),
    ("/view-store-image", "md"),
)


def _mask_api_key(value: object) -> object:
    """Recursively replaces any "api_key" field's value with a fixed
    placeholder — used only for what gets persisted to logs.message_log
    (and, from there, into the CSV log archive), never for the live HTTP
    response the client actually receives (register-company-data's
    response body still returns the real api_key as-is; only the copy
    written to `logs` below is masked). Without this, the plaintext
    api_key a client just registered would sit in the logs table (and
    later the archive CSVs) forever, defeating the point of storing only
    api_key_hash in company_data — see app/core/security.py."""
    if isinstance(value, dict):
        return {k: ("***" if k == "api_key" else _mask_api_key(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [_mask_api_key(item) for item in value]
    return value


@app.middleware("http")
async def log_requests(request: Request, call_next):
    path = request.url.path
    matched_prefix = next((prefix for prefix, _ in _DATA_TYPE_BY_PREFIX if path.startswith(prefix)), None)
    if matched_prefix is None:
        return await call_next(request)
    data_type = dict(_DATA_TYPE_BY_PREFIX)[matched_prefix]
    # The matched prefix, not the raw path — for update-*/delete-* this
    # strips the dynamic {customer_tag_id}/{store_id} segment, e.g.
    # "/delete-store-data/STR001" -> "delete-store-data", so url_api
    # always identifies the endpoint itself, not one specific call to it.
    url_api = matched_prefix.lstrip("/")

    response = await call_next(request)

    body_bytes = b""
    async for chunk in response.body_iterator:
        body_bytes += chunk if isinstance(chunk, bytes) else chunk.encode()

    try:
        body = json.loads(body_bytes)
    except Exception:
        body = None

    status = "success" if response.status_code < 400 else "failed"
    message_log = json.dumps(_mask_api_key(body)) if isinstance(body, dict) else None
    activity = _ACTIVITY_BY_METHOD.get(request.method, "view")
    ctx = await _extract_context(request, body)

    # image_path means something different depending on activity:
    # register/update/delete touch one specific file (or none, for
    # store_data operations, which have no file at all — stays whatever
    # _extract_context found, usually null) — but view is a read of
    # everything under that company, not any one file, so it points at
    # the company's whole upload folder for this data_type instead
    # (data_type "store"/"company" have no upload folder at all, so it's
    # null there too).
    if activity == "view" and ctx["company_name"] and data_type in ("template", "md"):
        image_path = str(company_kind_dir(data_type, ctx["company_name"]))
    else:
        image_path = ctx["image_path"]

    try:
        insert_log(
            url_api,
            ctx["company_id"],
            ctx["company_name"],
            ctx["customer_tag_id"],
            ctx["store_id"],
            ctx["store_name"],
            image_path,
            message_log,
            data_type,
            activity,
            status,
        )
    except Exception:
        pass

    headers = dict(response.headers)
    headers.pop("content-length", None)
    return Response(
        content=body_bytes,
        status_code=response.status_code,
        headers=headers,
        media_type=response.media_type,
    )


@app.get("/health")
def health() -> dict[str, str]:
    # ping_db() raises HTTPException(503, ...) on failure (same path/retry
    # behavior as every other DB call, see app/core/db.py:ping) — that
    # propagates through the normal exception handlers below, so a broken
    # DB connection here comes back as a real 503, not a 200 that only
    # means "the process is running", which is useless to an orchestrator
    # (k8s liveness/readiness probe, load balancer health check, ...)
    # deciding whether to route traffic here or restart the container.
    ping_db()
    return {"status": "ok", "database": "ok"}
