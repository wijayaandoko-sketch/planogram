# Planogram Compliance Detection

Deteksi produk di foto rak dan identifikasi SKU-nya. Multi-tenant per company — tiap company punya API key, model YOLO, checkpoint embedding, dan katalog referensi sendiri-sendiri (didaftarkan di database MySQL), supaya semantic search tidak pernah tercampur antar company.

Project ini murni untuk **serving/deteksi**. Training model (YOLO dan embedding ArcFace) dikerjakan terpisah di luar project ini (mis. Google Colab) — hasilnya (`.pt`) tinggal ditaruh di path yang didaftarkan di database.

## Arsitektur

```
X-API-Key header -> lookup MySQL (tabel company_data) -> company record
Foto rak -> YOLO dari model_path company itu (deteksi bounding box produk)
         -> crop tiap produk -> EfficientNet embedding dari embed_path company itu
         -> FAISS index company itu -> SKU teridentifikasi
```

- `app/core/db.py` — koneksi & query MySQL (PyMySQL), ambil baris company by `api_key`/`company_id`, baris template by `company_id`+`customer_tag_id`, baris store by `company_id`+`store_id`+`customer_tag_id`, insert baris `logs`, dan `setup_company()` untuk insert company+template sekaligus dalam satu transaksi.
- `app/core/company.py` — `resolve_company` (FastAPI dependency, baca header `X-API-Key`) dan `resolve_company_by_id` (dipakai script), keduanya balikin `CompanyRecord` (`company_id`, `company_name`, `model_path`, `embed_path`, `data_path`). Juga ada `faiss_index_dir()`/`uploads_dir()` — dua hal ini **tidak** ada di database, tetap pakai konvensi folder `data/faiss_index/<company_id>/` dan `data/uploads/<company_id>/`.
- `app/core/store.py` — `resolve_store` (FastAPI dependency-style helper) memvalidasi `store_id` ke tabel `store_data` untuk `company_id`+`customer_tag_id` yang sama, balikin `StoreRecord` (`store_id`, `store_name`). 404 "Unknown store_id" untuk store yang tidak ada, milik company lain, atau terdaftar di `customer_tag_id` lain — pesannya sengaja disamakan supaya tidak bocor informasi mana yang sebenarnya salah.
- `app/core/registry.py` — cache `CompliancePipeline` per `company_id` (model cuma di-load sekali per company selama proses server hidup, bukan tiap request/query DB ulang).
- `app/detection/`, `app/recognition/` — wrapper YOLO (Ultralytics) dan EfficientNet+FAISS, instansiasinya pakai path dari `CompanyRecord`.
- `app/pipeline.py` — `CompliancePipeline(company: CompanyRecord)`: alur deteksi -> crop -> embed -> search.
- `app/api/routes/_common.py` — logika deteksi+grouping (`group_by_product`) dipakai bareng `/test-detect` dan `/input-md`; `validate_tag_data()` (validasi tipe int untuk `customer_tag_data`) dipakai saat create `template_data`; `SAFE_ID_PATTERN` (charset aman untuk `customer_tag_id`/`store_id`, anti path-traversal) dipakai di banyak route.
- `app/main.py` — selain daftar router, juga isi **request-logging middleware** (`log_requests`) yang menulis satu baris `logs` untuk *setiap* pemanggilan endpoint (sukses maupun gagal) — lihat bagian Database di bawah untuk detailnya. Route-nya sendiri tidak ada kode logging sama sekali; ini satu-satunya tempat itu terjadi.
- `app/api/routes/` — endpoint FastAPI: `POST /register-company-data` dan `POST /topup-api-limit` (dua-duanya **tidak** butuh `X-API-Key`, tapi wajib `X-Admin-Token` — satu yang mendaftarkan company barunya, satu lagi menambah kuota `api_limit`-nya), lalu sisanya semua wajib header `X-API-Key` dan divalidasi ke database: `POST /test-detect`, `POST /input-md`, `POST /register-template-data`, `GET /view-template-data`, `DELETE /delete-template-data/{customer_tag_id}`, `POST /register-store-data`, `GET /view-store-data`, `DELETE /delete-store-data/{store_id}`, `GET /view-store-image`. Tidak ada endpoint update — untuk mengganti data, hapus baris lama lalu register ulang.

Modul `app/compliance/` dan `app/planogram/` (compliance scoring vs planogram acuan) masih ada di kode dan ada unit test-nya, tapi saat ini tidak dipakai endpoint API mana pun.

## Database

Empat tabel MySQL. Sumber kebenaran skemanya sekarang ada di **[`schema.sql`](schema.sql)** di root project — idempotent (`CREATE TABLE IF NOT EXISTS`, aman dijalankan berkali-kali), jadi deploy pertama kali tinggal:

```bash
mysql -u <user> -p -e "CREATE DATABASE IF NOT EXISTS planogram_data"
mysql -u <user> -p planogram_data < schema.sql
```

Tidak perlu lagi copy-paste manual dari blok SQL di bawah ini — blok di bawah cuma untuk dibaca (ikut disinkronkan tiap ada perubahan skema, tapi `schema.sql` yang dijalankan sungguhan):

```sql
CREATE TABLE company_data (
    company_id VARCHAR(50) COLLATE utf8mb4_bin NOT NULL PRIMARY KEY,
    company_name VARCHAR(100) COLLATE utf8mb4_bin NOT NULL UNIQUE,
    api_key_hash CHAR(64) COLLATE ascii_bin NOT NULL UNIQUE,       -- SHA-256(api_key), bukan plaintext — lihat "api_key disimpan sebagai hash"
    model_path VARCHAR(255) COLLATE utf8mb4_bin NOT NULL UNIQUE,   -- relatif ke models/, mis. "AICE/product.pt"
    embed_path VARCHAR(255) COLLATE utf8mb4_bin NOT NULL UNIQUE,   -- relatif ke models/, mis. "AICE/embedding_model.pt"
    data_path VARCHAR(255) COLLATE utf8mb4_bin NOT NULL UNIQUE,    -- relatif ke data/, mis. "catalog/AICE"
    api_limit INT NOT NULL DEFAULT 100 CHECK (api_limit >= 0)      -- kuota /test-detect + /input-md, lihat "Kuota api_limit"
);

CREATE TABLE template_data (
    company_id VARCHAR(50) COLLATE utf8mb4_bin NOT NULL,       -- = company_data.company_id
    company_name VARCHAR(100) NOT NULL,       -- = company_data.company_name
    customer_tag_id VARCHAR(50) COLLATE utf8mb4_bin NOT NULL,  -- identitas planogram/layout, bebas dipilih client
    customer_tag_data LONGTEXT NOT NULL,      -- JSON {sku_id: jumlah}, dikirim langsung oleh client
    template_image_path VARCHAR(255) NULL,    -- path foto referensi layout ini, cuma disimpan (tidak dideteksi)
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),  -- presisi mikrodetik, bukan cuma detik — supaya (company_id, customer_tag_id, created_at) aman dipakai identifier baris
    PRIMARY KEY (company_id, customer_tag_id, created_at)  -- tidak ada template_id — baris diidentifikasi lewat kombinasi ini
);

CREATE TABLE store_data (
    company_id VARCHAR(50) COLLATE utf8mb4_bin NOT NULL,       -- = company_data.company_id
    company_name VARCHAR(100) NOT NULL,       -- = company_data.company_name
    store_id VARCHAR(50) COLLATE utf8mb4_bin NOT NULL,         -- unik per company_id (primary key di bawah), BUKAN lintas company
    store_name VARCHAR(100) COLLATE utf8mb4_bin NOT NULL,      -- unik per company_id juga (lihat UNIQUE di bawah)
    customer_tag_id VARCHAR(50) COLLATE utf8mb4_bin NOT NULL,  -- tag/layout yang dipakai toko ini
    PRIMARY KEY (company_id, store_id),
    UNIQUE (company_id, store_name)
);

CREATE TABLE logs (
    log_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    url_api VARCHAR(255) NOT NULL,            -- nama endpoint yang di-hit, mis. "view-template-data" (tanpa slash awal, tanpa segmen path dinamis)
    company_id VARCHAR(50) NOT NULL,          -- = company_data.company_id
    company_name VARCHAR(100) NOT NULL,       -- = company_data.company_name
    customer_tag_id VARCHAR(50) NOT NULL,     -- tag yang dipakai pada request ini
    store_id VARCHAR(50) NOT NULL,
    store_name VARCHAR(100) NOT NULL,
    image_path VARCHAR(255) NULL,             -- lihat penjelasan di bawah: file spesifik untuk register/update/delete, folder company untuk view
    message_log LONGTEXT NULL,                -- JSON: isi response endpoint terkait (atau {success:false,...} kalau gagal)
    data_type ENUM('template', 'md', 'store', 'company') NOT NULL,
    activity ENUM('register', 'update', 'delete', 'view') NOT NULL,
    status ENUM('success', 'failed') NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

`model_path` dan `embed_path` di-resolve relatif terhadap `models/` (jadi tinggal isi `"<COMPANY_ID>/product.pt"` dst — filenya harus ditaruh di `models/<COMPANY_ID>/`). `data_path` di-resolve relatif terhadap `data/` (mis. `"catalog/<COMPANY_ID>"` → `data/catalog/<COMPANY_ID>/<SKU_ID>/*.jpg`). Lihat `app/core/company.py:_to_record()` dan `app/core/config.py` (`models_dir`, `data_dir`) kalau mau ubah base directory-nya.

Kolom identifier yang dipakai untuk lookup/validasi/`UNIQUE` (`company_id`, `company_name`, `model_path`, `embed_path`, `data_path` di `company_data`; `company_id`, `store_id`, `store_name`, `customer_tag_id` di `store_data`; `company_id`, `customer_tag_id` di `template_data`) sengaja pakai collation **`utf8mb4_bin`** (case-sensitive), bukan default MySQL `utf8mb4_general_ci` (case-insensitive) — tanpa ini, `"C001"` dan `"c001"` akan dianggap **sama** oleh MySQL (baik untuk `WHERE ... = ...` maupun cek `UNIQUE`), padahal seharusnya beda. `api_key_hash` juga case-sensitive tapi pakai **`ascii_bin`** (bukan `utf8mb4_bin`) karena isinya selalu hex digit SHA-256 (lihat "`api_key` disimpan sebagai hash"). Kolom isi bebas yang tidak pernah dibandingkan-persis (`company_name` di `template_data`/`store_data` — cuma salinan, bukan sumber kebenaran; `template_image_path`, `image_path`, `message_log`, dst) tetap collation default.

`template_data` menyimpan planogram acuan per `customer_tag_id` — satu tag bisa dipakai untuk banyak rak/lokasi yang layout-nya identik, tinggal pakai `customer_tag_id` yang sama saat panggil `/input-md`. `POST /register-template-data` insert baris ke sini; `POST /input-md` **membaca** dari sini (lookup by `company_id`+`customer_tag_id`, diambil baris `created_at` paling baru) sebagai sumber `must_have` untuk perbandingan. CRUD-nya (`GET /view-template-data`, `DELETE /delete-template-data/{customer_tag_id}`) ada di bagian endpoint di bawah — tidak ada endpoint update; untuk mengganti data satu tag, hapus lalu `POST /register-template-data` ulang. `DELETE` menghapus **seluruh riwayat** untuk satu `customer_tag_id` sekaligus (bukan satu baris saja), karena `customer_tag_id` memang tidak unik per baris.

`store_data` memetakan satu `store_id` ke satu `customer_tag_id`, didaftarkan lewat `POST /register-store-data` — `POST /input-md` wajib `store_id` yang sudah terdaftar di sini untuk `company_id`+`customer_tag_id` yang sama, lookup lewat `app/core/store.py:resolve_store()`. `store_id` dan `store_name` masing-masing **unik per company** (bukan lintas company) — company berbeda boleh pakai `store_id`/`store_name` yang sama persis, tapi dalam satu company tidak boleh dobel. `GET /view-store-image` cukup `store_id` saja (`customer_tag_id`-nya di-lookup dari baris `store_data`, lewat `app/core/db.py:fetch_store_by_id()`, tidak perlu dikirim client) — endpoint ini cuma serve foto MD, tidak ada opsi `type`. `store_id`+`store_name` juga jadi subfolder tempat gambar MD disimpan (lihat path di bawah) dan dicatat ke `logs`. `POST /register-template-data` **tidak** pakai `store_id` sama sekali — baris `logs` yang dibuatnya diisi `store_id`/`store_name` string kosong. CRUD-nya (`GET /view-store-data`, `DELETE /delete-store-data/{store_id}`) juga ada di bagian endpoint di bawah — tidak ada endpoint update; untuk mengganti data satu store, hapus lalu `POST /register-store-data` ulang.

`logs` mencatat **setiap** pemanggilan **9 dari 10 endpoint bisnis** — sukses maupun gagal, termasuk yang gagal duluan di tahap otentikasi (401 API key salah/hilang) sebelum kode endpoint itu sendiri sempat jalan. `POST /test-detect` sengaja **tidak** di-log sama sekali (murni tes cepat, tidak mengubah state apa pun — lihat docstring-nya). Ini terjadi di **satu tempat**: middleware `log_requests` di `app/main.py` (daftar path yang di-log ada di `_DATA_TYPE_BY_PREFIX`), bukan kode di masing-masing route — jadi tidak ada endpoint yang bisa "lupa" di-log (atau, untuk `/test-detect`, sengaja dikecualikan lewat satu baris di daftar itu).

`url_api` langsung menyebut nama endpoint-nya apa adanya (mis. `"view-template-data"`) — untuk `delete-*` yang path-nya punya segmen dinamis (`/delete-template-data/{customer_tag_id}`), yang tersimpan cuma nama endpoint-nya (`"delete-template-data"`), bukan path lengkap dengan `customer_tag_id`/`store_id` yang dikirim (nilai itu sudah ada di kolom `customer_tag_id`/`store_id` sendiri).

Dua kolom lain bareng-bareng identifikasi endpoint yang sama secara lebih terstruktur (berguna untuk query/filter tanpa parsing string `url_api`):
- `data_type` — target resource-nya: `"template"`, `"store"`, `"md"` (`/input-md` dan `GET /view-store-image`, tidak ada tabel `md_data` sungguhan, cuma penanda jenis), atau `"company"` (`/register-company-data`).
- `activity` — diturunkan otomatis dari HTTP method: `GET` → `"view"`, `POST` → `"register"`, `DELETE` → `"delete"` (`"update"` masih ada di ENUM kolomnya untuk kompatibilitas riwayat lama, tapi tidak ada endpoint yang menghasilkannya lagi).

Kombinasi keduanya unik per endpoint, mis. `activity="delete"` + `data_type="store"` = selalu dari `DELETE /delete-store-data/{store_id}`.

`message_log` berisi **body response lengkap** yang diterima client — persis `{"success": ..., "data": ..., "message": ...}`, bukan cuma potongan `data`-nya saja:
- **Sukses** (`status`, dari kode HTTP `< 400`): `message_log` = `{"success": true, "data": [...], "message": "SUCCESS"}` apa adanya. Semua endpoint (termasuk `GET /view-store-image`, sejak responsnya jadi JSON juga) mencatat body lengkap ini — tidak ada lagi endpoint dengan `message_log` `NULL` di baris sukses.
- **Gagal** (kode HTTP `>= 400`, dari endpoint manapun termasuk 401/404/409/422/503 bawaan validasi): `message_log` diisi body error lengkap yang sama persis dengan yang diterima client (lihat exception handler global di `app/main.py`, dan penjelasan bentuk `data`-nya di bagian endpoint di bawah).

`customer_tag_id`/`store_id`/`store_name`/`company_id`/`company_name` diisi dengan pendekatan best-effort berlapis (dicoba berurutan, berhenti begitu ketemu): dari isi `data[0]` response, dari path/query parameter URL, dari `request.state` (dipakai beberapa route untuk nitip detail yang tidak ikut dikembalikan ke client), dari form-data yang dikirim client (kalau errornya terjadi sebelum ada apa pun yang berhasil di-lookup), lalu terakhir resolve ulang lewat header `X-API-Key`. Kolom yang memang tidak relevan untuk endpoint itu (mis. `store_id` untuk `register-template-data`) dibiarkan `""`. Penulisan log ini best-effort — kalau gagal, tidak memengaruhi response yang sudah dikirim ke client.

`image_path` beda perlakuan tergantung `activity`, supaya kelihatan jelas dari `logs` sendiri operasi CRUD-nya ngapain:
- **`register`/`update`/`delete`** — path ke **file spesifik** yang bersangkutan (mis. foto template/MD yang baru disimpan). Untuk operasi yang memang tidak melibatkan file sama sekali (semua operasi `store_data` — daftar/ubah/hapus store tidak pernah menyentuh file gambar), tetap `NULL`.
- **`view`** — path cuma sampai ke **folder company** untuk `data_type` itu (`data/uploads/template_data/<company_name>/` atau `data/uploads/md_data/<company_name>/`), bukan satu file spesifik — karena `view` membaca semuanya, bukan satu row/file saja. `data_type="store"` (`GET /view-store-data`) tetap `NULL` karena `store_data` tidak punya folder upload sendiri.

Tabel ini INSERT-only, belum dibaca balik oleh endpoint manapun — murni riwayat/audit. Tumbuh tanpa batas kalau dibiarkan — lihat "Retensi logs" di bawah untuk cara mengarsipkannya.

**Validasi**: `X-API-Key` (→ `company_id`/`company_name`) untuk semua endpoint; `customer_tag_id` (→ baris `template_data`) untuk `/input-md` dan `/register-store-data`; `store_id` (→ baris `store_data`) untuk `/input-md` (harus terdaftar di bawah `company_id`+`customer_tag_id` yang sama) dan `GET /view-store-image` (cukup terdaftar untuk `company_id` itu, tag-nya ikut dari baris `store_data`) — `/register-template-data` tidak menyentuh `store_data` sama sekali. Salah satunya tidak cocok → 404 (pesan "Unknown store_id" disamakan untuk semua kasus store yang tidak valid, supaya tidak bocor informasi).

Kredensial koneksi di `.env` (lihat `.env.example`):

```
PLANOGRAM_MYSQL_HOST=localhost
PLANOGRAM_MYSQL_PORT=3306
PLANOGRAM_MYSQL_USER=root
PLANOGRAM_MYSQL_PASSWORD=
PLANOGRAM_MYSQL_DATABASE=planogram_data
PLANOGRAM_MYSQL_TABLE=company_data
PLANOGRAM_MYSQL_TEMPLATE_TABLE=template_data
PLANOGRAM_MYSQL_STORE_TABLE=store_data
PLANOGRAM_MYSQL_LOGS_TABLE=logs
```

### Retensi logs

`logs` di-`INSERT` di setiap request (lihat di atas) dan **tidak pernah dihapus otomatis** — kalau dibiarkan, tabel ini tumbuh selamanya. Solusinya bukan hapus, tapi **arsip bulanan**: `scripts/archive_logs.py` memindahkan satu bulan penuh data `logs` jadi file CSV, baru menghapusnya dari tabel aktif — riwayatnya tetap ada selamanya, cuma bentuknya jadi file, bukan baris database aktif yang terus dibaca/ditulis.

**Struktur file hasil arsip:**
```
data/logs_archive/
├── all/
│   └── logs_2026-08.csv                              ← semua company bulan itu
├── C001_AICE/
│   └── C001_AICE_logs_2026-08.csv                    ← cuma baris company_id="C001"
└── <company_id>_<company_name>/
    └── <company_id>_<company_name>_logs_<YYYY-MM>.csv
```
Baris `logs` yang `company_id`-nya kosong (request gagal sebelum sempat teridentifikasi company mana, mis. salah `X-API-Key`) cuma masuk ke `all/`, tidak ada folder company yang cocok untuknya.

**Cara kerja teknis — partisi bulanan MySQL, bukan `DELETE` biasa.** Tabel `logs` dipartisi per bulan (`PARTITION BY RANGE`, lihat `schema.sql`) — begitu satu bulan sudah selesai diarsipkan ke CSV, baris-barisnya dibuang lewat `DROP PARTITION` (operasi hapus metadata, hampir instan walau isinya jutaan baris) alih-alih `DELETE ... WHERE` yang harus scan baris satu-satu. Skema di `schema.sql` sengaja cuma punya satu partisi penampung (`pmax`) — skrip arsip yang "mengukir" partisi bulan tertentu dari situ (`REORGANIZE PARTITION`) tepat sebelum bulan itu diarsipkan, jadi `schema.sql` tidak perlu tahu tanggal berapa sekarang.

**Butuh kredensial MySQL terpisah yang lebih tinggi hak aksesnya.** `PLANOGRAM_MYSQL_USER` yang dipakai API sehari-hari sengaja **tidak** punya privilese `ALTER` (lihat "Kredensial database" di bawah) — jadi skrip ini butuh `PLANOGRAM_MYSQL_ADMIN_USER`/`PLANOGRAM_MYSQL_ADMIN_PASSWORD` sendiri (lihat `.env.example`), user MySQL terpisah yang **punya** privilese `ALTER` di database ini. Kalau env var ini tidak di-set, skrip menolak jalan dengan pesan error yang jelas — bukan diam-diam mencoba pakai user API yang memang tidak punya izin.

**Jalan sekali sebulan:**
```bash
python scripts/archive_logs.py                  # arsipkan bulan kalender penuh terakhir
python scripts/archive_logs.py --month 2026-08   # arsipkan bulan tertentu (mis. susulan)
```
Jadwalkan otomatis lewat Task Scheduler (Windows) atau `cron` (Linux/produksi) tanggal 1 tiap bulan — tidak ada scheduler bawaan di dalam aplikasi ini sendiri.

**Aman dijalankan berkali-kali (idempotent) dan aman kalau berhenti di tengah jalan** (mati listrik, proses ke-kill, dst) — urutannya selalu: tulis CSV ke file sementara → **verifikasi** jumlah baris yang ditulis cocok dengan tabel → baru rename jadi nama final → **baru setelah itu** `DROP PARTITION`. Kalau dijalankan ulang:
- Bulan yang sudah beres (CSV ada + partisi sudah tidak ada + tidak ada baris baru untuk bulan itu di tabel) → langsung berhenti, tidak kerja dua kali.
- Sempat berhenti di tengah (CSV sudah jadi tapi partisi belum sempat di-drop) → lanjutkan dari situ, tidak menulis ulang CSV yang sudah benar.
- **Ditemukan baris yang tidak konsisten** (mis. CSV bulan itu sudah ada tapi ternyata tabel masih punya baris untuk bulan itu dengan jumlah berbeda — seharusnya tidak pernah terjadi karena `created_at` selalu dibuat server, tidak pernah dikirim client, tapi tetap dijaga) → **berhenti dengan error**, tidak menghapus apa pun, supaya bisa dicek manual dulu.

## Setup lokal

```bash
python -m venv .venv
.venv/Scripts/activate       # Windows
pip install -r requirements.txt
cp .env.example .env         # lalu sesuaikan kredensial MySQL-nya
```

## Menambah company baru

**Cara 1 — lewat `POST /register-company-data`** (lihat bagian endpoint di bawah): kirim `company_id`/`company_name`/`api_key` + file `.pt` untuk `model_path`/`embed_path` dalam satu request. Endpoint ini yang membuat baris `company_data`-nya **dan** folder `models/<company_name>/` + `data/catalog/<company_name>/` sekaligus — tidak perlu langkah manual taruh file. Lanjut ke langkah 2 (isi katalog) dan 4 (build index) di bawah.

**Cara 2 — manual + script**:

1. Taruh weights YOLO di `models/<COMPANY_ID>/product.pt`, dan (opsional) checkpoint embedding fine-tuned di `models/<COMPANY_ID>/embedding_model.pt`.
2. Susun katalog referensi per SKU di `data/catalog/<COMPANY_ID>/<SKU_ID>/*.jpg`.
3. Isi `company_data` + (opsional) `template_data` **sekaligus** lewat `scripts/setup_company.py` (lihat bagian "Setup sekaligus" di bawah) — jangan insert manual satu-satu per tabel.
4. Build FAISS index untuk company itu (dibaca dari `data_path` & `embed_path` di database, disimpan ke `data/faiss_index/<company_id>/`):

   ```bash
   python scripts/build_index.py --company <COMPANY_ID>
   ```

Kedua cara **tidak** membuild FAISS index-nya — langkah 4 tetap wajib manual setelah katalog SKU-nya lengkap, baik company-nya didaftarkan lewat endpoint atau lewat script.

## Setup sekaligus (company + template dalam satu transaksi)

`scripts/setup_company.py` — baca satu file JSON, insert ke `company_data` dan `template_data` sekaligus dalam **satu transaksi database**: kalau ada satu langkah yang gagal (mis. `customer_tag_id` bentrok), **semuanya di-rollback**, tidak ada yang nyangkut setengah-setengah. Ini gantinya kalau sebelumnya harus `INSERT` manual satu-satu per tabel lewat SQL langsung.

Contoh config — lihat `scripts/setup_company.example.json`:
```json
{
  "company": {
    "company_id": "C001",
    "company_name": "AICE",
    "api_key": "...",
    "model_path": "AICE/product.pt",
    "embed_path": "AICE/embedding_model.pt",
    "data_path": "catalog/AICE"
  },
  "templates": [
    {"customer_tag_id": "LAYOUT_A", "customer_tag_data": {"SUSU COKLAT": 2, "SUSU STROBERI": 3}}
  ]
}
```

```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"   # generate api_key dulu
python scripts/setup_company.py --config scripts/setup_company.example.json
```

Perilakunya:
- `model_path`/`embed_path`/`data_path` di config dicek **benar-benar ada di disk dulu** sebelum menyentuh database sama sekali — kalau salah ketik path, gagal cepat dengan pesan jelas, bukan baru ketahuan pas ada request `422` nanti.
- `templates` opsional (boleh dikosongkan kalau cuma mau daftarkan company-nya saja).
- Kalau `company_id` **sudah ada**, itu **bukan error** — dilewati (tidak menimpa `api_key`/path yang sudah ada), tapi template baru di config tetap dibuat, otomatis pakai `company_name` **asli** dari database (bukan yang di config, supaya tidak mungkin mismatch dengan `company_data`).
- `customer_tag_id` yang sudah ada akan bikin seluruh transaksi gagal & rollback total (bukan skip diam-diam) — jadi aman dijalankan berulang asal `customer_tag_id` di config memang baru.

`store_data` **belum** ikut ditangani script ini — untuk registrasi store, pakai `POST /register-store-data` (lihat bagian endpoint di bawah), atau seed manual lewat `app.core.db.insert_store(company_id, company_name, store_id, store_name, customer_tag_id)`.

## Menambah/mengurangi SKU untuk company yang sudah ada

Tambah/hapus folder di `<data_path>/<SKU_ID>/` (path yang terdaftar di database untuk company itu), lalu jalankan ulang `python scripts/build_index.py --company <COMPANY_ID>` dan restart server (pipeline di-cache di memori, tidak baca ulang otomatis). Tidak perlu training ulang model kecuali kualitas recognition-nya bermasalah setelah dites.

Kalau `model_path`/`embed_path`/`data_path` di database diubah untuk company yang sudah pernah diakses, server juga perlu **direstart** — pipeline-nya sudah ter-cache di memori sejak request pertama.

**Jangan rename `company_id`** (kolom primary key) tanpa ikut memindahkan foldernya. `data/faiss_index/<company_id>/` dan `data/uploads/<company_id>/` itu konvensi folder berdasarkan `company_id`, bukan kolom database — kalau `company_id` diubah tapi foldernya tidak ikut di-rename, company itu akan kehilangan akses ke index & upload lamanya (dapat `422` "faiss_index is missing" sampai foldernya disesuaikan atau index-nya di-build ulang).

## Jalankan API

**Development** (kode masih sering diubah — `--reload` otomatis restart server tiap file berubah):
```bash
uvicorn app.main:app --reload
```

**Produksi** (tanpa `--reload` — flag itu terus memantau filesystem untuk restart otomatis, overhead yang tidak dibutuhkan di server produksi dan bisa memicu restart tak terduga kalau ada proses lain menyentuh file di folder project; jumlah worker eksplisit — tiap worker menggandakan pemakaian memori/GPU untuk model per company):
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 1
```

`GET /health` — dipakai orchestrator/load balancer (liveness/readiness probe, dst) untuk tahu instance ini boleh dikirimi traffic atau tidak. Bukan cuma status statis "proses hidup" — benar-benar menjalankan `SELECT 1` ke MySQL lewat jalur yang sama dengan endpoint lain (pool + retry yang sama, lihat "Connection pooling"). DB bisa dijangkau → `200 {"status": "ok", "database": "ok"}`; tidak bisa → `503` format standar `{success, data, message}` seperti error lain, otomatis pulih lagi jadi `200` begitu MySQL bisa dijangkau lagi (tidak perlu restart proses).

Ada 11 endpoint (lihat juga Swagger UI di `/docs`). `POST /register-company-data` **tidak butuh** `X-API-Key` (dia yang mendaftarkan company-nya) — sebagai gantinya wajib `X-Admin-Token` (lihat "Keamanan deployment" di bawah). Sisanya semua **wajib** header `X-API-Key`: `/input-md` wajib `customer_tag_id`+`store_id` (`store_id` harus sudah terdaftar di `store_data` untuk `company_id`+`customer_tag_id` yang sama); `/register-template-data` cuma wajib `customer_tag_id` (tanpa `store_id`); `/register-store-data` wajib `store_id`+`store_name`+`customer_tag_id` (ini yang membuat baris `store_data`-nya, bukan yang memvalidasi ke situ); `GET /view-store-image` wajib `store_id` — satu-satunya parameter (tidak ada `type`, cuma serve foto MD; `customer_tag_id` juga tidak dikirim, di-lookup dari `store_data`); `/test-detect` dan kedua endpoint `GET /view-*` tidak butuh parameter lain sama sekali selain API key. CRUD `/*-template-data` dan `/*-store-data` (lihat bagian tersendiri di bawah) melengkapi `/register-template-data`/`/register-store-data` dengan view/delete — tidak ada endpoint update.

### `POST /register-company-data`

Endpoint **satu-satunya yang tidak butuh `X-API-Key`** — tidak ada company yang bisa diautentikasi sebelum dia dibuat sendiri lewat endpoint ini. Sebagai gantinya, wajib header **`X-Admin-Token`** yang cocok dengan `PLANOGRAM_ADMIN_TOKEN` — satu secret bersama untuk admin deployment (bukan per-company seperti `api_key`). Kalau `PLANOGRAM_ADMIN_TOKEN` belum di-set di server, endpoint ini **selalu balas `503`** untuk siapa pun (fail-closed) — bukan diam-diam terbuka untuk semua orang.

- `401 "Missing or invalid X-Admin-Token"` — header tidak dikirim atau nilainya salah.
- `503 "Admin token is not configured on this server"` — server belum di-set `PLANOGRAM_ADMIN_TOKEN` sama sekali.

Ini lapisan proteksi di level kode saja — endpoint ini **tetap harus dibatasi di level jaringan juga** (lihat "Membatasi akses register-company-data" di bawah), karena siapa pun yang lolos otentikasi ini bisa menulis file `.pt` ke server dan membuat company baru bebas.

```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"   # generate PLANOGRAM_ADMIN_TOKEN sekali di awal

curl -X POST "http://127.0.0.1:8000/register-company-data" \
  -H "X-Admin-Token: <isi PLANOGRAM_ADMIN_TOKEN>" \
  -F "company_id=C002" -F "company_name=Nabati" -F "api_key=..." \
  -F "model_path=@product.pt" -F "embed_path=@embedding_model.pt"
```

Form-data (`multipart/form-data`) — 5 field:
- `company_id` — primary key, cuma boleh huruf/angka/`_`/`-`, maks 50 karakter. `409` kalau sudah terdaftar.
- `company_name` — jadi **nama folder asli** di `models/<company_name>/` dan `data/catalog/<company_name>/`, jadi cuma boleh huruf/angka/spasi/`_`/`-` (menolak `../../` dkk). Harus unik — `409 "company_name already registered"` kalau sudah dipakai company lain.
- `api_key` — bebas, maks 255 karakter, dipakai client nanti sebagai header `X-API-Key`. Harus unik antar company — `409` kalau sudah dipakai company lain.
- `model_path` — file `.pt` (weights YOLO). Disimpan ke `models/<company_name>/<nama_file_asli>`, path relatifnya (`<company_name>/<nama_file>`) yang masuk kolom `model_path`.
- `embed_path` — file `.pt` (checkpoint embedding). Sama seperti `model_path`, ke kolom `embed_path`. Nama filenya **harus beda** dari `model_path` (kalau sama, keduanya akan saling menimpa di folder yang sama → `400`).

`data_path` **tidak** diupload di sini — otomatis jadi `catalog/<company_name>`, dan folder `data/catalog/<company_name>/` dibuat kosong (isi SKU-nya ditambahkan belakangan, lihat "Menambah/mengurangi SKU"). `model_path`/`embed_path`/`data_path` juga `UNIQUE` di `company_data`, tapi tidak ada pengecekan `409` terpisah untuk ketiganya — semua diturunkan dari `company_name` (`<company_name>/<nama_file>`, `catalog/<company_name>`), jadi `company_name` yang sudah unik otomatis menjamin ketiganya unik juga.

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C002",
      "company_name": "Nabati",
      "api_key": "...",
      "model_path": "Nabati/product.pt",
      "embed_path": "Nabati/embedding_model.pt",
      "data_path": "catalog/Nabati"
    }
  ],
  "message": "SUCCESS"
}
```

FAISS index **tidak** dibuild di sini — tetap jalankan `python scripts/build_index.py --company <COMPANY_ID>` setelah katalognya diisi, kalau tidak semua request untuk company ini akan `422 "faiss_index is missing"`.

### `POST /test-detect`

Form-data `image` — endpoint uji coba paling sederhana: validasi **cuma dari API key**, tidak ada parameter lain. Jalankan deteksi+recognition pakai model & index milik company itu, hasilnya di-group per SKU (satu entry per varian produk, bukan per box), langsung dikembalikan sebagai response. **Tidak ada yang disimpan** — gambarnya tidak ditulis ke disk, tidak ada baris masuk ke database mana pun. Cocok untuk cek cepat apakah model/index sebuah company jalan dengan benar, tanpa menyentuh state apa pun.

Mengonsumsi **1 unit `api_limit`** company itu (lihat "Kuota `api_limit`" di bawah) — cuma kalau deteksinya benar-benar berhasil; request yang gagal validasi/error tidak memotong kuota. `403 "API limit exceeded for this company"` kalau kuotanya sudah habis.

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C001",
      "total_item": 7,
      "total_product": 3,
      "list_product": [
        {
          "product_id": "SUSU COKLAT",
          "product_total": 2,
          "locations": [
            {"bbox": [x1, y1, x2, y2], "detection_confidence": 0.9, "similarity_score": 0.8},
            {"bbox": [x1, y1, x2, y2], "detection_confidence": 0.87, "similarity_score": 0.75}
          ]
        }
      ]
    }
  ],
  "message": "SUCCESS"
}
```

`total_item` = jumlah semua item terdeteksi (semua box). `total_product` = jumlah varian berbeda (`len(list_product)`). Tiap entry `list_product` mewakili satu SKU unik — `locations` berisi satu object per instance produk itu (`bbox` + `detection_confidence` + `similarity_score` digabung per lokasi, bukan array terpisah-pisah), panjangnya sama dengan `product_total`. `product_id` bernilai `"UNKNOWN"` untuk produk yang gagal dikenali (similarity di bawah `recognition_min_similarity`).

### `POST /input-md?customer_tag_id=<TAG_ID>&store_id=<STORE_ID>`

Form-data `images` — **satu atau lebih** foto rak hasil pengecekan lapangan (merchandiser/MD), semua untuk visit/store yang sama (`customer_tag_id`+`store_id` berlaku untuk seluruh foto dalam satu call, bukan per foto). Tiap foto diproses **independen** — dijalankan deteksi+recognition yang sama, ditambah **perbandingan** terhadap `customer_tag_data` (baris `template_data` **terbaru** untuk `customer_tag_id` itu, di company yang sama — lihat `POST /register-template-data`) — hasilnya **tidak digabung**, `data` berisi satu object per foto, urutannya sama seperti urutan upload. `store_id` divalidasi ke `store_data` (harus terdaftar untuk `company_id`+`customer_tag_id` ini, lihat bagian Database di atas).

Semua foto **divalidasi/didekode dulu sebelum ada satu pun yang diproses atau disimpan** — kalau salah satu foto invalid, seluruh request ditolak `400` dan tidak ada foto yang tersimpan sama sekali (all-or-nothing, konsisten dengan endpoint lain).

Mengonsumsi **`api_limit` PER FOTO** (lihat "Kuota `api_limit`" di bawah) — 5 foto dalam satu call yang berhasil memotong 5, bukan 1. Kalau sisa kuota company itu lebih kecil dari jumlah foto yang dikirim, **seluruh request ditolak `403`** sebelum satu pun foto diproses (sama seperti validasi all-or-nothing di atas) — tidak ada pemrosesan sebagian.

Gambar hasil anotasi tiap foto disimpan ke disk di `data/uploads/md_data/<company_name>/<customer_tag_id>/<store_id>_<store_name>/` (cuma gambarnya — tidak ada file JSON di sana), path masing-masing masuk field `image_path` di item-nya sendiri. JSON hasil lengkapnya (deteksi + perbandingan untuk seluruh foto di call ini) di-`INSERT` sebagai satu baris ke tabel `logs` (`data_type="md"`) — karena satu call bisa menghasilkan banyak file sekarang, `image_path` yang dicatat ke `logs` adalah **folder MD store ini**, bukan satu file spesifik (beda dari `register-template-data` yang tetap menunjuk satu file).

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C001",
      "customer_tag_id": "LAYOUT_A",
      "store_id": "STR001",
      "image_path": "data/uploads/md_data/AICE/LAYOUT_A/STR001_Indomaret_Kelapa_Gading/LAYOUT_A_20260828_113831_342452.png",
      "total_item": 1,
      "total_product": 1,
      "list_product": [
        {
          "product_id": "SUSU COKLAT",
          "must_have": 3,
          "product_total": 1,
          "short_by": 2,
          "locations": [
            {"bbox": [x1, y1, x2, y2], "detection_confidence": 0.87, "similarity_score": 0.7}
          ]
        }
      ],
      "missing_product": [
        {"product_id": "SUSU STROBERI"}
      ],
      "compliance_score": 0.0
    }
  ],
  "message": "SUCCESS"
}
```

- Contoh di atas cuma 1 foto (`data` berisi 1 item) — kalau upload 2 foto, `data` berisi 2 item seperti ini, masing-masing dengan `image_path` dan angka deteksinya sendiri.
- `compliance_score` — persentase (0-100, **dibulatkan 2 angka di belakang koma**) dari SKU-SKU **milik `customer_tag_data`** yang terdeteksi minimal satu kali di foto ini. **Berbasis ada/tidak ada, bukan jumlah** — SKU yang under-stock (`short_by > 0`) tetap dihitung "ada" selama tidak nol total; cuma SKU yang benar-benar masuk `missing_product` yang tidak dihitung. SKU yang terdeteksi tapi tidak ada di `customer_tag_data` sama sekali (yang di `list_product` dengan `must_have=0`) tidak memengaruhi hitungan ke arah mana pun — pembaginya cuma jumlah SKU di `customer_tag_data`.
  Contoh: template berisi 3 SKU (`SUSU COKLAT`:2, `SUSU STROBERI`:3, `SUSU VANILA`:4), yang terdeteksi di foto cuma 1 `SUSU COKLAT` (kurang dari `must_have`, tapi tetap "ada") dan 3 `SUSU STROBERI` (pas), `SUSU VANILA` nihil (masuk `missing_product`) → `compliance_score = round((3-1)/3*100, 2) = 66.67`. Kalau `customer_tag_data` kosong (tidak ada SKU yang disyaratkan sama sekali), `compliance_score = 100.0` (vacuously compliant, bukan error pembagian oleh nol, dan tidak melalui pembulatan karena memang sudah bulat).
- `must_have` = jumlah yang seharusnya ada, dari `customer_tag_data[product_id]` (mis. `{"SUSU COKLAT": 3, "SUSU STROBERI": 1}`). `product_total` = jumlah yang benar-benar terdeteksi di foto MD ini. `short_by` = `max(must_have - product_total, 0)` — cuma dihitung kalau kurang, tidak pernah negatif.
- Produk yang terdeteksi di foto MD tapi **tidak ada di `customer_tag_data` sama sekali** tetap masuk `list_product` dengan `must_have=0`, `short_by=0` (artinya: ada barang di rak yang tidak terdaftar di planogram).
- `missing_product` — daftar SKU yang ada di `customer_tag_data` tapi **sama sekali tidak terdeteksi** di foto MD ini (bukan cuma kurang, tapi nihil).
- Kalau `customer_tag_id` itu tidak punya baris di `template_data` untuk company ini (belum pernah dipanggil `/register-template-data`) → `404 "customer_tag_id missing"`.
- Kalau `store_id` tidak terdaftar di `store_data` untuk `company_id`+`customer_tag_id` ini (tidak ada, milik company lain, atau terdaftar di tag lain) → `404 "Unknown store_id"`.
- Kalau tidak ada foto sama sekali yang dikirim → `400 "At least one image is required"`. Kalau salah satu foto bukan gambar valid → `400 "Invalid image file"`, seluruh request gagal.

### Kuota `api_limit`

Tiap company punya kolom `company_data.api_limit` — jatah berapa kali lagi `POST /test-detect` dan `POST /input-md` boleh dipakai (dua-duanya yang benar-benar menjalankan model deteksi; endpoint lain seperti `view-*`/`register-template-data`/`register-store-data` tidak dibatasi kuota ini sama sekali).

- **Company baru** (`POST /register-company-data`) otomatis mulai dengan `api_limit = 100`.
- **`/test-detect`**: berhasil = potong 1. **`/input-md`**: berhasil = potong **sejumlah foto** yang dikirim di call itu (5 foto = potong 5). Kedua-duanya cuma dipotong kalau requestnya **benar-benar berhasil** — request yang gagal validasi (gambar rusak, `customer_tag_id`/`store_id` tidak dikenal, dst.) atau error, tidak memotong kuota sama sekali.
- Kalau sisa kuota tidak cukup, request ditolak **`403 "API limit exceeded for this company"`** sebelum model dijalankan (jadi tidak ada komputasi terbuang untuk request yang pasti ditolak) — untuk `/input-md`, ini juga berlaku kalau sisa kuota lebih kecil dari jumlah foto yang dikirim (semua-atau-tidak-sama-sekali, tidak ada foto yang diproses sebagian).
- Pengecekan & pengurangannya **atomik di level database** (satu `UPDATE ... WHERE api_limit >= N`) — dua request bersamaan dari company yang sama tidak akan pernah sama-sama lolos kalau sisa kuota cuma cukup untuk salah satu.

**`POST /topup-api-limit`** — nambah kuota, admin-only (`X-Admin-Token`, sama seperti `register-company-data`; bukan `X-API-Key` company itu sendiri — masuk akal, karena company yang kuotanya sudah habis tidak mungkin memberi izin dirinya sendiri nambah kuota). Form-data: `company_id`, `amount` (bilangan bulat positif, `422` kalau `0` atau negatif). **Menambah** ke sisa yang ada, bukan mengganti (sisa 30 di-top-up 50 → jadi 80, bukan 50).

```bash
curl -X POST "http://127.0.0.1:8000/topup-api-limit" \
  -H "X-Admin-Token: <admin-token>" \
  -F "company_id=C001" \
  -F "amount=100"
```

```json
{
  "success": true,
  "data": [
    {"company_id": "C001", "api_limit": 180}
  ],
  "message": "SUCCESS"
}
```

`data[0].api_limit` adalah **total setelah** top-up, bukan jumlah yang ditambahkan. `404 "Unknown company_id"` kalau `company_id`-nya tidak terdaftar.

### `POST /register-template-data`

Endpoint **input data + foto referensi**, tanpa deteksi. Form-data (`multipart/form-data`, bukan JSON) — API key (`company_id`/`company_name` ikut dari situ) + 3 field:
- `image` — file foto (disimpan apa adanya, **tidak** dijalankan deteksi apa pun terhadapnya).
- `customer_tag_id` — string bebas, tapi cuma boleh huruf/angka/`_`/`-` (jadi nama folder penyimpanan, jadi divalidasi supaya tidak bisa dipakai path traversal seperti `../../`).
- `customer_tag_data` — **file upload** berisi JSON, mis. isi filenya `{"SUSU COKLAT": 2, "SUSU STROBERI": 3}` (bukan lagi field teks biasa). Harus UTF-8 dan berupa JSON object (`400 "customer_tag_data file must be valid JSON"` kalau isinya bukan JSON valid, `400 "customer_tag_data must be a JSON object"` kalau JSON-nya bukan object, mis. array/angka/string).

Tidak ada `store_id` di sini — beda dari `/input-md` dan `GET /view-store-image`, endpoint ini tidak divalidasi ke `store_data`.

`customer_tag_data` `INSERT` sebagai baris baru ke tabel `template_data`. Foto disimpan ke `data/uploads/template_data/<company_name>/<customer_tag_id>/<customer_tag_id>_<YYYYmmdd_HHMMSS_ffffff>.png` (presisi mikrodetik di akhir nama file — supaya dua upload untuk tag yang sama dalam detik yang sama tidak saling menimpa), path-nya masuk kolom `template_image_path`. Sama seperti `/input-md`, satu baris juga masuk ke `logs` (`data_type="template"`, kolom `store_id`/`store_name` diisi string kosong karena endpoint ini tidak punya konteks store).

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C001",
      "customer_tag_id": "LAYOUT_A",
      "customer_tag_data": {"SUSU COKLAT": 2, "SUSU STROBERI": 3},
      "template_image_path": "data/uploads/template_data/AICE/LAYOUT_A/LAYOUT_A_20260824_134047.png"
    }
  ],
  "message": "SUCCESS"
}
```

Tiap panggilan `INSERT` baris baru (bukan update), jadi satu `customer_tag_id` bisa punya riwayat — `/input-md` selalu ambil baris `created_at` paling baru sebagai acuan aktif. Tidak ada kolom `template_id` — baris diidentifikasi lewat `(company_id, customer_tag_id, created_at)`; `DELETE /delete-template-data/{customer_tag_id}` pakai `customer_tag_id` di URL (lihat "CRUD template_data & store_data" di bawah).

### `POST /register-store-data`

Endpoint registrasi store — inilah yang **membuat** baris `store_data` yang divalidasi oleh `/input-md` dan dipakai lookup oleh `GET /view-store-image`. Form-data:
- `store_id` — cuma boleh huruf/angka/`_`/`-` (dipakai jadi nama subfolder saat `/input-md` menyimpan gambar, sama seperti `customer_tag_id`).
- `store_name` — bebas, otomatis disanitasi (karakter non alfanumerik/`-`/`_` → `_`) saat dipakai sebagai path folder, jadi aman diisi apa saja termasuk spasi.
- `customer_tag_id` — tag/layout yang dipakai store ini. **Divalidasi** ke `template_data`: harus sudah punya minimal satu baris untuk company ini (artinya `POST /register-template-data` pernah dipanggil untuk tag itu) — kalau belum, `404 "customer_tag_id missing"` (cek & pesan yang sama seperti `/input-md`).

`store_id` dan `store_name` masing-masing unik **per company** — daftar salah satunya dua kali **dalam company yang sama** akan ditolak `409` ("store_id already registered for this company" / "store_name already registered for this company"); company lain boleh pakai `store_id`/`store_name` yang sama persis. Untuk update/delete setelah terdaftar, lihat "CRUD template_data & store_data" di bawah.

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C001",
      "store_id": "STR001",
      "store_name": "Indomaret Kelapa Gading",
      "customer_tag_id": "LAYOUT_A"
    }
  ],
  "message": "SUCCESS"
}
```

### CRUD `template_data` & `store_data`

Selain `POST /register-template-data` dan `POST /register-store-data` (create), ada endpoint view/delete untuk kedua tabel — bertag Swagger `view`/`delete` (terpisah dari `register`). Tidak ada endpoint update: untuk mengganti data yang sudah terdaftar, hapus baris lama lalu register ulang. Semuanya wajib `X-API-Key`, response-nya format `{success, data: [...], message}` yang sama, dan cuma bisa melihat/menghapus baris milik `company_id` sendiri (tervalidasi dari API key). Tidak ada endpoint get-satu-baris — cuma list (semua baris company itu) dan delete by id.

**`GET /view-template-data`** — list baris `template_data` milik company, terbaru duluan, **satu halaman per panggilan** (bukan riwayat lengkap sekaligus) — company yang sudah lama bisa punya ribuan baris di sini karena tiap `POST /register-template-data` menambah baris baru (tidak pernah menimpa). Parameter query opsional: `limit` (default 50, maksimal 200 — di atas itu `422`) dan `offset` (default 0). Total jumlah baris (tanpa terpengaruh `limit`/`offset`) ada di response **header** `X-Total-Count`, bukan di body JSON — supaya bentuk `{success, data, message}`-nya tetap sama persis seperti endpoint lain.

**`DELETE /delete-template-data/{customer_tag_id}`** — hapus **seluruh riwayat** `template_data` untuk `customer_tag_id` itu (semua baris, bukan cuma yang terbaru — karena `customer_tag_id` sendiri tidak unik per baris). Setelahnya `/input-md` untuk tag ini langsung `404 "customer_tag_id missing"` sampai `POST /register-template-data` dipanggil lagi. `404 "customer_tag_id missing"` juga kalau tag itu memang tidak punya baris apa pun untuk company ini.

`data` di response **bukan array kosong** — isinya semua baris yang barusan dihapus (riwayat lengkap, terbaru duluan), masing-masing: `company_id`, `company_name`, `customer_tag_id`, `customer_tag_data`, `template_image_path`, `created_at`.

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C001",
      "company_name": "AICE",
      "customer_tag_id": "LAYOUT_A",
      "customer_tag_data": {"SUSU COKLAT": 9},
      "template_image_path": "data/uploads/template_data/AICE/LAYOUT_A/LAYOUT_A_20260827_151517.png",
      "created_at": "2026-08-27T15:15:18"
    }
  ],
  "message": "SUCCESS"
}
```

**`GET /view-store-data`** — list store milik company, **satu halaman per panggilan** (bukan semua sekaligus), dengan parameter `limit`/`offset` dan header `X-Total-Count` yang sama persis seperti `GET /view-template-data` di atas. Tiap item tambahan punya `store_image_path` — folder tempat gambar MD store itu tersimpan (`data/uploads/md_data/<company_name>/<customer_tag_id>/<store_id>_<store_name>/`), dikembalikan apa adanya walau foldernya belum pernah dibuat (belum ada `/input-md` yang dipanggil untuk store itu). Endpoint lain yang balikin store (`register-store-data`, `delete-store-data`) **tidak** punya field ini.

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C001",
      "store_id": "STR001",
      "store_name": "Indomaret Kelapa Gading",
      "customer_tag_id": "LAYOUT_A",
      "store_image_path": "data/uploads/md_data/AICE/LAYOUT_A/STR001_Indomaret_Kelapa_Gading"
    }
  ],
  "message": "SUCCESS"
}
```

**`DELETE /delete-store-data/{store_id}`** — hapus mapping-nya permanen. Foto yang sudah kepalang tersimpan di disk untuk `store_id` ini **tidak** ikut terhapus (cuma baris `store_data`-nya) — setelah dihapus, `/input-md` dan `GET /view-store-image` langsung menolak `store_id` itu (`404 "Unknown store_id"`).

`data` di response **bukan array kosong** — isinya baris yang barusan dihapus: `company_id`, `store_id`, `store_name`, `customer_tag_id` (bentuk yang sama seperti `POST /register-store-data`/`GET /view-store-data`).

### `GET /view-store-image?store_id=<STORE_ID>`

`store_id` **wajib** — satu-satunya parameter (tidak ada `customer_tag_id`, tidak ada `type`; endpoint ini cuma soal foto hasil `/input-md`, tidak pernah foto template). `store_id` dicari di `store_data` untuk `company_id` yang tervalidasi dari API key — kalau tidak ketemu → `404 "Unknown store_id"`. `customer_tag_id`-nya diambil dari baris `store_data` itu.

**Response-nya JSON** (sama format seperti endpoint lain — bukan file gambar): `company_id`, `store_id`, `store_name`, `customer_tag_id`, dan `store_image_path` yang menunjuk ke **satu file spesifik** — foto MD (yang sudah ada bounding box-nya) **paling terakhir diupload** untuk store ini (by timestamp nama file, tidak pernah baca folder company/store lain). Endpoint ini **tidak mengirim isi file gambarnya** — cuma path-nya di server; kalau butuh isi gambarnya, ambil langsung dari path itu lewat cara lain (mis. akses filesystem/shared storage), bukan lewat API ini. Tidak ada endpoint lain yang serve isi file gambar secara langsung.

```json
{
  "success": true,
  "data": [
    {
      "company_id": "C001",
      "store_id": "STR001",
      "store_name": "Indomaret Kelapa Gading",
      "customer_tag_id": "LAYOUT_A",
      "store_image_path": "data/uploads/md_data/AICE/LAYOUT_A/STR001_Indomaret_Kelapa_Gading/LAYOUT_A_20260828_154828_163867.png"
    }
  ],
  "message": "SUCCESS"
}
```

Beda dari `GET /view-store-data` yang `store_image_path`-nya menunjuk ke **folder** (foto belum tentu ada) — di sini menunjuk ke **file** yang sudah pasti ada (kalau belum ada foto sama sekali, balasnya `404 "No image has been uploaded yet"`, bukan path kosong).

Response error (400/401/404/409/422/503, lihat bagian bawah) untuk semua endpoint **juga** dibungkus format `{"success": false, "data": [...], "message": "..."}` yang sama — bukan format `{"detail": ...}` bawaan FastAPI. Ini berlaku global lewat exception handler di `app/main.py` (`http_exception_handler`, `validation_exception_handler`, `unhandled_exception_handler`) — mencakup semua `HTTPException` yang di-raise di kode, semua request validation error bawaan FastAPI/Pydantic (mis. field wajib yang tidak diisi), dan exception tak terduga lainnya (dibalas `500`).

- `message` berisi apa pun yang tadinya ada di `detail`: string untuk kebanyakan error, atau object/list untuk kasus tertentu (mis. body `422` dari `_validate_paths` yang isinya `{"company_id": ..., "errors": [...]}`, atau `422` dari validasi request FastAPI sendiri yang isinya list of objects).
- `data` **bukan lagi selalu `null`** — isinya list berisi satu object dengan field yang **PERSIS SAMA, satu-satu, dengan yang dikembalikan endpoint itu saat sukses** (bukan subset — setiap key yang ada di bentuk sukses selalu ada juga di bentuk error), diisi dengan nilai yang berhasil diketahui sebelum request-nya gagal; field yang belum sempat diketahui jadi `null` (bukan hilang dari object-nya). Field per endpoint (di `app/main.py:_ERROR_FIELDS_BY_PREFIX`, disalin field-for-field dari response model sukses masing-masing):
  - `/register-company-data`: `company_id`, `company_name`, `api_key`, `model_path`, `embed_path`, `data_path`.
  - `/test-detect`: `company_id`, `total_item`, `total_product`, `list_product`.
  - `/input-md`: `company_id`, `customer_tag_id`, `store_id`, `image_path`, `total_item`, `total_product`, `list_product`, `missing_product`, `compliance_score`.
  - `/register-template-data`: `company_id`, `customer_tag_id`, `customer_tag_data`, `template_image_path`.
  - `/view-template-data`: `company_id`, `customer_tag_id`, `customer_tag_data`, `template_image_path`, `created_at`.
  - `/delete-template-data`: `company_id`, `company_name`, `customer_tag_id`, `customer_tag_data`, `template_image_path`, `created_at`.
  - `/register-store-data`, `/delete-store-data`: `company_id`, `store_id`, `store_name`, `customer_tag_id`.
  - `/view-store-data`, `/view-store-image`: `company_id`, `store_id`, `store_name`, `customer_tag_id`, `store_image_path`.

  Field yang nilainya baru diketahui SETELAH validasi lolos sepenuhnya (mis. `model_path`/`embed_path`/`data_path` yang dihitung dari `company_name`+nama file upload, atau `total_item`/`list_product` yang baru ada setelah deteksi selesai jalan) akan selalu `null` di response error — keynya tetap ada, cuma isinya memang tidak mungkin diketahui kalau requestnya gagal sebelum sampai ke titik itu.

  Contoh: `POST /test-detect` tanpa header `X-API-Key` → `401 {"success": false, "data": [{"company_id": null, "total_item": null, "total_product": null, "list_product": null}], "message": "Missing API key"}`. `GET /view-store-image?store_id=S1` dengan API key valid tapi store itu belum pernah di-`input-md` → `404 {"success": false, "data": [{"company_id": "C001", "store_id": "S1", "store_name": "Indomaret Kelapa Gading", "customer_tag_id": "LAYOUT_A", "store_image_path": null}], "message": "No image has been uploaded yet"}` — `store_name`/`customer_tag_id` tetap terisi (di-lookup ulang dari `store_data` karena `store_id`-nya sudah valid), cuma `store_image_path` yang `null` karena memang belum ada foto.

Contoh pakai `curl`:

```bash
curl -X POST "http://127.0.0.1:8000/register-company-data" \
  -F "company_id=C002" \
  -F "company_name=Nabati" \
  -F "api_key=$(python -c 'import secrets; print(secrets.token_urlsafe(32))')" \
  -F "model_path=@product.pt" \
  -F "embed_path=@embedding_model.pt"

curl -X POST "http://127.0.0.1:8000/test-detect" \
  -H "X-API-Key: <api-key-company>" \
  -F "image=@foto_rak.jpg"

# bisa kirim lebih dari satu foto sekaligus (field "images", diulang) — customer_tag_id/store_id berlaku untuk semua foto
curl -X POST "http://127.0.0.1:8000/input-md?customer_tag_id=LAYOUT_A&store_id=STR001" \
  -H "X-API-Key: <api-key-company>" \
  -F "images=@foto_rak_cek_lapangan_1.jpg" \
  -F "images=@foto_rak_cek_lapangan_2.jpg"

# customer_tag_data.json isinya: {"SUSU COKLAT": 2, "SUSU STROBERI": 3}
curl -X POST "http://127.0.0.1:8000/register-template-data" \
  -H "X-API-Key: <api-key-company>" \
  -F "image=@foto_layout.jpg" \
  -F "customer_tag_id=LAYOUT_A" \
  -F "customer_tag_data=@customer_tag_data.json;type=application/json"

curl -X POST "http://127.0.0.1:8000/register-store-data" \
  -H "X-API-Key: <api-key-company>" \
  -F "store_id=STR001" \
  -F "store_name=Indomaret Kelapa Gading" \
  -F "customer_tag_id=LAYOUT_A"

curl "http://127.0.0.1:8000/view-store-image?store_id=STR001" \
  -H "X-API-Key: <api-key-company>"

curl "http://127.0.0.1:8000/view-template-data" -H "X-API-Key: <api-key-company>"
curl "http://127.0.0.1:8000/view-store-data" -H "X-API-Key: <api-key-company>"

# halaman kedua, 20 baris per halaman — cek total lewat header X-Total-Count
curl -i "http://127.0.0.1:8000/view-template-data?limit=20&offset=20" -H "X-API-Key: <api-key-company>"

curl -X DELETE "http://127.0.0.1:8000/delete-template-data/LAYOUT_A" -H "X-API-Key: <api-key-company>"
curl -X DELETE "http://127.0.0.1:8000/delete-store-data/STR001" -H "X-API-Key: <api-key-company>"
```

Di Swagger UI (`/docs`), klik tombol **Authorize** (ikon gembok) untuk isi API key sekali — otomatis kepakai di semua percobaan endpoint setelahnya, tidak perlu isi ulang tiap request. `customer_tag_id`/`store_id` tetap harus diisi manual tiap kali (query/form parameter, bukan bagian dari Authorize).

Response error:

- `401` — header `X-API-Key` tidak dikirim ("Missing API key"), atau key-nya tidak ditemukan di database ("Invalid API key").
- `404` — `customer_tag_id` tidak punya baris di `template_data` untuk company itu ("customer_tag_id missing"); `store_id` tidak terdaftar di `store_data` untuk company itu, atau (khusus `/input-md`) tidak terdaftar di bawah `customer_tag_id` yang sama ("Unknown store_id"); atau (di `GET /view-store-image`) belum ada gambar tersimpan untuk kombinasi itu.
- `409` — `store_id` atau `store_name` sudah dipakai **dalam company yang sama** di `POST /register-store-data` ("store_id already registered for this company" / "store_name already registered for this company" — company lain boleh pakai `store_id`/`store_name` yang sama); atau (di `POST /register-company-data`) `company_id` sudah terdaftar ("company_id already registered"), `company_name` sudah dipakai ("company_name already registered"), atau `api_key`-nya sudah dipakai company lain ("api_key already in use by another company"). Juga bisa muncul dari race condition dua request bersamaan yang lolos pengecekan duplikat sebelum salah satunya commit — ditangani di level MySQL sebagai "Duplicate entry — already registered".
- `422` — API key valid, tapi konfigurasi company itu ada yang salah: `model_path`/`embed_path`/`data_path` di database (file/folder tidak ditemukan di disk), **dan/atau** FAISS index-nya belum pernah dibuild (`data/faiss_index/<company_id>/` — bukan kolom database, konvensi folder dari `company_id`, jadi kalau `company_id` diganti/rename di database tanpa ikut memindahkan foldernya, ini juga akan ke-trigger). Body response-nya cuma menyebut `company_id` dan field mana yang salah, **bukan** path filesystem aslinya (supaya tidak bocor struktur direktori server ke client) — mis.:
  ```json
  {
    "detail": {
      "company_id": "C001",
      "errors": [
        "data_path is invalid",
        "faiss_index is missing — run scripts/build_index.py for this company"
      ]
    }
  }
  ```
  Path lengkap yang dicek dicatat di server log (`logger.warning`, lihat `app/core/company.py:_validate_paths`) untuk keperluan debug. Validasi jalan tiap request, jadi begitu diperbaiki, request berikutnya langsung normal lagi tanpa perlu restart server. (Pengecekan FAISS index ini dilewati khusus saat dipanggil dari `scripts/build_index.py` sendiri — karena tugas script itu justru membuat index-nya untuk pertama kali.)
- `503` — database tidak bisa diakses setelah dicoba ulang beberapa kali (lihat "Retry otomatis di level database" di bawah) — host salah, tabel belum ada, koneksi putus terus-menerus, dll (pesan errornya menyertakan detail dari MySQL).

Catatan: nama file pakai presisi mikrodetik (`%Y%m%d_%H%M%S_%f`) — dua upload ke `customer_tag_id` (+`store_id` untuk `md`) yang sama dalam detik yang sama tetap dapat nama file berbeda, tidak saling menimpa. Antar company/store tidak pernah saling mempengaruhi (folder terpisah per `company_name`/`customer_tag_id`, dan untuk `md` juga `store_id`_`store_name`, di mana `company_name` di-resolve dari API key dan `store_name` dari `store_data`, bukan dari input client mentah).

### Retry otomatis di level database

Setiap panggilan ke MySQL (lewat `app/core/db.py:_query_one`/`_query_all`/`_execute`/`_execute_rowcount`) otomatis dicoba ulang sampai `mysql_retry_max_attempts` kali (default 3, bisa diatur lewat env `PLANOGRAM_MYSQL_RETRY_MAX_ATTEMPTS`) **hanya** untuk error yang murni soal timing dan besar kemungkinan hilang kalau dicoba lagi sesaat kemudian:

- **Deadlock** (MySQL errno 1213) dan **lock wait timeout** (1205) — transaksi belum pernah `commit()` saat error ini terjadi, jadi retry tidak pernah menyebabkan efek dobel.
- **Koneksi putus/gagal** (2003 "Can't connect", 2006 "server has gone away", 2013 "Lost connection") — request belum sempat terkirim/selesai, aman diulang.

Jeda antar percobaan naik dua kali lipat tiap retry (mulai dari `mysql_retry_base_delay_seconds`, default `0.02` detik) plus sedikit acak (jitter), supaya kalau ada beberapa request yang retry bersamaan, mereka tidak langsung tabrakan lagi di percobaan berikutnya. Total tambahan waktu tunggu di skenario terburuk cuma puluhan-ratusan milidetik.

**Error yang SENGAJA tidak di-retry** — karena mengulang tidak akan pernah mengubah hasilnya:
- **Duplicate key** (1062, dua request bikin `company_id`/`store_id` yang sama nyaris bersamaan) — ini konflik data permanen begitu salah satu berhasil commit, langsung dibalas `409`, bukan `503`. Client **tidak seharusnya** retry otomatis atas `409` ini.
- Error SQL lain (mis. query salah, kolom tidak ada) — bukan soal timing, mengulang cuma buang waktu.

Retry ini terjadi **di dalam satu request yang sama**, sebelum server membalas ke client — jadi kalau retry akhirnya berhasil, client yang memanggil tidak pernah melihat error sama sekali, cuma menunggu sedikit lebih lama. Retry pada satu request tidak menahan request lain yang berjalan bersamaan — kecuali kalau memang seluruh connection pool (lihat "Connection pooling" di bawah) sedang penuh terpakai, di mana request baru wajar menunggu giliran sampai ada koneksi yang kosong, terlepas dari retry ini.

### Connection pooling

`app/core/db.py` memakai **connection pool** (lewat library `DBUtils`) — koneksi ke MySQL dibuka sekali lalu dipakai berulang-ulang untuk banyak query, bukan dibuka-tutup tiap satu query seperti sebelumnya. Manfaatnya: menghindari overhead jabat-tangan TCP+autentikasi MySQL di setiap query, dan membatasi jumlah koneksi bersamaan supaya tidak membentur `max_connections` MySQL saat traffic ramai.

- `mysql_pool_max_connections` (default `10`, env `PLANOGRAM_MYSQL_POOL_MAX_CONNECTIONS`) — batas keras jumlah koneksi yang boleh dibuka **per proses**. Kalau nanti pakai beberapa worker (`--workers` > 1 saat menjalankan uvicorn), tiap worker punya pool-nya sendiri-sendiri — jadi total koneksi ke MySQL kira-kira `mysql_pool_max_connections × jumlah worker`, pastikan itu tetap di bawah `max_connections` MySQL server-nya.
- Pool **tidak** membuka koneksi apa pun saat aplikasi baru start (`mincached=0`) — koneksi pertama baru dibuka saat benar-benar ada query yang jalan. Ini disengaja: kalau MySQL kebetulan belum siap tepat saat proses API baru menyala, aplikasi tetap **berhasil start** dan cuma request yang butuh DB yang gagal `503` sampai MySQL siap — bukan seluruh aplikasi gagal start total.
- Kalau semua koneksi di pool sedang dipakai dan ada request baru datang, dia **menunggu** (bukan langsung gagal) sampai ada koneksi yang kosong — perilaku ini bawaan `DBUtils` (`blocking=True`).

### Rate limiting

Semua endpoint dibatasi **satu limit bersama** (`rate_limit_default`, default `60/minute`, env `PLANOGRAM_RATE_LIMIT_DEFAULT`) lewat library `slowapi` — melebihi batas ini balas `429`:
```json
{ "success": false, "data": [...], "message": "Rate limit exceeded: 60 per 1 minute" }
```

- **Dibatasi per `X-API-Key`** kalau headernya ada — tiap company punya "jatah" sendiri, satu company yang boros tidak menghabiskan jatah company lain. Kalau tidak ada `X-API-Key` (termasuk `POST /register-company-data`, yang memang tidak pakai header itu, atau request dengan key yang salah/hilang), dibatasi per **IP client** sebagai gantinya.
- **`register-company-data` sengaja TIDAK dikasih limit terpisah yang lebih ketat** meski ini endpoint paling sensitif — sempat dicoba (`@limiter.limit(...)` per-route), tapi ternyata `slowapi` cuma menjalankan limit per-route itu **setelah** dependency route itu sendiri (di sini, cek `X-Admin-Token`) lolos duluan. Karena percobaan token yang salah gagal duluan di dependency, limit khusus itu tidak pernah sempat dicek — dan yang lebih parah, keberadaan limit per-route itu membuat `slowapi` **mengecualikan endpoint ini dari limit umum juga**, jadi percobaan brute-force token admin malah jadi sama sekali tidak dibatasi. Limit tunggal yang berlaku ke semua endpoint ini (dicek di middleware, sebelum dependency apa pun jalan) ternyata justru **lebih aman** untuk endpoint ini dibanding limit "khusus" yang dicoba.
- Penghitungnya tersimpan di **memori proses** (bukan Redis/database) — benar untuk 1 worker (default saat ini). Kalau nanti pakai beberapa `UVICORN_WORKERS`, tiap worker menghitung sendiri-sendiri, jadi limit efektifnya jadi `rate_limit_default × jumlah worker`.

### Logging & traceback error

`app/main.py` memanggil `logging.basicConfig(level=log_level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")` di awal — mengatur format semua log lewat modul `logging` standar Python (level default `INFO`, env `PLANOGRAM_LOG_LEVEL`), bukan cuma andalan format bawaan Python yang polos tanpa timestamp/level.

**Setiap error `500` (exception tak terduga) sekarang mencatat traceback lengkap** ke log server lewat `logger.exception(...)` di `unhandled_exception_handler`, sebelum dibalas ke client sebagai `{"success": false, ..., "message": str(exc)}`. Sebelumnya, satu-satunya jejak error 500 di produksi cuma satu baris `message_log` di tabel `logs` (isinya `str(exc)` saja, tanpa traceback/nomor baris) — tidak cukup untuk tahu di mana persis bug-nya terjadi tanpa mereproduksi manual. Sekarang traceback lengkap (termasuk file+baris kode yang error) tercetak ke stdout/stderr proses, yang otomatis tertangkap sink log yang dipakai (journald, cloud logging, dst) — independen dari apa pun yang tersimpan di MySQL.

**Belum ada** alerting otomatis (notifikasi email/Slack/dsb saat ada error) atau integrasi tracking pihak ketiga (Sentry, OpenTelemetry) — itu keputusan yang sengaja ditunda, karena butuh akun/layanan eksternal yang perlu disiapkan terpisah. Traceback yang sekarang tercatat cukup untuk debug manual lewat log server, tapi tidak ada yang otomatis memberi tahu kalau error itu terjadi.

## Keamanan deployment

### Token admin untuk `register-company-data`

`POST /register-company-data` tidak punya `api_key` per-company untuk divalidasi (dia sendiri yang membuat company-nya) — jadi diproteksi terpisah lewat header `X-Admin-Token`, dicocokkan ke `PLANOGRAM_ADMIN_TOKEN` (satu secret bersama untuk siapa pun yang mengelola deployment ini, bukan untuk dibagikan ke pengguna API biasa).

```bash
# generate sekali di awal, simpan sebagai env var PLANOGRAM_ADMIN_TOKEN
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

Wajib di-set sebelum deploy — kalau kosong, endpoint ini **selalu** balas `503` untuk siapa pun (fail-closed), bukan diam-diam terbuka. Simpan nilainya di `.env` (jangan commit ke git — sudah ada di `.gitignore`) atau lewat secret manager platform hosting kamu (mis. environment variable di dashboard cloud provider, bukan hardcode di kode).

### Membatasi akses `register-company-data` di level jaringan

Token admin di atas itu lapisan pertama — tetap disarankan **tambah pembatasan di level jaringan juga**, supaya kalau suatu saat token bocor atau salah konfigurasi, endpoint ini masih tidak bisa dijangkau sembarang orang dari internet. Dua pendekatan paling praktis:

**1. Reverse proxy (nginx) — batasi IP yang boleh akses path ini:**
```nginx
location /register-company-data {
    allow 10.0.0.0/8;       # jaringan internal/VPN kantor
    allow 203.0.113.5;      # IP admin tertentu
    deny all;
    proxy_pass http://127.0.0.1:8000;
}

location / {
    proxy_pass http://127.0.0.1:8000;
}
```

**2. Firewall/security group di level server/cloud** — kalau API di-deploy di cloud (AWS/GCP/Azure/VPS), atur security group/firewall supaya port yang diekspos ke internet publik cuma bisa diakses lewat reverse proxy di atas (yang sudah menyaring path ini), bukan langsung ke proses `uvicorn`. Kalau memang tidak ada kebutuhan mendaftarkan company dari jarak jauh sama sekali, alternatif paling aman adalah **tidak expose endpoint ini ke internet sama sekali** — buka aksesnya cuma dari dalam VPN/jaringan internal, atau pakai `scripts/setup_company.py` langsung di server (butuh akses shell, bukan HTTP) sebagai gantinya.

Dua lapis ini saling melengkapi (defense in depth) — token admin menahan kalau firewall salah konfigurasi/berubah, firewall menahan kalau token bocor.

### Kredensial database

Default `PLANOGRAM_MYSQL_USER=root` + `PLANOGRAM_MYSQL_PASSWORD=` (kosong) itu cuma masuk akal untuk instalasi XAMPP/MySQL lokal yang baru diinstal — **root** punya akses ke *seluruh* server MySQL (semua database, bukan cuma `planogram_data`, plus bisa `CREATE`/`DROP` apa saja), jadi kalau kredensial ini bocor atau kebawa ke server produksi, dampaknya jauh lebih luas daripada sekadar data planogram. Server sekarang mencatat **peringatan di log saat startup** kalau konfigurasi ini masih dipakai (lihat `app/main.py`) — tidak menghentikan server (supaya dev lokal tetap jalan), cuma pengingat.

Sebelum deploy, buat user MySQL khusus dengan privilese seminim mungkin — cuma `SELECT`/`INSERT`/`UPDATE`/`DELETE` ke database `planogram_data`, tidak lebih:

```sql
CREATE USER 'planogram_app'@'localhost' IDENTIFIED BY 'password-kuat-di-sini';
GRANT SELECT, INSERT, UPDATE, DELETE ON planogram_data.* TO 'planogram_app'@'localhost';
FLUSH PRIVILEGES;
```

(Ganti `'localhost'` dengan IP/host tempat aplikasi API-nya jalan kalau MySQL-nya di server terpisah, mis. `'planogram_app'@'10.0.0.5'`.) Lalu isi `PLANOGRAM_MYSQL_USER`/`PLANOGRAM_MYSQL_PASSWORD` di `.env` dengan kredensial user baru ini, bukan `root`. Dengan begini, kalau kredensial ini suatu saat bocor, penyerang cuma bisa baca/ubah 4 tabel milik app ini — tidak bisa akses database lain di server yang sama, dan `DROP TABLE`/`CREATE USER` akan ditolak MySQL.

### `api_key` disimpan sebagai hash, bukan plaintext

`company_data.api_key_hash` menyimpan `SHA-256(api_key)` (64 karakter hex), bukan nilai `api_key` aslinya — kalau tabel ini bocor (mis. backup database ke-upload tidak sengaja, atau server diakses paksa), penyerang cuma dapat hash yang tidak bisa dipakai langsung sebagai `X-API-Key` yang valid, bukan key siap pakai. Lihat `app/core/security.py:hash_api_key()`.

Sengaja dipakai hash **cepat & deterministik** (SHA-256), bukan hash lambat+garam seperti bcrypt/argon2 yang dipakai untuk password login manusia — alasannya:
- Password manusia berentropi rendah (rawan ditebak lewat kombinasi kata umum), jadi hash-nya sengaja dibuat lambat untuk memperlambat brute-force. `api_key` di sini sudah string acak yang di-generate/dipilih sebagai credential mesin-ke-mesin — ruang tebakannya sudah sangat besar, hash lambat tidak menambah perlindungan berarti.
- SHA-256 deterministik (input sama → hash selalu sama persis), jadi lookup-nya tetap satu langkah `WHERE api_key_hash = SHA256(<yang dikirim client>)` — sama cepatnya seperti lookup lama, bukan "ambil semua baris lalu verifikasi satu-satu" seperti bcrypt.
- Dari sisi client **tidak ada yang berubah** — tetap kirim `X-API-Key` yang sama seperti biasa; server yang menghitung hash-nya di baliknya (`app/core/db.py:fetch_company_by_api_key()` saat lookup, `insert_company()` saat `register-company-data`).

Konsekuensinya: `api_key` asli **tidak pernah bisa dibaca ulang** dari database (termasuk oleh admin) — satu-satunya salinan yang beredar adalah yang dikembalikan sekali di response `POST /register-company-data`. Kalau hilang, tidak ada cara "lihat lagi" — solusinya hapus baris `company_data` lama lalu `register-company-data` ulang dengan `api_key` baru.

**`api_key` juga di-mask dari tabel `logs`.** Middleware pencatat log (`app/main.py:log_requests`) menyimpan **seluruh response body** tiap request ke kolom `logs.message_log` — termasuk field `api_key` di response `register-company-data`, kalau tidak ditangani khusus. `app/main.py:_mask_api_key()` mengganti nilai field `api_key` jadi `"***"` sebelum ditulis ke `logs` (baik untuk request sukses maupun gagal) — client yang memanggil endpoint-nya tetap menerima `api_key` asli di response HTTP-nya seperti biasa, cuma salinan yang masuk ke `logs` (dan otomatis ikut ke CSV arsip logs bulanan, lihat "Retensi logs") yang di-mask. Tanpa ini, hashing di `company_data` di atas jadi percuma — `api_key` plaintext tetap bisa ditemukan lewat tabel `logs`.

## Test

```bash
pytest tests/
```

- `tests/test_compliance_scorer.py` — unit test murni, tidak butuh apa pun di luar Python (modul `app/compliance/` ini sendiri tidak dipakai endpoint mana pun, lihat "Arsitektur").
- `tests/test_api.py` — **butuh MySQL yang bisa diakses**, sama seperti menjalankan API-nya sendiri. Ini test integrasi sungguhan (bukan mock/in-memory) yang menyentuh 9 dari 10 endpoint lewat `TestClient` — mendaftarkan satu company sekali di awal sesi test (`tests/conftest.py`), menjalankan skenario sukses & error penting (termasuk regresi bug yang pernah ditemukan: race condition duplikat, all-or-nothing `input-md`, `compliance_score`, dst), lalu membersihkan semua baris DB + folder yang dibuatnya di akhir sesi — apa pun hasil test-nya (lolos/gagal).
  - Deteksi YOLO/embedding **tidak dijalankan sungguhan** — endpoint `/test-detect` dan `/input-md` di-stub (`stub_pipeline` fixture) supaya test tetap cepat & deterministik tanpa perlu model `.pt` asli.
- `tests/test_archive_logs.py` — test untuk `scripts/archive_logs.py` (lihat "Retensi logs"). **Otomatis di-skip** kalau `PLANOGRAM_MYSQL_ADMIN_USER` belum di-set (tidak wajib punya kredensial admin cuma untuk jalankan test biasa) — untuk benar-benar menjalankannya:
    ```bash
    PLANOGRAM_MYSQL_HOST=localhost PLANOGRAM_MYSQL_ADMIN_USER=root PLANOGRAM_MYSQL_ADMIN_PASSWORD= pytest tests/test_archive_logs.py
    ```
