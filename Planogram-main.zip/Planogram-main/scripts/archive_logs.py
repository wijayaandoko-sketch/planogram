"""Archives one calendar month of the `logs` table to CSV, then drops that
month's MySQL partition — see README.md "Retensi logs" for the full
design discussion.

Output layout:
    data/logs_archive/all/logs_<YYYY-MM>.csv                        — every row
    data/logs_archive/<company_id>_<company_name>/<same>_logs_<YYYY-MM>.csv
                                                                     — that company's rows only

Safety, in order — never violated regardless of when a previous run of
this script stopped (crash, Ctrl-C, killed process, ...):
    1. Every CSV is written to a ".tmp" file first, then atomically
       renamed into place only after its row count is confirmed to match
       what was read from the database.
    2. The month's MySQL partition is dropped ONLY after every CSV for
       that month (the "all" one and every per-company one) exists and is
       verified — never before.
    3. Re-running for a month that's already fully done (CSV exists,
       partition already gone) is a safe no-op. Re-running for a month
       that got interrupted after the CSV was written but before the
       partition was dropped resumes from there — it does NOT re-export
       (avoids clobbering a good file) but does re-verify row counts
       before proceeding to drop.

Usage:
    python scripts/archive_logs.py                  # last full calendar month
    python scripts/archive_logs.py --month 2026-08   # a specific month
"""

import argparse
import csv
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.config import settings  # noqa: E402
from app.core.db import fetch_logs_for_period  # noqa: E402
from app.core.db_admin import carve_month_partition, drop_partition, partition_exists  # noqa: E402

_UNSAFE = re.compile(r"[^A-Za-z0-9_-]+")


def _safe_component(value: str) -> str:
    cleaned = _UNSAFE.sub("_", value or "")
    return cleaned or "unknown"


def _month_bounds(year: int, month: int) -> tuple[datetime, datetime]:
    start = datetime(year, month, 1)
    end = datetime(year + 1, 1, 1) if month == 12 else datetime(year, month + 1, 1)
    return start, end


def _csv_row_count(path: Path) -> int:
    """Data rows only (excludes the header) — used to re-verify a CSV a
    previous run already wrote, before trusting it enough to proceed to
    dropping the partition."""
    with path.open(newline="", encoding="utf-8") as f:
        return sum(1 for _ in csv.reader(f)) - 1


def _write_csv_atomic(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    actual = _csv_row_count(tmp)
    if actual != len(rows):
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"Wrote {actual} rows to {tmp} but expected {len(rows)} — aborting, nothing renamed")
    tmp.replace(path)  # atomic on the same filesystem — never leaves a half-written file at the final name


def archive_month(year: int, month: int) -> None:
    label = f"{year:04d}-{month:02d}"
    partition_name = f"p{year:04d}{month:02d}"
    start, end = _month_bounds(year, month)
    archive_root = settings.data_dir / "logs_archive"
    all_csv = archive_root / "all" / f"logs_{label}.csv"

    # Always re-query the live table for this month first — never trust
    # "the CSV file exists" alone as proof there's nothing left to do.
    # created_at is always server-generated (CURRENT_TIMESTAMP, never
    # client-supplied) so a row backdated into an already-archived month
    # shouldn't normally happen — but if it ever did (a bug elsewhere, a
    # manual INSERT, restoring a backup, ...), this still needs to be
    # noticed rather than silently skipped just because a same-named CSV
    # happens to already exist from a previous, smaller export.
    rows = fetch_logs_for_period(start, end)

    if not rows:
        if partition_exists(partition_name):
            print(f"[{label}] no rows, dropping the (empty) partition")
            drop_partition(partition_name)
        else:
            print(f"[{label}] no rows — nothing to do (already archived, or never had data)")
        return

    fieldnames = list(rows[0].keys())

    if all_csv.exists():
        existing_count = _csv_row_count(all_csv)
        if existing_count != len(rows):
            raise RuntimeError(
                f"[{label}] {all_csv} already exists with {existing_count} rows, but the live table "
                f"currently has {len(rows)} rows for this month — refusing to proceed automatically. "
                "This shouldn't happen (past months' rows never change on their own) — investigate "
                "by hand (e.g. a stray backdated INSERT) before re-running."
            )
        if not partition_exists(partition_name):
            print(f"[{label}] already fully archived and verified consistent — nothing to do")
            return
        print(f"[{label}] {all_csv} already written and verified — resuming (partition not dropped yet)")
    else:
        _write_csv_atomic(all_csv, rows, fieldnames)
        print(f"[{label}] wrote {all_csv} ({len(rows)} rows)")

    by_company: dict[str, list[dict]] = {}
    for row in rows:
        company_id = row.get("company_id") or ""
        if company_id:
            by_company.setdefault(company_id, []).append(row)

    for company_id, company_rows in by_company.items():
        company_name = company_rows[0].get("company_name") or ""
        folder_name = f"{_safe_component(company_id)}_{_safe_component(company_name)}"
        company_csv = archive_root / folder_name / f"{folder_name}_logs_{label}.csv"
        if company_csv.exists():
            existing_count = _csv_row_count(company_csv)
            if existing_count != len(company_rows):
                raise RuntimeError(
                    f"[{label}] {company_csv} already exists with {existing_count} rows, expected "
                    f"{len(company_rows)} — refusing to proceed."
                )
        else:
            _write_csv_atomic(company_csv, company_rows, fieldnames)
            print(f"[{label}] wrote {company_csv} ({len(company_rows)} rows)")

    without_company = len(rows) - sum(len(v) for v in by_company.values())
    accounted_for = sum(len(v) for v in by_company.values()) + without_company
    if accounted_for != len(rows):
        raise RuntimeError(f"[{label}] internal consistency check failed ({accounted_for} != {len(rows)})")

    if not partition_exists(partition_name):
        carve_month_partition(partition_name, int(end.timestamp()))
        print(f"[{label}] carved out partition {partition_name}")

    drop_partition(partition_name)
    print(f"[{label}] dropped partition {partition_name} — done ({len(rows)} rows archived, {len(by_company)} companies)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--month", help="YYYY-MM to archive; default is the last full calendar month")
    args = parser.parse_args()

    if args.month:
        year_str, month_str = args.month.split("-")
        year, month = int(year_str), int(month_str)
    else:
        first_of_this_month = datetime.now().replace(day=1)
        last_month_end = first_of_this_month - timedelta(days=1)
        year, month = last_month_end.year, last_month_end.month

    archive_month(year, month)


if __name__ == "__main__":
    main()
