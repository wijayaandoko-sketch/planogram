from dataclasses import dataclass

from fastapi import HTTPException

from app.core.db import fetch_store


@dataclass
class StoreRecord:
    store_id: str
    store_name: str


def resolve_store(company_id: str, customer_tag_id: str, store_id: str) -> StoreRecord:
    """store_id must be pre-registered in store_data for this exact
    (company_id, customer_tag_id) pair — a store belongs to one tag. Same
    404 whether store_id doesn't exist at all, belongs to another
    company, or is registered under a different customer_tag_id."""
    row = fetch_store(company_id, store_id, customer_tag_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Unknown store_id")
    return StoreRecord(store_id=store_id, store_name=row["store_name"])
