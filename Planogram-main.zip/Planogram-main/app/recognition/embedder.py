from pathlib import Path

import numpy as np
import timm
import torch
import torch.nn.functional as F
from PIL import Image
from torch import nn
from torchvision import transforms

from app.core.config import settings


class ProductEmbedder(nn.Module):
    """EfficientNet backbone producing L2-normalized product embeddings.

    If a fine-tuned checkpoint exists at checkpoint_path (trained
    externally, e.g. via Colab — typically models/<company>/embedding_model.pt),
    it's loaded automatically; otherwise this falls back to the plain
    pretrained-ImageNet backbone.
    """

    def __init__(
        self,
        model_name: str | None = None,
        checkpoint_path: Path | None = None,
        auto_load_checkpoint: bool = True,
    ):
        super().__init__()
        model_name = model_name or settings.embedding_model_name

        self.backbone = timm.create_model(model_name, pretrained=True, num_classes=0)
        self.embedding_dim = self.backbone.num_features

        if auto_load_checkpoint and checkpoint_path is not None and checkpoint_path.exists():
            self.load_finetuned(checkpoint_path)

        self.preprocess = transforms.Compose(
            [
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ]
        )

    def load_finetuned(self, backbone_state_dict_path) -> None:
        """Loads a fine-tuned backbone state_dict (trained externally)."""
        state_dict = torch.load(backbone_state_dict_path, map_location="cpu")
        self.backbone.load_state_dict(state_dict)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)
        return F.normalize(features, dim=1)

    @torch.no_grad()
    def embed_image(self, image: Image.Image) -> np.ndarray:
        self.eval()
        tensor = self.preprocess(image.convert("RGB")).unsqueeze(0)
        embedding = self.forward(tensor)
        return embedding.squeeze(0).cpu().numpy()

    @torch.no_grad()
    def embed_batch(self, images: list[Image.Image]) -> np.ndarray:
        self.eval()
        tensors = torch.stack([self.preprocess(img.convert("RGB")) for img in images])
        embeddings = self.forward(tensors)
        return embeddings.cpu().numpy()
