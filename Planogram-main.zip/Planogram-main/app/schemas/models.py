from enum import Enum

from pydantic import BaseModel, Field


class BoundingBox(BaseModel):
    x1: float
    y1: float
    x2: float
    y2: float

    @property
    def center_x(self) -> float:
        return (self.x1 + self.x2) / 2

    @property
    def center_y(self) -> float:
        return (self.y1 + self.y2) / 2

    @property
    def height(self) -> float:
        return self.y2 - self.y1


class Detection(BaseModel):
    box: BoundingBox
    detection_confidence: float
    sku_id: str | None = None
    sku_confidence: float | None = None


class PlanogramSlot(BaseModel):
    row: int
    column: int
    sku_id: str
    facings: int = 1


class Planogram(BaseModel):
    planogram_id: str
    store_id: str | None = None
    fixture_name: str | None = None
    slots: list[PlanogramSlot]


class SlotStatus(str, Enum):
    CORRECT = "correct"
    MISPLACED = "misplaced"
    MISSING = "missing"
    UNEXPECTED = "unexpected"
    LOW_CONFIDENCE = "low_confidence"


class SlotResult(BaseModel):
    row: int
    column: int
    expected_sku_id: str | None = None
    detected_sku_id: str | None = None
    status: SlotStatus
    detection: Detection | None = None


class ComplianceResult(BaseModel):
    planogram_id: str
    compliance_score: float = Field(ge=0.0, le=1.0)
    total_slots: int
    correct_slots: int
    misplaced_slots: int
    missing_slots: int
    unexpected_slots: int
    slot_results: list[SlotResult]
