from app.planogram.matcher import assign_grid_positions
from app.schemas.models import (
    ComplianceResult,
    Detection,
    Planogram,
    SlotResult,
    SlotStatus,
)


def score_compliance(planogram: Planogram, detections: list[Detection]) -> ComplianceResult:
    """Compares detected+recognized products against the reference planogram.

    Detections are mapped to (row, column) grid positions by physical layout
    (assign_grid_positions), then each expected slot is checked against
    whatever landed in that position. Detections falling outside any
    expected slot are reported as unexpected.
    """
    expected_by_position = {(slot.row, slot.column): slot for slot in planogram.slots}
    detected_by_position = assign_grid_positions(detections)

    all_positions = set(expected_by_position) | set(detected_by_position)

    slot_results: list[SlotResult] = []
    correct = misplaced = missing = unexpected = 0

    for row, column in sorted(all_positions):
        expected_slot = expected_by_position.get((row, column))
        detection = detected_by_position.get((row, column))

        expected_sku_id = expected_slot.sku_id if expected_slot else None
        detected_sku_id = detection.sku_id if detection else None

        if expected_slot is None and detection is not None:
            status = SlotStatus.UNEXPECTED
            unexpected += 1
        elif expected_slot is not None and detection is None:
            status = SlotStatus.MISSING
            missing += 1
        elif detected_sku_id is None:
            status = SlotStatus.LOW_CONFIDENCE
            missing += 1
        elif detected_sku_id == expected_sku_id:
            status = SlotStatus.CORRECT
            correct += 1
        else:
            status = SlotStatus.MISPLACED
            misplaced += 1

        slot_results.append(
            SlotResult(
                row=row,
                column=column,
                expected_sku_id=expected_sku_id,
                detected_sku_id=detected_sku_id,
                status=status,
                detection=detection,
            )
        )

    total_expected_slots = len(expected_by_position)
    compliance_score = correct / total_expected_slots if total_expected_slots else 0.0

    return ComplianceResult(
        planogram_id=planogram.planogram_id,
        compliance_score=compliance_score,
        total_slots=total_expected_slots,
        correct_slots=correct,
        misplaced_slots=misplaced,
        missing_slots=missing,
        unexpected_slots=unexpected,
        slot_results=slot_results,
    )
