from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Company lookup (api_key -> model_path/embed_path/data_path) comes from
    # MySQL (see app/core/db.py, app/core/company.py). Those three columns
    # store paths *relative* to models_dir/data_dir below — e.g.
    # model_path="AICE/product.pt" resolves to models_dir/"AICE/product.pt".
    # FAISS index and upload storage aren't in that table, so they still
    # follow a company_id-based folder convention:
    #   data/faiss_index/<company_id>/index.faiss, sku_ids.json
    #   data/uploads/<company_id>/latest.png
    models_dir: Path = Path("models")
    data_dir: Path = Path("data")
    planogram_dir: Path = Path("data/planograms")
    faiss_index_dir: Path = Path("data/faiss_index")
    uploads_dir: Path = Path("data/uploads")

    mysql_host: str = "localhost"
    mysql_port: int = 3306
    mysql_user: str = "root"
    mysql_password: str = ""
    mysql_database: str = "planogram_data"
    mysql_table: str = "company_data"
    mysql_template_table: str = "template_data"
    mysql_store_table: str = "store_data"
    mysql_logs_table: str = "logs"
    # How many times a single DB call retries after a purely transient
    # error (deadlock, lock wait timeout, dropped connection) before giving
    # up as 503 — see app/core/db.py:_with_retry(). Delay doubles each
    # attempt, starting from mysql_retry_base_delay_seconds.
    mysql_retry_max_attempts: int = 3
    mysql_retry_base_delay_seconds: float = 0.02
    # Hard cap on connections this process keeps open to MySQL at once (see
    # app/core/db.py's connection pool) — per-process, so with multiple
    # uvicorn workers each one gets its own pool up to this size; keep the
    # total (this × worker count) comfortably under MySQL's own
    # max_connections. Reusing a small set of long-lived connections avoids
    # paying a fresh TCP+auth handshake on every single query.
    mysql_pool_max_connections: int = 10

    # Separate, more privileged credentials used ONLY by maintenance
    # scripts (scripts/archive_logs.py) that need ALTER TABLE (partition
    # maintenance) — the app's own runtime user (mysql_user above) is
    # deliberately least-privilege and does NOT have this (see README.md
    # "Kredensial database"). Empty by default; archive_logs.py refuses to
    # run without these set rather than silently trying with the wrong
    # (and appropriately unprivileged) credentials.
    mysql_admin_user: str = ""
    mysql_admin_password: str = ""

    # Rate limit (see app/core/rate_limit.py) — syntax from the `limits`
    # library, e.g. "60/minute", "10/second". Applies to every endpoint
    # uniformly, including register-company-data — a per-route override
    # was tried for that endpoint specifically but had to be dropped (see
    # git history/PR notes): slowapi only enforces a per-route @limit
    # once the route's OWN dependencies (here, the X-Admin-Token check)
    # already succeeded, so a route-specific decorator on
    # register-company-data left wrong-token brute-force attempts on it
    # completely unlimited instead of extra-protected — worse than this
    # single shared default, which is checked in middleware before any
    # route dependency runs. Keyed per X-API-Key when present (each
    # company gets its own bucket — one company being noisy never eats
    # another's quota) or per client IP otherwise (register-company-data,
    # or any request missing/wrong on X-API-Key). Counters live in-process
    # memory — correct for a single uvicorn worker (the default); with
    # multiple workers each one counts independently, so the *effective*
    # limit scales up with worker count.
    rate_limit_default: str = "100/minute"

    # Shared secret required in the X-Admin-Token header for
    # POST /register-company-data (see app/api/routes/company.py) — this
    # endpoint has no per-company API key to check (it's what CREATES a
    # company), so without this it's wide open to anyone who can reach it.
    # Empty by default so a deployment that forgets to set this fails
    # CLOSED (every request 503s) rather than silently open. Set via
    # PLANOGRAM_ADMIN_TOKEN — never commit a real value to .env.example.
    admin_token: str = ""

    yolo_conf_threshold: float = 0.25
    yolo_iou_threshold: float = 0.45
    yolo_imgsz: int = 1280

    embedding_model_name: str = "efficientnet_b0"

    recognition_top_k: int = 5
    recognition_min_similarity: float = 0.15

    shelf_row_cluster_eps_ratio: float = 0.5

    # Root logging level (see app/main.py's logging.basicConfig call) —
    # "DEBUG"/"INFO"/"WARNING"/"ERROR". Controls everything logged via the
    # standard `logging` module app-wide, including the full traceback
    # unhandled_exception_handler now logs for every 500.
    log_level: str = "INFO"

    # Hard caps on upload size, enforced by reading at most (limit + 1)
    # bytes per file (see app/api/routes/_common.py:read_upload_bounded())
    # rather than reading the whole thing first and checking len() after —
    # that would already have let an arbitrarily large file fill memory/
    # disk before being rejected, which is exactly what this exists to
    # prevent. Images: generous for a real photo (even high-res phone
    # photos are usually a few MB) while still refusing anything wildly
    # oversized. Models: generous for a real custom-trained YOLO/embedding
    # checkpoint (up to a couple hundred MB) while still refusing a
    # multi-GB upload.
    max_image_upload_bytes: int = 10 * 1024 * 1024
    max_model_upload_bytes: int = 500 * 1024 * 1024
    # customer_tag_data's uploaded .json file (per-SKU counts) — plenty for
    # even a very large SKU list, no reason for this to ever approach an
    # image-sized upload.
    max_json_upload_bytes: int = 1 * 1024 * 1024

    model_config = SettingsConfigDict(env_prefix="PLANOGRAM_", env_file=".env")


settings = Settings()
