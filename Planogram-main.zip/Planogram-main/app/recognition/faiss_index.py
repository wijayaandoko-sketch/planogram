import json
from pathlib import Path

import faiss
import numpy as np

from app.core.config import settings


class SkuFaissIndex:
    """Wraps a FAISS index over L2-normalized product embeddings.

    Uses inner product on normalized vectors as cosine similarity, and an
    IVF index once the catalog is large enough that a flat scan is too slow.
    """

    def __init__(self, embedding_dim: int | None = None):
        self.embedding_dim = embedding_dim
        self.index: faiss.Index | None = None
        self.sku_ids: list[str] = []

    def build(self, embeddings: np.ndarray, sku_ids: list[str], use_ivf_above: int = 50_000) -> None:
        if embeddings.shape[0] != len(sku_ids):
            raise ValueError("embeddings and sku_ids must have the same length")
        self.embedding_dim = embeddings.shape[1]
        embeddings = np.ascontiguousarray(embeddings.astype(np.float32))
        faiss.normalize_L2(embeddings)

        if embeddings.shape[0] > use_ivf_above:
            nlist = max(1, int(np.sqrt(embeddings.shape[0])))
            quantizer = faiss.IndexFlatIP(self.embedding_dim)
            index = faiss.IndexIVFFlat(quantizer, self.embedding_dim, nlist, faiss.METRIC_INNER_PRODUCT)
            index.train(embeddings)
            index.add(embeddings)
            index.nprobe = min(nlist, 16)
        else:
            index = faiss.IndexFlatIP(self.embedding_dim)
            index.add(embeddings)

        self.index = index
        self.sku_ids = sku_ids

    def search(self, query_embeddings: np.ndarray, top_k: int | None = None) -> list[list[tuple[str, float]]]:
        if self.index is None:
            raise RuntimeError(
                "FAISS index has not been built yet. Run scripts/build_index.py "
                "to build it from data/catalog/ before calling the recognition endpoints."
            )
        top_k = top_k or settings.recognition_top_k

        query_embeddings = np.ascontiguousarray(query_embeddings.astype(np.float32))
        faiss.normalize_L2(query_embeddings)

        similarities, indices = self.index.search(query_embeddings, top_k)

        results: list[list[tuple[str, float]]] = []
        for row_sims, row_idxs in zip(similarities, indices):
            row_results = [
                (self.sku_ids[idx], float(sim)) for idx, sim in zip(row_idxs, row_sims) if idx != -1
            ]
            results.append(row_results)
        return results

    def save(self, directory: Path | None = None) -> None:
        if self.index is None:
            raise RuntimeError("No index to save")
        directory = directory or settings.faiss_index_dir
        directory.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, str(directory / "index.faiss"))
        (directory / "sku_ids.json").write_text(json.dumps(self.sku_ids))

    def load(self, directory: Path | None = None) -> None:
        directory = directory or settings.faiss_index_dir
        self.index = faiss.read_index(str(directory / "index.faiss"))
        self.sku_ids = json.loads((directory / "sku_ids.json").read_text())
