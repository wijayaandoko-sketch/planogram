import hashlib

from PIL import Image, ImageDraw, ImageFont

from app.schemas.models import Detection

UNKNOWN_LABEL = "UNKNOWN"
UNKNOWN_COLOR = (150, 150, 150)

# Distinct, readable colors — cycled through by hashing the sku_id so the
# same SKU always gets the same color across requests, and different SKUs
# in the same image are visually easy to tell apart.
PALETTE = [
    (230, 25, 75),
    (60, 180, 75),
    (255, 165, 0),
    (0, 130, 200),
    (245, 130, 48),
    (145, 30, 180),
    (70, 240, 240),
    (240, 50, 230),
    (210, 245, 60),
    (0, 128, 128),
    (170, 110, 40),
    (128, 0, 0),
    (0, 100, 0),
    (0, 0, 128),
    (128, 128, 0),
    (220, 20, 60),
]


def _color_for_label(sku_id: str | None) -> tuple[int, int, int]:
    if sku_id is None:
        return UNKNOWN_COLOR
    digest = hashlib.md5(sku_id.encode()).hexdigest()
    return PALETTE[int(digest, 16) % len(PALETTE)]


def _text_color_for(background: tuple[int, int, int]) -> tuple[int, int, int]:
    luminance = 0.299 * background[0] + 0.587 * background[1] + 0.114 * background[2]
    return (0, 0, 0) if luminance > 140 else (255, 255, 255)


def draw_detections(image: Image.Image, detections: list[Detection]) -> Image.Image:
    annotated = image.convert("RGB").copy()
    draw = ImageDraw.Draw(annotated)
    try:
        font = ImageFont.truetype("arial.ttf", 16)
    except OSError:
        font = ImageFont.load_default()

    for detection in detections:
        box = detection.box
        color = _color_for_label(detection.sku_id)
        draw.rectangle([box.x1, box.y1, box.x2, box.y2], outline=color, width=3)

        if detection.sku_id and detection.sku_confidence is not None:
            label = f"{detection.sku_id} ({detection.sku_confidence:.2f})"
        else:
            label = f"{UNKNOWN_LABEL} ({detection.detection_confidence:.2f})"

        text_bbox = draw.textbbox((0, 0), label, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]

        label_y = max(box.y1 - text_height - 4, 0)
        draw.rectangle(
            [box.x1, label_y, box.x1 + text_width + 4, label_y + text_height + 4],
            fill=color,
        )
        draw.text((box.x1 + 2, label_y + 2), label, fill=_text_color_for(color), font=font)

    return annotated
