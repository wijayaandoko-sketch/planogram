from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel

from app.core.company import CompanyRecord, resolve_company
from app.core.db import count_stores, delete_store, fetch_store_by_id, list_stores
from app.utils.image_store import store_folder_path

router = APIRouter()

# See template_data.py's identical constants for the rationale — applied
# the same way here so both list endpoints behave consistently.
_DEFAULT_LIMIT = 50
_MAX_LIMIT = 200


class StoreItem(BaseModel):
    company_id: str
    store_id: str
    store_name: str
    customer_tag_id: str


class StoreListResponse(BaseModel):
    success: bool
    data: list[StoreItem]
    message: str


class StoreViewItem(StoreItem):
    store_image_path: str


class StoreViewListResponse(BaseModel):
    success: bool
    data: list[StoreViewItem]
    message: str


@router.get("/view-store-data", tags=["view"], response_model=StoreViewListResponse)
def view_store_data(
    response: Response,
    limit: int = Query(_DEFAULT_LIMIT, gt=0, le=_MAX_LIMIT),
    offset: int = Query(0, ge=0),
    company: CompanyRecord = Depends(resolve_company),
) -> StoreViewListResponse:
    """Lists stores registered for the caller's company (see
    POST /register-store-data), one page at a time (default 50, max 200
    per call; `offset` to move through the rest) rather than every store
    in one response — a long-lived company can accumulate a large store
    list over time. Total row count (ignoring limit/offset) is in the
    `X-Total-Count` response header, not the JSON body.

    store_image_path is where this store's MD images live on disk (see
    app/utils/image_store.py:store_folder_path()) — the folder, not one
    specific file, and returned whether or not /input-md has actually
    been called for this store yet (the folder may not exist on disk
    until then)."""
    rows = list_stores(company.company_id, limit, offset)
    response.headers["X-Total-Count"] = str(count_stores(company.company_id))
    data = [
        StoreViewItem(
            company_id=company.company_id,
            store_id=row["store_id"],
            store_name=row["store_name"],
            customer_tag_id=row["customer_tag_id"],
            store_image_path=str(
                store_folder_path(company.company_name, row["customer_tag_id"], row["store_id"], row["store_name"])
            ),
        )
        for row in rows
    ]
    return StoreViewListResponse(success=True, data=data, message="SUCCESS")


@router.delete("/delete-store-data/{store_id}", tags=["delete"], response_model=StoreListResponse)
def delete_store_data(store_id: str, company: CompanyRecord = Depends(resolve_company)) -> StoreListResponse:
    """Permanently removes the store_id -> customer_tag_id mapping. Images
    already saved under this store_id on disk (see app/utils/image_store.py)
    are NOT deleted — this only removes the store_data row, so
    /input-md and GET /view-store-image stop accepting this store_id
    afterward.

    `data` in the response is the row that got deleted — company_id,
    store_id, store_name, customer_tag_id — not an empty list."""
    existing = fetch_store_by_id(company.company_id, store_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Unknown store_id")

    item = StoreItem(
        company_id=company.company_id,
        store_id=store_id,
        store_name=existing["store_name"],
        customer_tag_id=existing["customer_tag_id"],
    )
    delete_store(company.company_id, store_id)

    return StoreListResponse(success=True, data=[item], message="SUCCESS")
