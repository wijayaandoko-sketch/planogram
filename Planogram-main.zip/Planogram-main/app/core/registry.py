from app.core.company import CompanyRecord
from app.pipeline import CompliancePipeline

_pipelines: dict[str, CompliancePipeline] = {}


def get_pipeline(company: CompanyRecord) -> CompliancePipeline:
    """Returns the cached CompliancePipeline for a company, building it
    (loading YOLO + embedder + FAISS index from disk, per the paths in the
    company_data row) on first use.

    Cached by company_id: if model_path/embed_path/data_path change in the
    database later, the running server keeps using what it already loaded
    until restarted. Not safe against concurrent first-requests for the
    same brand-new company racing to build two pipelines — acceptable for
    this project's scale, revisit if that becomes a real issue.
    """
    if company.company_id not in _pipelines:
        _pipelines[company.company_id] = CompliancePipeline(company)
    return _pipelines[company.company_id]
