import io
import re
from collections import OrderedDict

from fastapi import HTTPException, UploadFile
from PIL import Image
from pydantic import BaseModel

from app.schemas.models import Detection

UNKNOWN_SKU = "UNKNOWN"

# Shared by customer_tag_id and store_id everywhere they're client input —
# both end up as path segments on disk (see app/utils/image_store.py), so
# this blocks path-traversal payloads like "../../etc" from escaping the
# intended upload folder.
SAFE_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")


class ProductLocation(BaseModel):
    bbox: list[float]
    detection_confidence: float
    similarity_score: float | None


class ProductGroup(BaseModel):
    product_id: str
    product_total: int
    locations: list[ProductLocation]


async def read_upload_bounded(file: UploadFile, max_bytes: int, field_name: str) -> bytes:
    """Reads at most (max_bytes + 1) bytes — never the whole file first —
    so a client uploading something far larger than max_bytes can't force
    the server to hold the entire thing in memory before being rejected.
    Real files under the limit are read in full and returned normally."""
    contents = await file.read(max_bytes + 1)
    if len(contents) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"{field_name} exceeds the maximum allowed size of {max_bytes // (1024 * 1024)} MB",
        )
    return contents


def read_image(contents: bytes) -> Image.Image:
    # Image.open() only parses the header — it doesn't decode pixel data,
    # so a truncated/corrupted-but-header-valid file passes silently here
    # and only blows up later (unhandled OSError) wherever the pixels are
    # actually touched. .load() forces the decode now, inside the
    # try/except, so it fails as a clean 400 instead.
    try:
        image = Image.open(io.BytesIO(contents))
        image.load()
        return image
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid image file") from exc


def validate_tag_data(tag_data: dict) -> None:
    """Shared by POST /register-template-data and PUT /template-data/{id}
    — /input-md does arithmetic on these values (must_have - product_total,
    see app/api/routes/md.py), so a non-int here would crash that endpoint
    later instead of failing here, on the request that actually caused it."""
    for sku_id, count in tag_data.items():
        if not isinstance(count, int) or isinstance(count, bool):
            raise HTTPException(
                status_code=400,
                detail=f"customer_tag_data[{sku_id!r}] must be an integer, got {count!r}",
            )


def group_by_product(detections: list[Detection]) -> list[ProductGroup]:
    """Groups raw per-box detections into one entry per SKU (product_id),
    each carrying every instance's bbox/confidence/similarity as its own
    "location" — used by both /register-template and /input-md so the two
    endpoints' detection output stays identical."""
    # OrderedDict (not a plain dict) only to make the grouping order
    # explicit: first-seen order, not sorted — dict already preserves
    # insertion order in modern Python, this just documents that intent.
    groups: OrderedDict[str, list[Detection]] = OrderedDict()
    for detection in detections:
        product_id = detection.sku_id or UNKNOWN_SKU
        groups.setdefault(product_id, []).append(detection)

    return [
        ProductGroup(
            product_id=product_id,
            product_total=len(items),
            locations=[
                ProductLocation(
                    bbox=[d.box.x1, d.box.y1, d.box.x2, d.box.y2],
                    detection_confidence=d.detection_confidence,
                    similarity_score=d.sku_confidence,
                )
                for d in items
            ],
        )
        for product_id, items in groups.items()
    ]
