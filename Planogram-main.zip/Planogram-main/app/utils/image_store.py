import datetime
import re
from pathlib import Path

from app.core.config import settings

_UNSAFE = re.compile(r"[^A-Za-z0-9_-]+")


def _store_segment(store_id: str, store_name: str) -> str:
    return f"{_UNSAFE.sub('_', store_id)}_{_UNSAFE.sub('_', store_name)}"


def _dir(kind: str, company_name: str, customer_tag_id: str, store_id: str | None, store_name: str | None) -> Path:
    directory = settings.uploads_dir / f"{kind}_data" / company_name / customer_tag_id
    if store_id is not None:
        directory = directory / _store_segment(store_id, store_name)
    return directory


def _save(
    image, kind: str, company_name: str, customer_tag_id: str, store_id: str | None, store_name: str | None
) -> Path:
    directory = _dir(kind, company_name, customer_tag_id, store_id, store_name)
    directory.mkdir(parents=True, exist_ok=True)

    # Microsecond precision: two saves for the same tag/store within the
    # same second (e.g. rapid successive /input-md calls) would otherwise
    # produce identical filenames and silently overwrite each other.
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    image_path = directory / f"{customer_tag_id}_{timestamp}.png"
    image.convert("RGB").save(image_path, format="PNG")
    return image_path


def save_md(image, company_name: str, customer_tag_id: str, store_id: str, store_name: str) -> Path:
    """Saves an annotated field-check (MD) image under
    uploads/md_data/<company_name>/<customer_tag_id>/<store_id>_<store_name>/.
    The full detection+comparison result goes to the logs table instead
    (see app.core.db.insert_log)."""
    return _save(image, "md", company_name, customer_tag_id, store_id, store_name)


def save_template(image, company_name: str, customer_tag_id: str) -> Path:
    """Saves a reference template image (no detection run on it) under
    uploads/template_data/<company_name>/<customer_tag_id>/ — no store
    subfolder, this endpoint doesn't take store_id."""
    return _save(image, "template", company_name, customer_tag_id, None, None)


def company_kind_dir(kind: str, company_name: str) -> Path:
    """Root upload folder for this company under the given kind
    ("md" or "template") — data/uploads/<kind>_data/<company_name>/,
    regardless of whether anything's been uploaded there yet. Used to
    show *where* a company's files live without pointing at one specific
    file (see GET /view-template-data and friends)."""
    return settings.uploads_dir / f"{kind}_data" / company_name


def store_folder_path(company_name: str, customer_tag_id: str, store_id: str, store_name: str) -> Path:
    """Where one store's MD images live (or would live) on disk — same
    convention as save_md()/get_latest_image(), regardless of whether any
    image has actually been uploaded for it yet."""
    return _dir("md", company_name, customer_tag_id, store_id, store_name)


def get_latest_image(
    company_name: str, customer_tag_id: str, kind: str, store_id: str | None = None, store_name: str | None = None
) -> Path | None:
    """Most recent image for this company+tag(+store, for kind="md") under
    the given kind ("md" or "template") — by filename, which sorts
    chronologically since the timestamp format (%Y%m%d_%H%M%S) is
    fixed-width."""
    directory = _dir(kind, company_name, customer_tag_id, store_id, store_name)
    if not directory.exists():
        return None

    images = sorted(directory.glob(f"{customer_tag_id}_*.png"))
    return images[-1] if images else None
