from fastapi import APIRouter, Depends, Form, HTTPException
from pydantic import BaseModel

from app.api.routes._common import SAFE_ID_PATTERN
from app.core.company import CompanyRecord, resolve_company
from app.core.db import (
    fetch_latest_template_tag,
    fetch_store_by_id,
    fetch_store_by_name,
    insert_store,
)

router = APIRouter(prefix="/register-store-data", tags=["register"])


class RegisterStoreResult(BaseModel):
    company_id: str
    store_id: str
    store_name: str
    customer_tag_id: str


class RegisterStoreResponse(BaseModel):
    success: bool
    data: list[RegisterStoreResult]
    message: str


@router.post("", response_model=RegisterStoreResponse)
async def register_store(
    store_id: str = Form(...),
    store_name: str = Form(...),
    customer_tag_id: str = Form(...),
    company: CompanyRecord = Depends(resolve_company),
) -> RegisterStoreResponse:
    """Registers one store_id -> customer_tag_id mapping in store_data for
    the caller's company. /input-md and GET /view-store-image validate against
    this table via app/core/store.py:resolve_store() /
    app/core/db.py:fetch_store_by_id().

    store_id AND store_name are each UNIQUE per company_id (not across
    all companies — a different company can reuse the same store_id or
    store_name) — registering either one again within the SAME company
    returns 409 (use PUT /update-store-data to change
    store_name/customer_tag_id afterward).

    customer_tag_id must already have at least one row in template_data
    for this company (i.e. POST /register-template-data was called for it
    at least once) — otherwise 404 "customer_tag_id missing", same check
    and same message as /input-md.

    store_id/customer_tag_id/store_name are length-capped to match their
    VARCHAR columns (store_data, logs) — MySQL silently truncates an
    over-long value in non-strict mode instead of erroring, which would
    otherwise make this 200 with a value that isn't actually what got
    stored (a later lookup with the same string then 404s).

    Every call to this endpoint (success or error) is logged to the
    `logs` table by app/main.py's request-logging middleware — no
    per-route logging code needed here.
    """
    if not SAFE_ID_PATTERN.match(store_id):
        raise HTTPException(
            status_code=400,
            detail="store_id may only contain letters, digits, underscore, and hyphen",
        )
    if len(store_id) > 50:
        raise HTTPException(status_code=400, detail="store_id must be 50 characters or fewer")
    if len(customer_tag_id) > 50:
        raise HTTPException(status_code=400, detail="customer_tag_id must be 50 characters or fewer")
    if len(store_name) > 100:
        raise HTTPException(status_code=400, detail="store_name must be 100 characters or fewer")

    if fetch_latest_template_tag(company.company_id, customer_tag_id) is None:
        raise HTTPException(status_code=404, detail="customer_tag_id missing")

    if fetch_store_by_id(company.company_id, store_id) is not None:
        raise HTTPException(status_code=409, detail="store_id already registered for this company")
    if fetch_store_by_name(company.company_id, store_name) is not None:
        raise HTTPException(status_code=409, detail="store_name already registered for this company")

    insert_store(company.company_id, company.company_name, store_id, store_name, customer_tag_id)

    result = RegisterStoreResult(
        company_id=company.company_id,
        store_id=store_id,
        store_name=store_name,
        customer_tag_id=customer_tag_id,
    )
    return RegisterStoreResponse(success=True, data=[result], message="SUCCESS")
