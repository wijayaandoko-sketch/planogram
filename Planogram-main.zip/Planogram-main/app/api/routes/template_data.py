import datetime
import json

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel

from app.core.company import CompanyRecord, resolve_company
from app.core.db import (
    count_templates,
    delete_templates_by_tag,
    fetch_templates_by_tag,
    list_templates,
)

# Applied uniformly on every list endpoint here and in store_data.py — a
# company with years of history could otherwise return thousands of rows
# in one response (template_data/store_data both only ever grow, nothing
# here is ever deleted except by an explicit delete-* call). limit=0 is
# rejected (Query's gt=0) rather than silently treated as "unlimited" —
# an unbounded response is exactly what this exists to prevent.
_DEFAULT_LIMIT = 50
_MAX_LIMIT = 200

router = APIRouter()


class TemplateItem(BaseModel):
    company_id: str
    customer_tag_id: str
    customer_tag_data: dict[str, int]
    template_image_path: str | None
    created_at: datetime.datetime


class TemplateListResponse(BaseModel):
    success: bool
    data: list[TemplateItem]
    message: str


class DeletedTemplateItem(BaseModel):
    company_id: str
    company_name: str
    customer_tag_id: str
    customer_tag_data: dict[str, int]
    template_image_path: str | None
    created_at: datetime.datetime


class DeletedTemplateListResponse(BaseModel):
    success: bool
    data: list[DeletedTemplateItem]
    message: str


def _to_item(company_id: str, customer_tag_id: str, row: dict) -> TemplateItem:
    return TemplateItem(
        company_id=company_id,
        customer_tag_id=customer_tag_id,
        customer_tag_data=json.loads(row["customer_tag_data"]),
        template_image_path=row["template_image_path"],
        created_at=row["created_at"],
    )


@router.get("/view-template-data", tags=["view"], response_model=TemplateListResponse)
def view_template_data(
    response: Response,
    limit: int = Query(_DEFAULT_LIMIT, gt=0, le=_MAX_LIMIT),
    offset: int = Query(0, ge=0),
    company: CompanyRecord = Depends(resolve_company),
) -> TemplateListResponse:
    """Lists template_data rows for the caller's company, newest first —
    one page at a time (default 50, max 200 per call; `offset` to move
    through the rest) rather than the full history in one response, since
    a long-lived company can accumulate thousands of rows here (every
    register-template-data call adds one, nothing here is ever
    overwritten). The total row count (ignoring limit/offset) is in the
    `X-Total-Count` response header, not in the JSON body — `data` always
    stays a plain list, keeping the {success, data, message} shape
    identical to every other endpoint."""
    rows = list_templates(company.company_id, limit, offset)
    response.headers["X-Total-Count"] = str(count_templates(company.company_id))
    return TemplateListResponse(
        success=True,
        data=[_to_item(company.company_id, row["customer_tag_id"], row) for row in rows],
        message="SUCCESS",
    )


@router.delete(
    "/delete-template-data/{customer_tag_id}", tags=["delete"], response_model=DeletedTemplateListResponse
)
def delete_template_data(
    customer_tag_id: str, company: CompanyRecord = Depends(resolve_company)
) -> DeletedTemplateListResponse:
    """Permanently removes **every** template_data row for this
    customer_tag_id (its full history, not just the latest) — customer_tag_id
    isn't unique per row, so this is a bulk delete by tag rather than a
    single-row delete. Afterward /input-md 404s "customer_tag_id missing"
    for this tag until POST /register-template-data is called again.

    `data` in the response is every row that got deleted (full history,
    newest first) — company_id, company_name, customer_tag_id,
    customer_tag_data, template_image_path, created_at for each."""
    rows = fetch_templates_by_tag(company.company_id, customer_tag_id)
    if not rows:
        raise HTTPException(status_code=404, detail="customer_tag_id missing")

    delete_templates_by_tag(company.company_id, customer_tag_id)

    items = [
        DeletedTemplateItem(
            company_id=row["company_id"],
            company_name=row["company_name"],
            customer_tag_id=row["customer_tag_id"],
            customer_tag_data=json.loads(row["customer_tag_data"]),
            template_image_path=row["template_image_path"],
            created_at=row["created_at"],
        )
        for row in rows
    ]
    return DeletedTemplateListResponse(success=True, data=items, message="SUCCESS")
