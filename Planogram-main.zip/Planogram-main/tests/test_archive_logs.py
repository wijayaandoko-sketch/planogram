"""Tests for scripts/archive_logs.py — needs PLANOGRAM_MYSQL_ADMIN_USER set
(the archiving script requires ALTER TABLE, which the app's regular
least-privilege user deliberately doesn't have — see README.md "Retensi
logs"), so this whole file is skipped when that isn't configured, rather
than failing everyone who runs `pytest` without admin credentials handy.

Uses a test month far enough in the past (2020-01) that it can never
collide with a real month someone is also archiving, and backdates rows
via direct SQL (the app itself always inserts created_at = NOW(), so this
is the only way to get rows into a "past" month for testing).
"""

import csv
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.config import settings  # noqa: E402
from app.core.db import _execute  # noqa: E402

pytestmark = pytest.mark.skipif(
    not settings.mysql_admin_user, reason="PLANOGRAM_MYSQL_ADMIN_USER not set — see README.md 'Retensi logs'"
)

TEST_YEAR = 2020
TEST_MONTH = 1
TEST_LABEL = f"{TEST_YEAR:04d}-{TEST_MONTH:02d}"


def _seed_row(company_id, company_name, day=15):
    _execute(
        "INSERT INTO logs "
        "(url_api, company_id, company_name, customer_tag_id, store_id, store_name, image_path, "
        "message_log, data_type, activity, status, created_at) "
        "VALUES (%s, %s, %s, '', '', '', NULL, NULL, 'company', 'register', 'success', %s)",
        ("archive-test", company_id, company_name, f"{TEST_YEAR:04d}-{TEST_MONTH:02d}-{day:02d} 10:00:00"),
    )


@pytest.fixture
def seeded_test_month():
    """3 rows for company A, 2 for company B, all in the 2020-01 test
    month — cleaned up afterward (any leftover live rows for this month;
    the CSVs this test itself writes are cleaned up in the test body)."""
    from app.core.db import _query_all

    for _ in range(3):
        _seed_row("ARCHTEST_A", "Archive Test A")
    for _ in range(2):
        _seed_row("ARCHTEST_B", "Archive Test B")
    yield
    _execute(
        "DELETE FROM logs WHERE company_id IN ('ARCHTEST_A', 'ARCHTEST_B') AND created_at >= %s AND created_at < %s",
        (f"{TEST_YEAR:04d}-{TEST_MONTH:02d}-01", f"{TEST_YEAR:04d}-{TEST_MONTH + 1:02d}-01"),
    )
    assert _query_all(
        "SELECT COUNT(*) c FROM logs WHERE company_id IN ('ARCHTEST_A', 'ARCHTEST_B')", ()
    )[0]["c"] == 0


def _cleanup_archive_files():
    import shutil

    root = settings.data_dir / "logs_archive"
    (root / "all" / f"logs_{TEST_LABEL}.csv").unlink(missing_ok=True)
    shutil.rmtree(root / "ARCHTEST_A_Archive_Test_A", ignore_errors=True)
    shutil.rmtree(root / "ARCHTEST_B_Archive_Test_B", ignore_errors=True)


def test_archive_month_splits_per_company_and_drops_partition(seeded_test_month):
    from scripts.archive_logs import archive_month
    from app.core.db_admin import partition_exists

    _cleanup_archive_files()
    try:
        archive_month(TEST_YEAR, TEST_MONTH)

        all_csv = settings.data_dir / "logs_archive" / "all" / f"logs_{TEST_LABEL}.csv"
        a_csv = settings.data_dir / "logs_archive" / "ARCHTEST_A_Archive_Test_A" / f"ARCHTEST_A_Archive_Test_A_logs_{TEST_LABEL}.csv"
        b_csv = settings.data_dir / "logs_archive" / "ARCHTEST_B_Archive_Test_B" / f"ARCHTEST_B_Archive_Test_B_logs_{TEST_LABEL}.csv"
        assert all_csv.exists() and a_csv.exists() and b_csv.exists()

        def rows_of(path):
            with path.open(newline="", encoding="utf-8") as f:
                return list(csv.DictReader(f))

        assert len(rows_of(a_csv)) == 3
        assert len(rows_of(b_csv)) == 2
        assert all(r["company_id"] == "ARCHTEST_A" for r in rows_of(a_csv))

        # the partition for this month must be gone — the whole point of archiving
        assert not partition_exists(f"p{TEST_YEAR:04d}{TEST_MONTH:02d}")

        # re-running is a safe no-op (idempotent)
        archive_month(TEST_YEAR, TEST_MONTH)
    finally:
        _cleanup_archive_files()
