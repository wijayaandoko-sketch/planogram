import json

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from pydantic import BaseModel

from app.api.routes._common import ProductLocation, group_by_product, read_image, read_upload_bounded
from app.core.company import CompanyRecord, resolve_company
from app.core.config import settings
from app.core.db import consume_api_limit, fetch_latest_template_tag, peek_api_limit
from app.core.registry import get_pipeline
from app.core.store import resolve_store
from app.utils.image_store import save_md, store_folder_path
from app.utils.visualize import draw_detections

router = APIRouter(prefix="/input-md", tags=["detection"])


class MdProductGroup(BaseModel):
    product_id: str
    must_have: int
    product_total: int
    short_by: int
    locations: list[ProductLocation]


class MissingProduct(BaseModel):
    product_id: str


class InputMdData(BaseModel):
    company_id: str
    api_limit_consumed: int
    api_limit_remaining: int | None
    customer_tag_id: str
    store_id: str
    image_path: str
    total_item: int
    total_product: int
    list_product: list[MdProductGroup]
    missing_product: list[MissingProduct]
    compliance_score: float


class InputMdResponse(BaseModel):
    success: bool
    data: list[InputMdData]
    message: str


def _get_template_counts(company_id: str, customer_tag_id: str) -> dict[str, int]:
    """must_have quantities come from template_data (see
    POST /register-template-data), keyed by customer_tag_id."""
    row = fetch_latest_template_tag(company_id, customer_tag_id)
    if row is None:
        raise HTTPException(status_code=404, detail="customer_tag_id missing")
    return json.loads(row["customer_tag_data"])


@router.post("", response_model=InputMdResponse)
async def input_md(
    request: Request,
    images: list[UploadFile] = File(...),
    customer_tag_id: str = Query(...),
    store_id: str = Query(...),
    company: CompanyRecord = Depends(resolve_company),
) -> InputMdResponse:
    """Detects+recognizes products in one or more field-check (MD) photos
    for the same store visit, then compares each photo's counts against
    customer_tag_id's template (from template_data, see
    POST /register-template-data):
      - must_have: quantity expected per customer_tag_data[product_id]
      - short_by: max(must_have - product_total, 0) — how many are missing
        for a product that IS present but under-stocked
      - missing_product: SKUs in customer_tag_data that don't appear in
        this photo at all
      - compliance_score: percentage (0-100, rounded to 2 decimal places) of
        customer_tag_data's own SKUs that were detected at all in this
        photo — presence-based, not quantity-based, so a SKU counts here
        even if short_by > 0 (under-stocked but still on the shelf); only
        missing_product actually excludes a SKU. E.g. template has 3 SKUs,
        1 is fully missing → compliance_score = round(2/3 * 100, 2) = 66.67.
    Products detected here but absent from customer_tag_data are still
    reported (must_have=0, short_by=0) — flags stock that isn't on the
    planogram, but doesn't affect compliance_score either way.

    customer_tag_id/store_id apply to every photo in the call — there's
    one result per photo in `data`, in upload order, each with its own
    independent detection breakdown and saved image_path (photos are
    never merged into a single combined count). All photos are validated
    (decoded) before any of them are processed or saved — one invalid
    photo fails the whole request and nothing gets saved, same as any
    other endpoint here.

    Validation is API key + customer_tag_id + store_id: customer_tag_id
    must have at least one row in template_data for this company
    (otherwise 404 "customer_tag_id missing"), and store_id must be
    registered in store_data under this exact company+customer_tag_id
    (otherwise 404 "Unknown store_id").

    Every call to this endpoint (success or error) is logged to the
    `logs` table by app/main.py's request-logging middleware — since a
    call can save more than one file, the logged image_path is the store's
    whole MD folder rather than one specific file (see request.state
    below).

    Consumes 1 unit of the company's api_limit (see company_data.api_limit,
    topped up via POST /topup-api-limit) PER PHOTO — 5 photos in one
    successful call costs 5, not 1. Only charged once every photo in the
    call has actually succeeded (same all-or-nothing spirit as the rest of
    this endpoint): a cheap upfront check rejects a request that clearly
    doesn't have enough quota for all its photos before any of them are
    decoded or run through the model, but the atomic decrement at the end
    is what actually enforces this correctly under concurrent requests.
    """
    if not images:
        raise HTTPException(status_code=400, detail="At least one image is required")

    template_counts = _get_template_counts(company.company_id, customer_tag_id)
    store = resolve_store(company.company_id, customer_tag_id, store_id)

    if peek_api_limit(company.company_id) < len(images):
        raise HTTPException(status_code=403, detail="API limit exceeded for this company")

    pil_images = [
        read_image(await read_upload_bounded(image, settings.max_image_upload_bytes, "image")) for image in images
    ]

    pipeline = get_pipeline(company)
    data = []
    for pil_image in pil_images:
        detections = pipeline.detect_and_recognize(pil_image)
        detected_groups = group_by_product(detections)

        list_product = [
            MdProductGroup(
                product_id=group.product_id,
                must_have=template_counts.get(group.product_id, 0),
                product_total=group.product_total,
                short_by=max(template_counts.get(group.product_id, 0) - group.product_total, 0),
                locations=group.locations,
            )
            for group in detected_groups
        ]

        detected_ids = {group.product_id for group in detected_groups}
        missing_product = [
            MissingProduct(product_id=product_id)
            for product_id in template_counts
            if product_id not in detected_ids
        ]

        annotated = draw_detections(pil_image, detections)
        image_path = save_md(annotated, company.company_name, customer_tag_id, store.store_id, store.store_name)

        # Presence-based, not quantity-based: a product counts as "compliant"
        # here the moment it's detected at all, even if short_by > 0 (under-
        # stocked). Only template_counts' own SKUs are counted on either
        # side — a product detected but absent from customer_tag_data
        # doesn't inflate the denominator, same scope as missing_product.
        # Empty template (nothing required) is vacuously 100% compliant.
        total_required_products = len(template_counts)
        compliance_score = (
            100.0
            if total_required_products == 0
            else round((total_required_products - len(missing_product)) / total_required_products * 100, 2)
        )

        data.append(
            InputMdData(
                company_id=company.company_id,
                # Placeholder — every photo in this call is charged as one
                # batch, only once all of them have succeeded (see below),
                # so the real numbers aren't known yet at this point.
                api_limit_consumed=0,
                api_limit_remaining=None,
                customer_tag_id=customer_tag_id,
                store_id=store.store_id,
                image_path=str(image_path),
                total_item=len(detections),
                total_product=len(list_product),
                list_product=list_product,
                missing_product=missing_product,
                compliance_score=compliance_score,
            )
        )

    if not consume_api_limit(company.company_id, len(images)):
        raise HTTPException(status_code=403, detail="API limit exceeded for this company")

    remaining = peek_api_limit(company.company_id)
    for item in data:
        item.api_limit_consumed = len(images)
        item.api_limit_remaining = remaining

    request.state.image_path = str(
        store_folder_path(company.company_name, customer_tag_id, store.store_id, store.store_name)
    )
    request.state.store_name = store.store_name

    return InputMdResponse(success=True, data=data, message="SUCCESS")
