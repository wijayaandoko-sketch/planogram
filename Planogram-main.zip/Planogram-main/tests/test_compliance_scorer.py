import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.compliance.scorer import score_compliance
from app.schemas.models import BoundingBox, Detection, Planogram, PlanogramSlot, SlotStatus


def make_detection(x1: float, y1: float, sku_id: str | None, confidence: float = 0.9) -> Detection:
    return Detection(
        box=BoundingBox(x1=x1, y1=y1, x2=x1 + 50, y2=y1 + 50),
        detection_confidence=confidence,
        sku_id=sku_id,
        sku_confidence=confidence,
    )


def test_fully_compliant_shelf():
    planogram = Planogram(
        planogram_id="p1",
        slots=[
            PlanogramSlot(row=0, column=0, sku_id="A"),
            PlanogramSlot(row=0, column=1, sku_id="B"),
        ],
    )
    detections = [
        make_detection(x1=0, y1=0, sku_id="A"),
        make_detection(x1=60, y1=0, sku_id="B"),
    ]

    result = score_compliance(planogram, detections)

    assert result.compliance_score == 1.0
    assert result.correct_slots == 2
    assert result.missing_slots == 0
    assert result.misplaced_slots == 0


def test_misplaced_and_unexpected():
    # Column assignment is ordinal (left-to-right index within a row), so
    # with 2 expected slots and 2 detected products in row 0, both slots get
    # filled — this case exercises "wrong SKU in every slot", not "missing".
    planogram = Planogram(
        planogram_id="p2",
        slots=[
            PlanogramSlot(row=0, column=0, sku_id="A"),
            PlanogramSlot(row=0, column=1, sku_id="B"),
        ],
    )
    detections = [
        make_detection(x1=0, y1=0, sku_id="B"),  # wrong SKU where A expected
        make_detection(x1=60, y1=0, sku_id="C"),  # wrong SKU where B expected
    ]

    result = score_compliance(planogram, detections)

    statuses = {(s.row, s.column): s.status for s in result.slot_results}
    assert statuses[(0, 0)] == SlotStatus.MISPLACED
    assert statuses[(0, 1)] == SlotStatus.MISPLACED
    assert result.compliance_score == 0.0


def test_missing_slot_with_no_detection():
    planogram = Planogram(
        planogram_id="p2b",
        slots=[
            PlanogramSlot(row=0, column=0, sku_id="A"),
            PlanogramSlot(row=0, column=1, sku_id="B"),
        ],
    )
    detections = [make_detection(x1=0, y1=0, sku_id="A")]

    result = score_compliance(planogram, detections)

    statuses = {(s.row, s.column): s.status for s in result.slot_results}
    assert statuses[(0, 0)] == SlotStatus.CORRECT
    assert statuses[(0, 1)] == SlotStatus.MISSING


def test_unexpected_extra_row():
    planogram = Planogram(
        planogram_id="p2c",
        slots=[PlanogramSlot(row=0, column=0, sku_id="A")],
    )
    detections = [
        make_detection(x1=0, y1=0, sku_id="A"),
        make_detection(x1=0, y1=300, sku_id="C"),  # far below -> separate row
    ]

    result = score_compliance(planogram, detections)

    statuses = {(s.row, s.column): s.status for s in result.slot_results}
    assert statuses[(0, 0)] == SlotStatus.CORRECT
    assert statuses[(1, 0)] == SlotStatus.UNEXPECTED


def test_low_confidence_detection_counts_as_missing():
    planogram = Planogram(
        planogram_id="p3",
        slots=[PlanogramSlot(row=0, column=0, sku_id="A")],
    )
    detections = [make_detection(x1=0, y1=0, sku_id=None)]

    result = score_compliance(planogram, detections)

    assert result.slot_results[0].status == SlotStatus.LOW_CONFIDENCE
    assert result.missing_slots == 1
