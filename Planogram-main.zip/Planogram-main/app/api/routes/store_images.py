from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from app.core.company import CompanyRecord, resolve_company
from app.core.db import fetch_store_by_id
from app.utils.image_store import get_latest_image

router = APIRouter(prefix="/view-store-image", tags=["view"])


class StoreImageResult(BaseModel):
    company_id: str
    store_id: str
    store_name: str
    customer_tag_id: str
    store_image_path: str


class StoreImageResponse(BaseModel):
    success: bool
    data: list[StoreImageResult]
    message: str


@router.get("", response_model=StoreImageResponse)
def get_store_image(
    store_id: str = Query(...),
    company: CompanyRecord = Depends(resolve_company),
) -> StoreImageResponse:
    """Looks up the most recent annotated MD photo (from POST /input-md)
    for this store and returns its metadata — company_id, store_id,
    store_name, customer_tag_id, and store_image_path (the full path to
    that specific file, not the store's whole folder). Does NOT serve the
    image bytes themselves — this endpoint only ever returns JSON, same
    shape as every other endpoint here.

    store_id alone is enough: it's looked up in store_data (must be
    registered via POST /register-store-data) to find which
    customer_tag_id it belongs to, same 404 "Unknown store_id" whether it
    doesn't exist at all or belongs to another company.

    Every call is logged to `logs` (data_type="md", activity="view") by
    app/main.py's request-logging middleware — since the response is JSON
    now, message_log is populated for successful calls too (previously
    NULL, back when this endpoint served a raw PNG)."""
    row = fetch_store_by_id(company.company_id, store_id)
    if row is None:
        raise HTTPException(status_code=404, detail="Unknown store_id")

    path = get_latest_image(company.company_name, row["customer_tag_id"], "md", store_id, row["store_name"])
    if path is None:
        raise HTTPException(status_code=404, detail="No image has been uploaded yet")

    result = StoreImageResult(
        company_id=company.company_id,
        store_id=store_id,
        store_name=row["store_name"],
        customer_tag_id=row["customer_tag_id"],
        store_image_path=str(path),
    )
    return StoreImageResponse(success=True, data=[result], message="SUCCESS")
