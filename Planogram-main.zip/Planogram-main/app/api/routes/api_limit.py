from fastapi import APIRouter, Form, HTTPException, Security
from pydantic import BaseModel

from app.api.routes.company import require_admin_token
from app.core.db import topup_api_limit

router = APIRouter(prefix="/topup-api-limit", tags=["admin"])


class TopupApiLimitResult(BaseModel):
    company_id: str
    api_limit: int


class TopupApiLimitResponse(BaseModel):
    success: bool
    data: list[TopupApiLimitResult]
    message: str


@router.post("", response_model=TopupApiLimitResponse, dependencies=[Security(require_admin_token)])
async def topup_api_limit_route(
    company_id: str = Form(...),
    amount: int = Form(..., gt=0),
) -> TopupApiLimitResponse:
    """Adds `amount` to the company's current api_limit (see
    company_data.api_limit) — this ADDS to whatever is left, it does not
    reset/overwrite it (topping up a company that still has 30 left by 50
    leaves it at 80, not 50). Admin-only, same X-Admin-Token as
    POST /register-company-data — there's no per-company way to do this,
    since a company being low on quota is exactly the situation where its
    own (possibly exhausted) api_limit shouldn't be the thing gating
    whether it can ask for more.

    `data` returns the new total after the top-up, not just the amount
    added.
    """
    new_total = topup_api_limit(company_id, amount)
    if new_total is None:
        raise HTTPException(status_code=404, detail="Unknown company_id")

    result = TopupApiLimitResult(company_id=company_id, api_limit=new_total)
    return TopupApiLimitResponse(success=True, data=[result], message="SUCCESS")
