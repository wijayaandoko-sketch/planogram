import re
import secrets
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, Security, UploadFile
from fastapi.security import APIKeyHeader
from pydantic import BaseModel

from app.api.routes._common import read_upload_bounded
from app.core.config import settings
from app.core.db import fetch_company_by_api_key, fetch_company_by_id, fetch_company_by_name, insert_company

router = APIRouter(prefix="/register-company-data", tags=["admin"])

# This endpoint has no per-company API key to check against (it's what
# CREATES a company) — X-API-Key can't gate it the way it gates every
# other endpoint. X-Admin-Token is a separate, single shared secret for
# whoever administers this deployment, checked against
# settings.admin_token (env PLANOGRAM_ADMIN_TOKEN). scheme_name is
# explicit — see app/core/company.py's _api_key_header for why (both are
# APIKeyHeader instances; without distinct names they collide in the
# OpenAPI schema and Swagger's Authorize dialog shows one merged field).
_admin_token_header = APIKeyHeader(name="X-Admin-Token", scheme_name="AdminTokenAuth", auto_error=False)


def require_admin_token(admin_token: str | None = Security(_admin_token_header)) -> None:
    """Fails CLOSED: if the server itself has no admin_token configured,
    every request is rejected (503) rather than silently letting anyone
    through — a deployment that forgets to set PLANOGRAM_ADMIN_TOKEN must
    not end up with this endpoint wide open by accident. secrets.compare_digest
    avoids leaking the real token's length/prefix via response-timing
    differences (a plain == would return early on the first mismatched
    character)."""
    if not settings.admin_token:
        raise HTTPException(status_code=503, detail="Admin token is not configured on this server")
    if not admin_token or not secrets.compare_digest(admin_token, settings.admin_token):
        raise HTTPException(status_code=401, detail="Missing or invalid X-Admin-Token")

# company_id is a plain identifier (primary key), not a path segment, but
# kept to the same safe charset as customer_tag_id/store_id for
# consistency. company_name IS used as a literal folder name below
# (models/<company_name>/, data/catalog/<company_name>/), so it additionally
# blocks path separators — this is what stops "../../etc" from escaping
# those directories.
_SAFE_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")
_SAFE_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_ -]+$")


class RegisterCompanyResult(BaseModel):
    model_config = {"protected_namespaces": ()}

    company_id: str
    company_name: str
    api_key: str
    model_path: str
    embed_path: str
    data_path: str


class RegisterCompanyResponse(BaseModel):
    success: bool
    data: list[RegisterCompanyResult]
    message: str


@router.post("", response_model=RegisterCompanyResponse, dependencies=[Security(require_admin_token)])
async def register_company_data(
    company_id: str = Form(...),
    company_name: str = Form(...),
    api_key: str = Form(...),
    model_path: UploadFile = File(...),
    embed_path: UploadFile = File(...),
) -> RegisterCompanyResponse:
    """Registers a brand-new company: creates its company_data row AND the
    models/<company_name>/ + data/catalog/<company_name>/ folders it needs,
    in one call — previously this meant manually creating those folders
    and INSERTing company_data by hand, or running scripts/setup_company.py
    (which still expects the weight files to already exist on disk).

    No X-API-Key header here — there's no existing company to
    authenticate as yet; this endpoint is how one gets created. Instead,
    requires header X-Admin-Token matching settings.admin_token (env
    PLANOGRAM_ADMIN_TOKEN) — a single shared secret for whoever
    administers this deployment, not a per-company credential. Without a
    real admin_token configured, this endpoint 503s for every caller
    rather than silently accepting anyone (see require_admin_token above).
    This is code-level defense; it should also sit behind a network-level
    restriction (reverse proxy / firewall) in production — see "Membatasi
    akses register-company-data" in README.md — since it lets any caller
    who gets past it write arbitrary .pt files under models/ on this
    server and create new companies freely.

    - company_id: primary key, letters/digits/underscore/hyphen only, max 50 chars.
    - company_name: becomes a literal folder name under models/ and
      data/catalog/ — letters/digits/spaces/underscore/hyphen only (blocks
      path traversal), max 100 chars.
    - api_key: whatever the client wants callers to send as X-API-Key
      later for this company; must be unique across companies.
    - model_path/embed_path: uploaded .pt files, saved to
      models/<company_name>/<original_filename>, with that relative path
      ("<company_name>/<filename>") stored in the DB column of the same
      name — same convention app/core/company.py resolves at request time.
    - data_path is NOT uploaded here — it's always "catalog/<company_name>",
      and data/catalog/<company_name>/ is created empty; SKU images go in
      per-SKU subfolders there afterward (see "Menambah/mengurangi SKU"
      in the README).

    company_id, company_name, api_key, model_path, embed_path, and
    data_path are all UNIQUE in company_data — company_name is checked
    explicitly (409 "company_name already registered"); model_path/
    embed_path/data_path are derived from company_name
    ("<company_name>/<filename>", "catalog/<company_name>"), so a unique
    company_name is enough to guarantee those three stay unique too,
    without a separate check.

    FAISS index is NOT built here — run
    `scripts/build_index.py --company <company_id>` once the catalog has
    images, otherwise every request for this company 422s
    "faiss_index is missing".

    Every call to this endpoint (success or error) is logged to the
    `logs` table by app/main.py's request-logging middleware — including
    failed attempts, where company_id/company_name are read back from the
    submitted form fields since there's no resolved company yet.
    """
    # Windows silently drops a trailing space when creating a directory
    # (mkdir("Nabati ") actually creates "Nabati") but NOT when opening a
    # file for writing under that same path — so an un-stripped
    # company_name with leading/trailing whitespace made mkdir() succeed
    # and the very next write_bytes() crash with an unhandled
    # FileNotFoundError. Stripping here also turns an all-whitespace
    # company_name into "", which the pattern check below cleanly rejects.
    company_name = company_name.strip()

    if not _SAFE_ID_PATTERN.match(company_id):
        raise HTTPException(
            status_code=400,
            detail="company_id may only contain letters, digits, underscore, and hyphen",
        )
    if len(company_id) > 50:
        raise HTTPException(status_code=400, detail="company_id must be 50 characters or fewer")

    if not _SAFE_NAME_PATTERN.match(company_name):
        raise HTTPException(
            status_code=400,
            detail="company_name may only contain letters, digits, spaces, underscore, and hyphen",
        )
    if len(company_name) > 100:
        raise HTTPException(status_code=400, detail="company_name must be 100 characters or fewer")

    if not api_key:
        raise HTTPException(status_code=400, detail="api_key is required")
    if len(api_key) > 255:
        raise HTTPException(status_code=400, detail="api_key must be 255 characters or fewer")

    if fetch_company_by_id(company_id) is not None:
        raise HTTPException(status_code=409, detail="company_id already registered")
    if fetch_company_by_name(company_name) is not None:
        raise HTTPException(status_code=409, detail="company_name already registered")
    if fetch_company_by_api_key(api_key) is not None:
        raise HTTPException(status_code=409, detail="api_key already in use by another company")

    model_filename = Path(model_path.filename or "").name
    embed_filename = Path(embed_path.filename or "").name
    if not model_filename.lower().endswith(".pt"):
        raise HTTPException(status_code=400, detail="model_path file must be a .pt file")
    if not embed_filename.lower().endswith(".pt"):
        raise HTTPException(status_code=400, detail="embed_path file must be a .pt file")
    if model_filename == embed_filename:
        raise HTTPException(
            status_code=400,
            detail="model_path and embed_path files must have different filenames",
        )

    model_bytes = await read_upload_bounded(model_path, settings.max_model_upload_bytes, "model_path")
    embed_bytes = await read_upload_bounded(embed_path, settings.max_model_upload_bytes, "embed_path")

    model_dir = settings.models_dir / company_name
    model_dir.mkdir(parents=True, exist_ok=True)
    (model_dir / model_filename).write_bytes(model_bytes)
    (model_dir / embed_filename).write_bytes(embed_bytes)

    catalog_dir = settings.data_dir / "catalog" / company_name
    catalog_dir.mkdir(parents=True, exist_ok=True)

    db_model_path = f"{company_name}/{model_filename}"
    db_embed_path = f"{company_name}/{embed_filename}"
    db_data_path = f"catalog/{company_name}"

    insert_company(company_id, company_name, api_key, db_model_path, db_embed_path, db_data_path)

    result = RegisterCompanyResult(
        company_id=company_id,
        company_name=company_name,
        api_key=api_key,
        model_path=db_model_path,
        embed_path=db_embed_path,
        data_path=db_data_path,
    )
    return RegisterCompanyResponse(success=True, data=[result], message="SUCCESS")
