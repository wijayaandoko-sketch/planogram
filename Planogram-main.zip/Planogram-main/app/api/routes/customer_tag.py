import io
import json

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from PIL import Image
from pydantic import BaseModel

from app.api.routes._common import SAFE_ID_PATTERN, read_upload_bounded, validate_tag_data
from app.core.company import CompanyRecord, resolve_company
from app.core.config import settings
from app.core.db import insert_template_tag
from app.utils.image_store import save_template

router = APIRouter(prefix="/register-template-data", tags=["register"])


class RegisterTemplateDataResult(BaseModel):
    company_id: str
    customer_tag_id: str
    customer_tag_data: dict[str, int]
    template_image_path: str


class RegisterTemplateDataResponse(BaseModel):
    success: bool
    data: list[RegisterTemplateDataResult]
    message: str


@router.post("", response_model=RegisterTemplateDataResponse)
async def register_template_data(
    image: UploadFile = File(...),
    customer_tag_id: str = Form(...),
    customer_tag_data: UploadFile = File(..., description='JSON file, e.g. {"SKU A": 2, "SKU B": 3}'),
    company: CompanyRecord = Depends(resolve_company),
) -> RegisterTemplateDataResponse:
    """Data-entry endpoint: inserts one row into template_data for the
    caller's company — company_id/company_name come from the API key,
    customer_tag_id from the form field, customer_tag_data from an
    uploaded .json file, and the uploaded image is saved (no detection run
    on it) to data/uploads/template_data/<company_name>/<customer_tag_id>/,
    with that path stored as template_image_path.

    No detection runs here — the client already has the per-SKU counts and
    just wants them (plus a reference photo) stored under a reusable tag.
    /input-md later reads this back by customer_tag_id alone (see
    app/api/routes/md.py) — nothing else needs to "share" a tag, any
    caller with the right API key + customer_tag_id gets the same data.

    Every call INSERTs a new row rather than updating one in place, so a
    tag accumulates a history; "the current template for this tag" means
    the most recent row by created_at.

    Validation is API key + customer_tag_id format only — no store_id
    here (unlike /input-md and GET /view-store-image, which do validate
    against store_data).

    Every call to this endpoint (success or error) is logged to the
    `logs` table by app/main.py's request-logging middleware — no
    per-route logging code needed here.
    """
    if not SAFE_ID_PATTERN.match(customer_tag_id):
        raise HTTPException(
            status_code=400,
            detail="customer_tag_id may only contain letters, digits, underscore, and hyphen",
        )
    if len(customer_tag_id) > 50:
        raise HTTPException(status_code=400, detail="customer_tag_id must be 50 characters or fewer")

    try:
        raw_tag_data = (
            await read_upload_bounded(customer_tag_data, settings.max_json_upload_bytes, "customer_tag_data")
        ).decode("utf-8")
    except UnicodeDecodeError as exc:
        raise HTTPException(status_code=400, detail="customer_tag_data file must be UTF-8 text") from exc
    try:
        tag_data = json.loads(raw_tag_data)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="customer_tag_data file must be valid JSON") from exc
    if not isinstance(tag_data, dict):
        raise HTTPException(status_code=400, detail="customer_tag_data must be a JSON object")
    validate_tag_data(tag_data)

    try:
        pil_image = Image.open(
            io.BytesIO(await read_upload_bounded(image, settings.max_image_upload_bytes, "image"))
        )
        pil_image.load()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid image file") from exc

    image_path = save_template(pil_image, company.company_name, customer_tag_id)

    insert_template_tag(
        company.company_id,
        company.company_name,
        customer_tag_id,
        json.dumps(tag_data),
        str(image_path),
    )

    result = RegisterTemplateDataResult(
        company_id=company.company_id,
        customer_tag_id=customer_tag_id,
        customer_tag_data=tag_data,
        template_image_path=str(image_path),
    )
    return RegisterTemplateDataResponse(success=True, data=[result], message="SUCCESS")
