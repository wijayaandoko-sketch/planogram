import numpy as np

from app.core.config import settings
from app.schemas.models import Detection


def cluster_into_rows(detections: list[Detection]) -> list[list[Detection]]:
    """Groups detections into shelf rows by their vertical center.

    Sorts by center_y and starts a new row whenever the gap to the previous
    detection exceeds a fraction of the median box height. This assumes
    a roughly front-on shelf photo with horizontal shelves.
    """
    if not detections:
        return []

    sorted_dets = sorted(detections, key=lambda d: d.box.center_y)
    median_height = float(np.median([d.box.height for d in sorted_dets]))
    gap_threshold = median_height * settings.shelf_row_cluster_eps_ratio

    rows: list[list[Detection]] = [[sorted_dets[0]]]
    for det in sorted_dets[1:]:
        prev_center_y = rows[-1][-1].box.center_y
        if det.box.center_y - prev_center_y > gap_threshold:
            rows.append([det])
        else:
            rows[-1].append(det)

    for row in rows:
        row.sort(key=lambda d: d.box.center_x)

    return rows


def assign_grid_positions(detections: list[Detection]) -> dict[tuple[int, int], Detection]:
    """Maps each detection to a (row, column) grid coordinate, row 0 = top shelf.

    Column assignment is ordinal (left-to-right index within the row), not
    spatial. A single missing or extra facing shifts every column after it,
    so this is only reliable when facing counts are close to correct.
    Replacing this with position-aware matching (e.g. against expected slot
    x-ranges) is a known follow-up, not a v1 requirement.
    """
    rows = cluster_into_rows(detections)
    grid: dict[tuple[int, int], Detection] = {}
    for row_idx, row in enumerate(rows):
        for col_idx, detection in enumerate(row):
            grid[(row_idx, col_idx)] = detection
    return grid
