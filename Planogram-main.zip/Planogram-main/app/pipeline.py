from PIL import Image

from app.core.company import CompanyRecord, faiss_index_dir
from app.core.config import settings
from app.detection.yolo_detector import YoloProductDetector
from app.recognition.embedder import ProductEmbedder
from app.recognition.faiss_index import SkuFaissIndex
from app.schemas.models import Detection


def crop_detection(image: Image.Image, detection: Detection) -> Image.Image:
    box = detection.box
    return image.crop((box.x1, box.y1, box.x2, box.y2))


class CompliancePipeline:
    """Shelf photo -> detections -> recognized SKUs, scoped to one company's
    model_path/embed_path/data_path (from company_data) and FAISS index —
    never touches another company's data."""

    def __init__(
        self,
        company: CompanyRecord,
        detector: YoloProductDetector | None = None,
        embedder: ProductEmbedder | None = None,
        faiss_index: SkuFaissIndex | None = None,
    ):
        self.company = company
        self.detector = detector or YoloProductDetector(company.model_path)
        self.embedder = embedder or ProductEmbedder(checkpoint_path=company.embed_path)

        if faiss_index is not None:
            self.faiss_index = faiss_index
        else:
            self.faiss_index = SkuFaissIndex()
            index_dir = faiss_index_dir(company.company_id)
            if (index_dir / "index.faiss").exists():
                self.faiss_index.load(index_dir)

    def recognize(self, image: Image.Image, detections: list[Detection]) -> list[Detection]:
        if not detections:
            return detections

        crops = [crop_detection(image, det) for det in detections]
        embeddings = self.embedder.embed_batch(crops)
        search_results = self.faiss_index.search(embeddings, top_k=1)

        for detection, matches in zip(detections, search_results):
            if not matches:
                continue
            sku_id, similarity = matches[0]
            if similarity >= settings.recognition_min_similarity:
                detection.sku_id = sku_id
                detection.sku_confidence = similarity
        return detections

    def detect_and_recognize(self, image: Image.Image) -> list[Detection]:
        detections = self.detector.detect(image.convert("RGB"))
        return self.recognize(image, detections)
